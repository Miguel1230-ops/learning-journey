local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local GuiService = game:GetService("GuiService")
local usuario = Players.LocalPlayer
local faro = workspace:WaitForChild("IslaDelViento"):WaitForChild("RuinasDelFaro")
local ruta = faro:WaitForChild("RescateNimbo")
local modelos = ReplicatedStorage:WaitForChild("EcosDelFaro")
local remoto = ReplicatedStorage:WaitForChild("AccionFaro")
local huevo = ruta:WaitForChild("Huevo")
local menta,violeta = Color3.fromRGB(101,255,196),Color3.fromRGB(186,129,255)
local companeros = {}
local baseHuevo=huevo.CFrame
local iluminacion=Instance.new("PointLight")
iluminacion.Color,iluminacion.Range,iluminacion.Brightness=Color3.fromRGB(255,199,126),14,1.4
iluminacion.Parent=huevo
local chispas=Instance.new("ParticleEmitter")
chispas.Texture="rbxasset://textures/particles/sparkles_main.dds"
chispas.Rate,chispas.LightEmission,chispas.Speed=0,.9,NumberRange.new(2,6)
chispas.Lifetime,chispas.SpreadAngle=NumberRange.new(.45,.95),Vector2.new(180,180)
chispas.Size=NumberSequence.new(.38,0)
chispas.Parent=huevo

local salida=Instance.new("Attachment")
salida.Parent=faro.Linterna
local haces={}
local arcos={}
for i=1,3 do
	local aro=ruta.Aros[tostring(i)]
	local fin=Instance.new("Attachment")
	fin.Parent=aro.Centro
	local haz=Instance.new("Beam")
	haz.Attachment0,haz.Attachment1=salida,fin
	haz.Width0,haz.Width1,haz.FaceCamera=.34,.12,true
	haz.Color=ColorSequence.new(({menta,Color3.fromRGB(255,203,126),violeta})[i])
	haz.LightEmission,haz.Transparency,haz.Enabled=1,NumberSequence.new(.4),false
	haz.Parent=salida
	haces[i]=haz
	for _,p in aro:GetChildren() do
		if p.Name=="Arco" then table.insert(arcos,p) end
	end
end
local subir=ruta.Ascensor:WaitForChild("Subir")
local saltar=ruta.Despegue:WaitForChild("Saltar")
local abrir=huevo:WaitForChild("Abrir")
local volver=ruta.Nido.Salida:WaitForChild("Volver")
local function actualizar()
	local fase=usuario:GetAttribute("RescateNimbo")
	local visible=usuario:GetAttribute("EnFaro")==true and usuario:GetAttribute("Prisma")==true and usuario:GetAttribute("FaroEncendido")==true
	for _,p in arcos do p.LocalTransparencyModifier=if visible then 0 else 1 end
	for _,haz in haces do haz.Enabled=visible end
	subir.Enabled=visible and (fase==nil or fase=="Balcon")
	saltar.Enabled=visible and fase=="Balcon"
	abrir.Enabled=visible and fase=="Nido"
	volver.Enabled=visible and (fase=="Rescatado" or fase=="Nido")
	local oculto=fase=="Rescatado"
	huevo.LocalTransparencyModifier=if oculto then 1 else 0
	ruta.VetaHuevo.LocalTransparencyModifier=huevo.LocalTransparencyModifier
	ruta.VetaHuevo.Rama.LocalTransparencyModifier=huevo.LocalTransparencyModifier
	if fase~="Eclosion" then
		huevo.CFrame=baseHuevo
		huevo.Color=Color3.fromRGB(250,233,199)
		iluminacion.Brightness=if oculto then 0 else 1.4
	end
end
usuario:GetAttributeChangedSignal("RescateNimbo"):Connect(function()
	if usuario:GetAttribute("RescateNimbo")~="Balcon" or GuiService.ReducedMotionEnabled then return end
	local cam=workspace.CurrentCamera
	if cam and cam.CameraType==Enum.CameraType.Custom then
		local origen=ruta.Despegue.Position
		cam.CFrame=CFrame.lookAt(origen+Vector3.new(-9,7,0),origen+Vector3.new(20,2,0))
	end
end)
for _,a in {"RescateNimbo","EnFaro","Prisma","FaroEncendido"} do
	usuario:GetAttributeChangedSignal(a):Connect(actualizar)
end
actualizar()
remoto.OnClientEvent:Connect(function(evento,aurora)
	if evento=="EclosionNimbo" then
		local tono=if aurora then violeta else Color3.fromRGB(255,192,111)
		chispas.Color=ColorSequence.new(if aurora then menta else huevo.Color,tono)
		iluminacion.Color=tono
		TweenService:Create(iluminacion,TweenInfo.new(.72),{Brightness=4}):Play()
		TweenService:Create(huevo,TweenInfo.new(.12,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,3,true),
			{CFrame=baseHuevo*CFrame.Angles(0,0,.13),Color=tono}):Play()
		chispas:Emit(22)
	elseif evento=="NimboNacio" then
		chispas:Emit(45)
		for lado=-1,1,2 do
			local cascara=huevo:Clone()
			cascara:ClearAllChildren()
			cascara.Name="Fragmento"
			cascara.LocalTransparencyModifier=0
			cascara.Size=huevo.Size*Vector3.new(.68,.5,.73)
			cascara.CFrame=baseHuevo+Vector3.yAxis*(lado*.7)
			cascara.Parent=ruta
			local giro=TweenService:Create(cascara,TweenInfo.new(.65),{CFrame=cascara.CFrame*CFrame.new(lado*2,.6,0)*CFrame.Angles(0,0,lado*.9),Transparency=1})
			giro:Play()
			game:GetService("Debris"):AddItem(cascara,.7)
		end
	end
end)

local function quitar(p)
	local d=companeros[p]
	if d then d.modelo:Destroy() companeros[p]=nil end
end
local function observar(p)
	local function sincronizar()
		local personaje=p.Character
		local r=personaje and personaje:FindFirstChild("HumanoidRootPart")
		local aurora=p:GetAttribute("NimboAurora")==true
		if not r or not p:GetAttribute("Nimbo") then quitar(p) return end
		if companeros[p] and companeros[p].raiz==r and companeros[p].aurora==aurora then return end
		quitar(p)
		local m=modelos[if aurora then "NimboAurora" else "Nimbo"]:Clone()
		local alas={m.AlaIzquierda,m.AlaDerecha}
		local offsets={m:GetPivot():ToObjectSpace(alas[1]:GetPivot()),m:GetPivot():ToObjectSpace(alas[2]:GetPivot())}
		local nace=(r.Position-huevo.Position).Magnitude<13
		m:PivotTo(if nace then baseHuevo else r.CFrame*CFrame.new(-2,2,2))
		m.Parent=workspace
		companeros[p]={modelo=m,raiz=r,aurora=aurora,alas=alas,offsets=offsets,plumas=if aurora then {alas[1]:GetChildren(),alas[2]:GetChildren()} else nil}
	end
	p.CharacterAdded:Connect(function(c) c:WaitForChild("HumanoidRootPart",10) sincronizar() end)
	p.CharacterRemoving:Connect(function() quitar(p) end)
	p:GetAttributeChangedSignal("Nimbo"):Connect(sincronizar)
	p:GetAttributeChangedSignal("NimboAurora"):Connect(sincronizar)
	if p.Character then task.spawn(function() p.Character:WaitForChild("HumanoidRootPart",10) sincronizar() end) end
end
Players.PlayerAdded:Connect(observar)
Players.PlayerRemoving:Connect(quitar)
for _,p in Players:GetPlayers() do observar(p) end
RunService.PreRender:Connect(function(dt)
	local t=workspace:GetServerTimeNow()
	for p,d in companeros do
		local cerca=(workspace.CurrentCamera.CFrame.Position-d.raiz.Position).Magnitude<190
		if not cerca then d.modelo.Parent=nil continue end
		if not d.modelo.Parent then d.modelo.Parent=workspace end
		local destino=d.raiz.CFrame*CFrame.new(-3.1,2.1+math.sin(t*3)*.32,2.25)
		local pose=d.modelo:GetPivot():Lerp(destino,1-math.exp(-dt*6))
		d.modelo:PivotTo(pose)
		for i,ala in d.alas do
			ala:PivotTo(pose*d.offsets[i]*CFrame.Angles(0,0,(if i==1 then -1 else 1)*math.sin(t*8)*.30))
			if d.plumas then
				local tono=menta:Lerp(violeta,.5+.5*math.sin(t*2+i*1.5))
				for _,pluma in d.plumas[i] do pluma.Color=tono end
			end
		end
	end
end)
