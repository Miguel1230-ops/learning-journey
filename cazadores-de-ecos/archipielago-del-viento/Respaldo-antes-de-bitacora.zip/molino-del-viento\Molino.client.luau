local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Controles = require(ReplicatedStorage:WaitForChild("ControlesCombate"))

local jugador = Players.LocalPlayer
local isla = workspace:WaitForChild("IslaDelViento")
local molino = isla:WaitForChild("MolinoDelViento")
local chispa = molino:WaitForChild("Chispa")
local farol = molino:WaitForChild("Farol")
local zona = molino:WaitForChild("ZonaViento")
local despegue = molino:WaitForChild("PlayaDespegue")
local muelle = molino:WaitForChild("Llegada")
local aspas = molino:WaitForChild("Aspas")
local accion = ReplicatedStorage:WaitForChild("AccionMolino")
local abandonarCola = Instance.new("ProximityPrompt")
abandonarCola.Name = "SalirDeLaEspera"
abandonarCola.ObjectText = "Muelle del Molino"
abandonarCola.ActionText = "Volver al despegue"
abandonarCola.RequiresLineOfSight = false
abandonarCola.MaxActivationDistance = 12
abandonarCola.Enabled = false
abandonarCola.Parent = muelle
abandonarCola.Triggered:Connect(function()
	if jugador:GetAttribute("EsperaMolino") then accion:FireServer("SalirDeLaEspera") end
end)

-- Cada visitante ve las acciones de su turno. El servidor valida de nuevo al interactuar.
local tomar = chispa:WaitForChild("Accion")
local entregar = farol:WaitForChild("Accion")
local volver = molino:WaitForChild("Regreso"):WaitForChild("Accion")
local alcanceTomar, alcanceEntregar, alcanceVolver = tomar.MaxActivationDistance, entregar.MaxActivationDistance, volver.MaxActivationDistance
local function mostrarAcciones()
	local dentro = jugador:GetAttribute("EnMolino") == true
	local propio = dentro and molino:GetAttribute("TitularExpedicion") == jugador.UserId
	tomar.MaxActivationDistance = if propio then alcanceTomar else 0
	entregar.MaxActivationDistance = if propio then alcanceEntregar else 0
	volver.MaxActivationDistance = if dentro and not jugador:GetAttribute("EsperaMolino") then alcanceVolver else 0
	abandonarCola.Enabled = dentro and jugador:GetAttribute("EsperaMolino") == true
end
molino:GetAttributeChangedSignal("TitularExpedicion"):Connect(mostrarAcciones)
jugador:GetAttributeChangedSignal("EnMolino"):Connect(mostrarAcciones)
jugador:GetAttributeChangedSignal("EsperaMolino"):Connect(mostrarAcciones)
mostrarAcciones()

local NOCHE = Color3.fromRGB(15, 26, 40)
local PIZARRA = Color3.fromRGB(54, 75, 97)
local PERLA = Color3.fromRGB(246, 250, 250)
local SUAVE = Color3.fromRGB(192, 210, 224)
local ORO = Color3.fromRGB(255, 201, 111)
local HIELO = Color3.fromRGB(148, 224, 255)
local CORAL = Color3.fromRGB(255, 174, 155)
local MENTA = Color3.fromRGB(143, 244, 217)

local VUELTA = 6.25
local REVELACION = 3.7
local ESCENA_MOVIMIENTO_REDUCIDO = 2.8
local escena
local pendiente

local function crear(clase, padre, props)
	local objeto = Instance.new(clase)
	for nombre, valor in pairs(props) do
		objeto[nombre] = valor
	end
	objeto.Parent = padre
	return objeto
end

local function superficie(padre, props, radio, tono)
	local objeto = crear("Frame", padre, props)
	crear("UICorner", objeto, { CornerRadius = UDim.new(0, radio or 12) })
	crear("UIStroke", objeto, { Color = tono or PIZARRA, Transparency = 0.37 })
	return objeto
end

local function etiqueta(padre, nombre, y, tamano, alto, fuerte)
	return crear("TextLabel", padre, {
		Name = nombre,
		BackgroundTransparency = 1,
		Position = UDim2.fromOffset(14, y),
		Size = UDim2.new(1, -28, 0, alto),
		Font = if fuerte then Enum.Font.GothamBold else Enum.Font.GothamMedium,
		TextSize = tamano,
		TextColor3 = if fuerte then PERLA else SUAVE,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextWrapped = true,
	})
end

local gui = crear("ScreenGui", jugador:WaitForChild("PlayerGui"), {
	Name = "MolinoDelVientoHUD",
	ResetOnSpawn = false,
	ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets,
	DisplayOrder = 13,
	Enabled = false,
})

local tarjeta = superficie(gui, {
	Name = "Mision",
	Position = UDim2.fromOffset(13, 9),
	Size = UDim2.new(1, -26, 0, 72),
	BackgroundColor3 = NOCHE,
	BackgroundTransparency = 0.08,
	BorderSizePixel = 0,
})
crear("UISizeConstraint", tarjeta, { MaxSize = Vector2.new(342, 72) })
local titulo = etiqueta(tarjeta, "Titulo", 7, 16, 22, true)
local objetivo = etiqueta(tarjeta, "Objetivo", 29, 13, 34, false)
local fuerza = crear("Frame", tarjeta, {
	Name = "FuerzaChispa",
	Position = UDim2.fromOffset(14, 64),
	Size = UDim2.new(1, -28, 0, 3),
	BackgroundColor3 = PIZARRA,
	BorderSizePixel = 0,
	Visible = false,
})
local porcion = crear("Frame", fuerza, {
	Size = UDim2.fromScale(1, 1),
	BackgroundColor3 = ORO,
	BorderSizePixel = 0,
})

local ayuda = superficie(gui, {
	Name = "Aviso",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 0, 1, -21),
	Size = UDim2.new(1, -34, 0, 51),
	BackgroundColor3 = NOCHE,
	BackgroundTransparency = 0.12,
	BorderSizePixel = 0,
	Visible = false,
})
crear("UISizeConstraint", ayuda, { MaxSize = Vector2.new(400, 51) })
local estado = etiqueta(ayuda, "Estado", 4, 14, 21, true)
local detalle = etiqueta(ayuda, "Detalle", 25, 11, 19, false)
estado.TextXAlignment = Enum.TextXAlignment.Center
detalle.TextXAlignment = Enum.TextXAlignment.Center

local function boton(padre, nombre, texto, pos, tamano, tono)
	local b = crear("TextButton", padre, {
		Name = nombre,
		AnchorPoint = Vector2.new(1, 1),
		Position = pos,
		Size = tamano,
		BackgroundColor3 = NOCHE,
		BackgroundTransparency = 0.08,
		BorderSizePixel = 0,
		Text = texto,
		TextColor3 = tono,
		TextSize = 13,
		Font = Enum.Font.GothamBold,
	})
	crear("UICorner", b, { CornerRadius = UDim.new(0, 11) })
	crear("UIStroke", b, { Color = tono, Transparency = 0.57 })
	return b
end

local escudo = boton(gui, "Escudo", "Escudo", UDim2.new(1, -16, 1, -179), UDim2.fromOffset(105, 45), HIELO)
escudo.Visible = false

local cine = crear("ScreenGui", gui.Parent, {
	Name = "MolinoCinematica",
	ResetOnSpawn = false,
	ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets,
	DisplayOrder = 26,
	Enabled = false,
})
local sombra = crear("Frame", cine, {
	AnchorPoint = Vector2.new(0, 1),
	Position = UDim2.fromScale(0, 1),
	Size = UDim2.fromScale(1, 0.32),
	BackgroundColor3 = NOCHE,
	BorderSizePixel = 0,
	BackgroundTransparency = 1,
})
crear("UIGradient", sombra, { Rotation = 90, Transparency = NumberSequence.new(1, 0.05) })
local letrero = crear("CanvasGroup", cine, {
	Name = "Descubrimiento",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 0, 1, -20),
	Size = UDim2.new(1, -44, 0, 83),
	BackgroundColor3 = NOCHE,
	BackgroundTransparency = 0.12,
	BorderSizePixel = 0,
	GroupTransparency = 1,
})
crear("UICorner", letrero, { CornerRadius = UDim.new(0, 13) })
crear("UISizeConstraint", letrero, { MaxSize = Vector2.new(422, 83) })
crear("UIStroke", letrero, { Color = ORO, Transparency = 0.4 })
local corona = etiqueta(letrero, "Categoria", 6, 11, 17, true)
local nombre = etiqueta(letrero, "Nombre", 24, 23, 27, true)
local lema = etiqueta(letrero, "Pista", 52, 12, 24, false)
corona.TextColor3 = ORO
corona.TextXAlignment = Enum.TextXAlignment.Center
nombre.TextXAlignment = Enum.TextXAlignment.Center
lema.TextXAlignment = Enum.TextXAlignment.Center
local omitir = boton(cine, "Omitir", "Omitir escena", UDim2.new(1, -14, 0, 11), UDim2.fromOffset(120, 44), PERLA)
omitir.AnchorPoint = Vector2.new(1, 0)

local function hoy()
	return workspace:GetServerTimeNow()
end

local function avatar()
	local personaje = jugador.Character
	local humanoide = personaje and personaje:FindFirstChildOfClass("Humanoid")
	return if personaje then personaje:FindFirstChild("HumanoidRootPart") else nil, humanoide
end

local function cerrarEscena(completada)
	if not escena then
		return
	end
	local anterior = escena
	escena = nil
	cine.Enabled = false
	jugador:SetAttribute("MolinoPresentando", false)
	if anterior.humanoide and anterior.humanoide.Parent then
		if anterior.humanoide.WalkSpeed == 0 then
			anterior.humanoide.WalkSpeed = anterior.paso
		end
		anterior.humanoide.AutoRotate = anterior.giro
		anterior.humanoide:SetStateEnabled(Enum.HumanoidStateType.Jumping, anterior.salto)
	end
	if anterior.camara and workspace.CurrentCamera == anterior.camara then
		anterior.camara.CFrame = if completada and anterior.marcoFinal then anterior.marcoFinal else anterior.marco
		anterior.camara.Focus = if completada and anterior.focoFinal then anterior.focoFinal else anterior.foco
		anterior.camara.FieldOfView = anterior.fov
		anterior.camara.CameraType = anterior.tipo
	end
	if anterior.ocultos then
		for pieza, transparencia in anterior.ocultos do
			if pieza.Parent then
				pieza.LocalTransparencyModifier = transparencia
			end
		end
	end
	for objeto, encendido in anterior.efectosOcultos or {} do
		if objeto.Parent then objeto.Enabled = encendido end
	end
	if anterior.arte then
		anterior.arte:Destroy()
	end
end

local function luzLocal(padre, tono, medida, forma)
	return crear("Part", padre, {
		Anchored = true,
		CanCollide = false,
		CanTouch = false,
		CanQuery = false,
		CastShadow = false,
		Material = Enum.Material.Neon,
		Color = tono,
		Size = medida,
		Shape = forma or Enum.PartType.Block,
		Transparency = 1,
	})
end

local function cometaDeEscena(esc)
	local companeros = isla:FindFirstChild("CompanerosCometa")
	local original = companeros and companeros:FindFirstChild(tostring(jugador.UserId))
	if not original or not original:IsA("Model") or original:GetAttribute("Propietario") ~= jugador.UserId then
		return
	end
	local copia = original:Clone()
	if not copia then
		return
	end
	esc.ocultos, esc.efectosOcultos = {}, {}
	for _, pieza in original:GetDescendants() do
		if pieza:IsA("BasePart") then
			esc.ocultos[pieza] = pieza.LocalTransparencyModifier
			pieza.LocalTransparencyModifier = 1
		elseif pieza:IsA("Light") or pieza:IsA("ParticleEmitter") or pieza:IsA("Trail") or pieza:IsA("Beam") then
			esc.efectosOcultos[pieza] = pieza.Enabled
			pieza.Enabled = false
		end
	end
	for _, pieza in copia:GetDescendants() do
		if pieza:IsA("BasePart") then
			pieza.Anchored = true
			pieza.CanCollide = false
			pieza.CanQuery = false
			pieza.CanTouch = false
			pieza.LocalTransparencyModifier = 0
		end
	end
	copia.Name = "CometaEnVuelo"
	esc.inicioEco = original:GetPivot().Position
	copia:PivotTo(original:GetPivot())
	copia.Parent = esc.arte
	esc.cometa = copia

	local centro = copia.PrimaryPart or copia:FindFirstChild("Nucleo")
	if centro and centro:IsA("BasePart") then
		local izq = crear("Attachment", centro, { Position = Vector3.new(-0.5, 0, 0.75) })
		local der = crear("Attachment", centro, { Position = Vector3.new(0.5, 0, 0.75) })
		crear("Trail", centro, {
			Attachment0 = izq,
			Attachment1 = der,
			Color = ColorSequence.new(PERLA, ORO),
			Transparency = NumberSequence.new(0.17, 1),
			WidthScale = NumberSequence.new(0.9, 0),
			Lifetime = 0.32,
			LightEmission = 0.93,
			FaceCamera = true,
			MinLength = 0.12,
		})
	end
end

local function plano(p)
	return Vector3.new(p.X, 0, p.Z)
end

local function curva(a, b, c, d, t)
	return 0.5 * ((2 * b) + (c - a) * t + (2 * a - 5 * b + 4 * c - d) * t * t
		+ (3 * b - a - 3 * c + d) * t * t * t)
end

local function muestrear(paradas, t)
	for i = 1, #paradas - 1 do
		local b = paradas[i]
		local c = paradas[i + 1]
		if t <= c[1] or i == #paradas - 1 then
			local a = paradas[math.max(1, i - 1)]
			local d = paradas[math.min(i + 2, #paradas)]
			local u = math.clamp((t - b[1]) / (c[1] - b[1]), 0, 1)
			return curva(a[2], b[2], c[2], d[2], u), curva(a[3], b[3], c[3], d[3], u),
				b[4] + (c[4] - b[4]) * u, b[5] + (c[5] - b[5]) * u
		end
	end
end

local function escala(u)
	u = math.clamp(u, 0, 1)
	return u * u * (3 - 2 * u)
end

local function vueltaDeIsla(esc, root)
	local puerto, semilla = muelle.Position, chispa.Position
	local eje = aspas:GetPivot().Position
	local ejePlano = plano(eje - semilla)
	local ancho = math.clamp(ejePlano.Magnitude, 18, 48)
	local frente = if ejePlano.Magnitude > .1 then ejePlano.Unit else muelle.CFrame.RightVector
	local lado = frente:Cross(Vector3.yAxis)
	if lado:Dot(despegue.Position - puerto) < 0 then lado = -lado end
	local altura = Vector3.yAxis
	local centro = Vector3.new((semilla.X + eje.X)/2, semilla.Y, (semilla.Z + eje.Z)/2)
	esc.percha = semilla - frente * 1.6 + altura * 1.35
	local haciaChispa = plano(semilla-root.Position)
	local rumbo = if haciaChispa.Magnitude > .05 then haciaChispa.Unit else frente
	local distancia = (esc.marco.Position - esc.foco.Position).Magnitude
	local foco = root.Position + altura*1.5
	local elevacion = math.clamp(-esc.marco.LookVector.Y, -.15, .55)
	local vista = rumbo * math.sqrt(1-elevacion*elevacion) - altura*elevacion
	esc.focoFinal = CFrame.new(foco)
	esc.marcoFinal = CFrame.lookAt(foco - vista * distancia, foco - vista * distancia + vista)
	esc.pasoEco = puerto + frente * 5.6 + lado * 2.5 + altura * 4.8
	esc.vueloEco = semilla + frente * (ancho * .42) + lado * 4.5 + altura * 8
	esc.adelante = frente
	return {
		{ 0, esc.marco.Position, esc.foco.Position, esc.fov, 0 },
		{ .72, puerto-frente*7+lado*10+altura*6, puerto+altura*1.6, 63,-.018 },
		{ 1.56, esc.pasoEco-frente*3+lado*11+altura*2.5, esc.pasoEco, 55,-.024 },
		{ 2.55, centro+frente*(ancho*.24)+lado*25+altura*14, eje, 63,-.035 },
		{ 3.32, centro+frente*(ancho*.82)+lado*10+altura*22, eje+altura*.8, 66,-.017 },
		{ 4.16, centro+frente*(ancho*.36)-lado*25+altura*28, centro+altura*3, 65,.025 },
		{ 4.92, centro-frente*(ancho*.47)-lado*18+altura*13, semilla+altura*1.1, 58,.017 },
		{ 5.55, semilla-frente*8+lado*5+altura*5, semilla+altura*.6, 53,0 },
		{ esc.duracion, esc.marcoFinal.Position, esc.marcoFinal.Position + esc.marcoFinal.LookVector * math.max(distancia, 1), esc.fov, 0 },
	}
end

local function chispasDeRecompensa(esc)
	local apunta = farol.Position
	esc.pulso = luzLocal(esc.arte, ORO, Vector3.one, Enum.PartType.Ball)
	esc.pulso.Position = apunta
	esc.brillo = crear("PointLight", esc.pulso, { Color = ORO, Range = 22, Brightness = 0 })
	esc.particulas = {}
	for i = 1, 18 do
		local tono = if i % 4 == 0 then PERLA else ORO
		esc.particulas[i] = luzLocal(esc.arte, tono, Vector3.new(0.14, 0.34 + (i % 3) * 0.14, 0.13))
	end

	esc.faros = {}
	local luces = molino:FindFirstChild("Luces")
	if not luces then
		return
	end
	local recorrido = luces:GetChildren()
	table.sort(recorrido, function(a, b)
		return a.Name < b.Name
	end)
	for _, faro in recorrido do
		if faro:IsA("BasePart") then
			local pulso = luzLocal(esc.arte, ORO, Vector3.one, Enum.PartType.Ball)
			pulso.Position = faro.Position
			esc.faros[#esc.faros + 1] = pulso
		end
	end
end

local function imagen(esc, origen, objetivoCam, fov, rotacion)
	local camara = esc.camara
	if (origen - objetivoCam).Magnitude < 0.2 then
		objetivoCam = origen + esc.marco.LookVector
	end
	camara.CFrame = CFrame.lookAt(origen, objetivoCam) * CFrame.Angles(0, 0, rotacion)
	camara.Focus = CFrame.new(objetivoCam)
	camara.FieldOfView = fov
end

local function pintarLlegada(esc, t)
	local pos, meta, fov, giro = muestrear(esc.paradas, t)
	imagen(esc, pos, meta, fov, giro)
	local retorno = escala((t - 5.55) / math.max(.1, esc.duracion - 5.55))
	if retorno > 0 then
		esc.camara.CFrame = esc.camara.CFrame:Lerp(esc.marcoFinal, retorno)
		esc.camara.Focus = esc.camara.Focus:Lerp(esc.focoFinal, retorno)
	end
	if not esc.cometa and t >= (esc.reintentoEco or 0) then
		esc.reintentoEco = t + .24
		cometaDeEscena(esc)
	end
	if not esc.cometa then
		return
	end
	local vuelo = esc.inicioEco:Lerp(esc.pasoEco, escala(t/1.45))
	vuelo = vuelo:Lerp(esc.vueloEco, escala((t-1.55)/1.35))
	vuelo = vuelo:Lerp(esc.percha, escala((t-3.12)/1.9))
	local companeros = isla:FindFirstChild("CompanerosCometa")
	local original = companeros and companeros:FindFirstChild(tostring(jugador.UserId))
	if original then vuelo = vuelo:Lerp(original:GetPivot().Position, retorno) end
	vuelo += Vector3.yAxis * math.sin(t*4) * .19 * (1-retorno)
	local orientacion = CFrame.lookAt(vuelo, vuelo+esc.adelante) * CFrame.Angles(0,0,math.sin(t*3.1)*.13)
	if original and retorno > 0 then orientacion = orientacion:Lerp(original:GetPivot(), retorno) end
	esc.cometa:PivotTo(orientacion)
end

local function pintarPremio(esc, t)
	local centro = farol.Position
	local vuelo = escala(t / 2.45)
	local base = centro + Vector3.new(-9.5, 3.25, -7.8)
	local alto = centro + Vector3.new(-13.5, 6.1, -10.2)
	local corte = math.clamp((t - 0.44) / 1.2, 0, 1)
	local mirada = centro + Vector3.new(0, 1.1 + vuelo * 0.72, 0)
	imagen(esc, base:Lerp(alto, vuelo), mirada, 52 + 8 * vuelo, 0)
	esc.pulso.Size = Vector3.one * (0.24 + corte * 5.5)
	esc.pulso.Transparency = if t < 0.44 then 1 else 0.65 + corte * 0.35
	esc.brillo.Brightness = 0.7 * (1 - corte) + 3.2 * math.sin(corte * math.pi)
	for i, pieza in esc.particulas do
		local a = i * 2.4
		local r = 0.3 + corte * (2.0 + i % 4 * 0.9)
		local y = math.sin(corte * 2.54) * (1 + (i % 5) * 0.75)
		pieza.CFrame = CFrame.new(centro + Vector3.new(math.cos(a) * r, y, math.sin(a) * r))
			* CFrame.Angles(a, t * 2 + a / 2, t * 4)
		pieza.Transparency = if t < 0.44 then 1 else math.min(1, corte * 1.36)
	end
	for i, orbe in esc.faros do
		local onda = math.clamp((t - 0.42 - i * (1.36 / #esc.faros)) / 0.65, 0, 1)
		orbe.Size = Vector3.one * (0.25 + onda * 3.3)
		orbe.Transparency = if onda <= 0 then 1 else 0.51 + onda * 0.49
	end
end

local function iniciarEscena(evento, comienzo, duracionServidor)
	if not jugador:GetAttribute("EnMolino") or jugador:GetAttribute("EnCueva") then
		return
	end
	cerrarEscena()
	local llegada = evento == "Llegada"
	local reducir = GuiService.ReducedMotionEnabled
	local duracion = if llegada then VUELTA else REVELACION
	if typeof(duracionServidor) == "number" then
		duracion = math.clamp(duracionServidor, if llegada then 5.95 else 2.5, 8)
	end
	if reducir then
		duracion = math.min(duracion, ESCENA_MOVIMIENTO_REDUCIDO)
	end
	local root, humanoide = avatar()
	if not root or not humanoide or humanoide.Health <= 0 or hoy() - comienzo >= duracion then
		return
	end
	local camara = if reducir then nil else workspace.CurrentCamera
	local esc = {
		llegada = llegada,
		comienzo = comienzo,
		duracion = duracion,
		camara = camara,
	}
	escena = esc
	if camara then
		esc.marco = camara.CFrame
		esc.foco = camara.Focus
		esc.fov = camara.FieldOfView
		esc.tipo = camara.CameraType
		esc.humanoide = humanoide
		esc.paso = humanoide.WalkSpeed
		esc.giro = humanoide.AutoRotate
		esc.salto = humanoide:GetStateEnabled(Enum.HumanoidStateType.Jumping)
		humanoide.WalkSpeed = 0
		humanoide.AutoRotate = false
		humanoide:SetStateEnabled(Enum.HumanoidStateType.Jumping, false)
		root.AssemblyLinearVelocity = Vector3.new(0, math.min(root.AssemblyLinearVelocity.Y, 0), 0)
		esc.arte = crear("Folder", workspace, { Name = "CinematicaMolinoLocal" })
		camara.CameraType = Enum.CameraType.Scriptable
		if llegada then
			esc.paradas = vueltaDeIsla(esc, root)
			cometaDeEscena(esc)
		else
			chispasDeRecompensa(esc)
		end
	end
	jugador:SetAttribute("MolinoPresentando", true)
	gui.Enabled = false
	corona.Text = if llegada then "ISLA DEL VIENTO" else "ECO RESCATADO"
	nombre.Text = if llegada then "Molino del Viento" else "Lucero"
	lema.Text = if llegada then "Cometa encontró una chispa viva." else "La chispa despertó y el molino volvió a girar."
	letrero.GroupTransparency = 1
	sombra.BackgroundTransparency = 1
	cine.Enabled = true
end

local function terminarEscena()
	accion:FireServer(if escena.llegada then "TerminarLlegada" else "TerminarDespertar")
	cerrarEscena(true)
end

local function omitirEscena()
	if not escena then
		return false
	end
	terminarEscena()
	return true
end

local function usarEscudo()
	if not escena and jugador:GetAttribute("EnMolino") and jugador:GetAttribute("Pedernal")
		and jugador:GetAttribute("LlevaChispa") and (jugador:GetAttribute("EscudoMolinoListoEn") or 0) <= hoy() then
		accion:FireServer("Escudo")
		return true
	end
	return false
end

Controles.escudoBreve(function() return jugador:GetAttribute("EnMolino") and not escena end, usarEscudo)
ContextActionService:BindActionAtPriority("MolinoEscudo", function(_, entrada)
	if entrada == Enum.UserInputState.Begin and usarEscudo() then
		return Enum.ContextActionResult.Sink
	end
	return Enum.ContextActionResult.Pass
end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.ButtonR1)
ContextActionService:BindActionAtPriority("MolinoOmitir", function(_, entrada)
	if entrada == Enum.UserInputState.Begin and omitirEscena() then
		return Enum.ContextActionResult.Sink
	end
	return Enum.ContextActionResult.Pass
end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.ButtonB)
escudo.Activated:Connect(usarEscudo)
omitir.Activated:Connect(omitirEscena)
jugador.CharacterRemoving:Connect(function()
	pendiente = nil
	cerrarEscena()
end)
jugador:GetAttributeChangedSignal("EnMolino"):Connect(function()
	if not jugador:GetAttribute("EnMolino") then
		pendiente = nil
		cerrarEscena()
	end
end)
accion.OnClientEvent:Connect(function(evento, comienzo, duracion)
	if (evento == "Llegada" or evento == "Despertar") and typeof(comienzo) == "number" then
		pendiente = { evento = evento, comienzo = comienzo, duracion = duracion }
	end
end)

local function cercaDelViento(posicion)
	local d = zona.CFrame:PointToObjectSpace(posicion)
	local mitad = zona.Size * 0.5 + Vector3.new(5, 3, 5)
	return math.abs(d.X) <= mitad.X and math.abs(d.Y) <= mitad.Y and math.abs(d.Z) <= mitad.Z
end

local function indicador(cabecera, texto, tono)
	estado.Text = cabecera
	estado.TextColor3 = tono
	detalle.Text = texto
	ayuda.Visible = true
end

local function mostrarMision()
	local root, humanoide = avatar()
	local enIsla = not jugador:GetAttribute("EnCueva")
	local dentro = jugador:GetAttribute("EnMolino") == true
	local completado = jugador:GetAttribute("Lucero") == true
	local listo = jugador:GetAttribute("Pedernal") and jugador:GetAttribute("Cometa")
	local cercaDespegue = root and (root.Position - despegue.Position).Magnitude < 13
	gui.Enabled = enIsla and root ~= nil and humanoide and humanoide.Health > 0
		and (dentro or (listo and not completado and cercaDespegue)) or false
	if not gui.Enabled then
		return
	end
	tarjeta.Visible = dentro
	ayuda.Visible = false
	escudo.Visible = false
	local lt = UserInputService:GetLastInputType()
	local mando = lt.Name:match("^Gamepad") ~= nil
	local tactil = UserInputService.TouchEnabled and not mando
	local tecla = if tactil then "Toca Escudo" elseif mando then "R1" else "Clic derecho"
	local interactuar = if tactil then "Toca el aviso" elseif mando then "X" else "E"
	titulo.Text = "Molino del Viento"

	if not dentro then
		local planear = if tactil then "toca Planeo" elseif mando then "pulsa Y para planear" else "pulsa F para planear"
		ayuda.Position = UDim2.new(0.5, 0, 1, -59)
		indicador("Despegue hacia el molino", "Salta hacia la otra plataforma y " .. planear .. ".", ORO)
		return
	end
	ayuda.Position = UDim2.new(0.5, 0, 1, if tactil then -45 else -22)
	local lleva = jugador:GetAttribute("LlevaChispa") == true
	local proteccion = math.max(0, (jugador:GetAttribute("EscudoMolinoHasta") or 0) - hoy())
	local recarga = math.max(0, (jugador:GetAttribute("EscudoMolinoListoEn") or 0) - hoy())
	local situacion = jugador:GetAttribute("EstadoChispa")
	local viento = molino:GetAttribute("EstadoViento")
	local fase = molino:GetAttribute("MolinoFase")
	escudo.Visible = tactil and lleva
	escudo.Text = if proteccion > 0 then ("%0.1f s  Escudo"):format(proteccion)
		elseif recarga > 0 then "Recargando" else "Escudo"
	fuerza.Visible = lleva
	local intensidad = math.clamp(jugador:GetAttribute("FuerzaChispa") or 1, 0, 1)
	porcion.Size = UDim2.fromScale(intensidad, 1)
	porcion.BackgroundColor3 = if proteccion > 0 then HIELO else CORAL:Lerp(ORO, intensidad)

	if jugador:GetAttribute("EsperaMolino") then
		objetivo.Text = "Otro explorador está llevando la chispa. Tu turno empieza aquí en cuanto termine."
		indicador("Estás en la fila", "Quédate en el muelle, o vuelve al despegue para salir de la fila.", HIELO)
	elseif completado then
		titulo.Text = "El molino volvió a girar"
		objetivo.Text = if isla:FindFirstChild("RefugioDelViento") then "Vuelve al refugio para visitar al farero."
			else "Lucero se une a tus Ecos. Usa el regreso junto al molino."
		local guardado = jugador:GetAttribute("EstadoGuardado")
		if jugador:GetAttribute("ModoGuardado") == "Sesion" then
			indicador("Progreso de esta sesión", "Lucero está contigo durante esta partida.", HIELO)
		elseif guardado == "Guardado" then
			indicador("Progreso guardado", "Lucero se queda en tu colección.", MENTA)
		elseif guardado == "Reintentando" then
			indicador("Volviendo a guardar", "Lucero ya se unió a tu colección.", ORO)
		end
	elseif fase == "Aterrizando" or fase == "Llegada" then
		objetivo.Text = "Cometa acaba de encontrar una chispa junto al molino."
	elseif lleva then
		objetivo.Text = "Lleva la chispa al farol. Protégela de las ráfagas con Pedernal."
		local cercaFarol = farol:FindFirstChild("Accion")
		if proteccion > 0 then
			indicador("Escudo activo", ("Protección durante %.1f s"):format(proteccion), HIELO)
		elseif cercaFarol and cercaFarol.Enabled and (root.Position - farol.Position).Magnitude <= 8.9 then
			indicador("Enciende el farol", interactuar .. "  ·  Colocar la chispa", ORO)
		elseif situacion == "En riesgo" or (viento == "Rafaga" and cercaDelViento(root.Position)) then
			indicador("¡Protege la chispa!",
				if recarga > 0 then ("Escudo listo en %.1f s"):format(recarga) else tecla .. "  ·  Escudo de Pedernal", CORAL)
		elseif situacion == "Alerta" or (viento == "Aviso" and cercaDelViento(root.Position)) then
			indicador("Se acerca una ráfaga",
				if recarga > 0 then ("Escudo listo en %.1f s"):format(recarga) else tecla .. "  ·  Escudo de Pedernal", ORO)
		end
	elseif situacion == "Apagada" then
		objetivo.Text = "La chispa volvió al pedestal. Recógela y protege su luz."
	else
		objetivo.Text = "Recoge la chispa que encontró Cometa junto al farol apagado."
		if (root.Position - chispa.Position).Magnitude <= 8.9 then
			indicador("La chispa está viva", interactuar .. "  ·  Recoger", ORO)
		end
	end
end

local relojHud = 0
RunService.PreRender:Connect(function(dt)
	if pendiente then
		if hoy() - pendiente.comienzo > 1.75 then
			pendiente = nil
		elseif jugador:GetAttribute("EnMolino") and molino:GetAttribute("TitularExpedicion") == jugador.UserId then
			local solicitud = pendiente
			pendiente = nil
			local bien, fallo = pcall(iniciarEscena, solicitud.evento, solicitud.comienzo, solicitud.duracion)
			if not bien then
				cerrarEscena()
				warn(fallo)
			end
		end
	end
	if escena then
		local esc = escena
		local t = math.max(0, hoy() - esc.comienzo)
		local _, humanoide = avatar()
		if not humanoide or humanoide.Health <= 0 or jugador:GetAttribute("EnCueva")
			or (esc.camara and workspace.CurrentCamera ~= esc.camara) then
			cerrarEscena()
		elseif t >= esc.duracion then
			terminarEscena()
		else
			local entrada = if not esc.camara then 0 elseif esc.llegada then 4.78 else 1.22
			local visible = escala((t - entrada) / 0.28) * escala((esc.duracion - t) / 0.2)
			letrero.GroupTransparency = 1 - visible
			sombra.BackgroundTransparency = 1 - visible * 0.75
			if esc.camara then
				if esc.llegada then
					pintarLlegada(esc, t)
				else
					pintarPremio(esc, t)
				end
			end
			return
		end
	end
	relojHud += dt
	if relojHud >= 0.07 then
		relojHud = 0
		mostrarMision()
	end
end)
