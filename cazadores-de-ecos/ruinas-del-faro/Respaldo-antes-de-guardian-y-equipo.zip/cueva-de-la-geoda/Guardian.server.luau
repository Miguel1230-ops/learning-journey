-- Segunda expedición de Cazadores de Ecos. Prueba individual para Roblox Studio.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")

local cueva = workspace:WaitForChild("CuevaDeLaGeoda")
local isla = workspace:WaitForChild("IslaDelViento")
local remoto = ReplicatedStorage:WaitForChild("AccionGeoda")
local guardian = cueva.Guardian
local cristal = guardian.CristalEspalda
local geoda = cueva.Geoda
local cometa = cueva.Cometa
local pedernal = cueva.Pedernal
local ruta = cueva.Ruta
local cristalAlto = cueva.CristalAlto
local MAX_VIDA = 3
local ROCA = Color3.fromRGB(100, 119, 151)
local VERDE = Color3.fromRGB(126, 250, 217)
local ORO = Color3.fromRGB(255, 214, 111)
local CORAL = Color3.fromRGB(255, 116, 96)
local VIOLETA = Color3.fromRGB(190, 131, 255)
local AZUL = Color3.fromRGB(128, 218, 255)
local PISO = 20.09
local DURACION_REVELACION = 3.3
local APERTURA_GEODA = 0.58

ruta.PuertaViento.Material = Enum.Material.SmoothPlastic
ruta.PuertaViento.Transparency = 0.72

local jugador
local fase = "Inicio"
local estado = "Acecha"
local vida = MAX_VIDA
local hazana = false
local selloEncendido = false
local proximo = "Embestida"
local hasta = 0
local siguientePulso = 0
local siguienteOrden = 0
local escudoHasta = 0
local siguienteDisparo = 0
local aviso
local proyectil
local defensaVisual
local puertaAbierta = false
local direccion = -Vector3.xAxis
local posicion = guardian.PrimaryPart.Position
local origenGuardian = posicion
local puntoAlto = cristalAlto.PrimaryPart.Position
local posCometa = cometa:GetPivot()
local posPedernal = pedernal:GetPivot()
local llevaCometa = false
local tienePedernal = false
local tieneRebote = false
local golpeo = false
local distanciaEmbestida = 0
local origenIsla
local revelacion
local revancha = false

local efectos = Instance.new("Folder")
efectos.Name = "Efectos"
efectos.Parent = cueva

local function reloj()
	return workspace:GetServerTimeNow()
end

local function parte(padre, nombre, tamano, marco, color, forma)
	local p = Instance.new("Part")
	p.Name = nombre
	p.Size = tamano
	p.CFrame = marco
	p.Color = color
	p.Material = Enum.Material.Neon
	p.Shape = forma or Enum.PartType.Block
	p.Anchored = true
	p.CanCollide = false
	p.CanTouch = false
	p.CanQuery = false
	p.CastShadow = false
	p.Parent = padre
	return p
end

local function plano(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function cerca(root, punto, alcance)
	return root and (root.Position - punto).Magnitude <= alcance
end

local function dentro(pos, zona)
	local a = zona.CFrame:PointToObjectSpace(pos)
	local b = zona.Size / 2
	return math.abs(a.X) <= b.X and math.abs(a.Y) <= b.Y and math.abs(a.Z) <= b.Z
end

local function avatar()
	local char = jugador and jugador.Character
	local h = char and char:FindFirstChildOfClass("Humanoid")
	local root = char and char:FindFirstChild("HumanoidRootPart")
	if root and h and h.Health > 0 then
		return root, h
	end
	return nil
end

local function informacion(titulo, pista)
	cueva:SetAttribute("Titulo", titulo)
	cueva:SetAttribute("Pista", pista)
end

local function cambiarFase(nueva, titulo, pista)
	fase = nueva
	cueva:SetAttribute("Fase", nueva)
	informacion(titulo, pista)
end

local function cambiarEstado(nuevo)
	estado = nuevo
	cueva:SetAttribute("EstadoGuardian", nuevo)
	cristal.Color = if nuevo == "Expuesto" then VERDE else ROCA
	cristal.Material = if nuevo == "Expuesto" then Enum.Material.Neon else Enum.Material.Slate
end

local function indicador(padre, nombre, verbo, distancia)
	local p = Instance.new("ProximityPrompt")
	p.Name = "Accion"
	p.ObjectText = nombre
	p.ActionText = verbo
	p.MaxActivationDistance = distancia
	p.ClickablePrompt = true
	p.RequiresLineOfSight = false
	p.Parent = padre
	return p
end

local trial = parte(isla, "PruebaDeLaGeoda", Vector3.new(1.7, 1.8, 1.7),
	CFrame.new(-51, 22.2, 4.55) * CFrame.Angles(0, 0, 0.4), VIOLETA)
local portal = parte(isla.Rutas, "PortalDeLaGeoda", Vector3.new(1.75, 1.85, 1.75),
	CFrame.new(87.15, 22.25, 9.25) * CFrame.Angles(0, 0, 0.4), VIOLETA)
local atajo = indicador(trial, "Cueva de la Geoda", "Probar con Cometa", 8.0)
local entrada = indicador(portal, "Expedición a la Geoda", "Entrar con Cometa", 7.5)
local reto = indicador(cueva.Totem, "Guardián de la Geoda", "Comenzar desafío", 8.5)
local volver = indicador(cueva.SalidaIsla, "Isla del Viento", "Volver a la isla", 7)
local abrir = indicador(geoda.Punto, "Geoda del guardián", "Abrir geoda", 8.5)
local descubrir = indicador(ruta.Baliza, "Mirador de la Geoda", "Encender baliza", 8.5)
local playa = isla:WaitForChild("MolinoDelViento"):WaitForChild("PlayaDespegue")
local seguirMolino = indicador(ruta.Baliza, "Mirador de la Geoda", "Seguir al Molino", 8.5)
seguirMolino.Name = "SeguirAlMolino"
seguirMolino.Enabled = false
local retornoLente = parte(cueva, "SalidaAlRefugio", Vector3.new(0.8, 2.05, 0.8),
	CFrame.new(346.95, 22.5, 9.1) * CFrame.Angles(0, 0, math.rad(29)), VERDE)
local salidaLente = indicador(retornoLente, "Refugio del Viento", "Volver con la lente", 7.5)
local lente = parte(geoda, "LenteDeLaGeoda", Vector3.new(0.18, 2.12, 2.12), CFrame.new(350, 24.2, 0),
	AZUL, Enum.PartType.Cylinder)
local aroLente = parte(geoda, "BordeDeLaLente", Vector3.new(0.135, 2.42, 2.42), CFrame.new(350.13, 24.2, 0),
	ORO, Enum.PartType.Cylinder)
lente.Transparency = 1
aroLente.Transparency = 1
retornoLente.Transparency = 1
salidaLente.Enabled = false
atajo.Enabled = RunService:IsStudio() and game.GameId == 0 and isla:GetAttribute("AtajosDePrueba") == true
trial.Transparency = if atajo.Enabled then 0 else 1
entrada.Enabled = false
abrir.Enabled = false
descubrir.Enabled = false

local function puedeUsar(quien, p, enCueva)
	local root = avatar()
	return quien == jugador and (quien:GetAttribute("EnCueva") == true) == enCueva
		and p.Enabled and cerca(root, p.Parent.Position, p.MaxActivationDistance + 0.65)
end

local function transparenciaOriginal(objeto)
	local partes = {}
	for _, hijo in ipairs(objeto:GetDescendants()) do
		if hijo:IsA("BasePart") then
			partes[hijo] = hijo.Transparency
		end
	end
	return partes
end

local pedernalPartes = transparenciaOriginal(pedernal)
local cristalPartes = transparenciaOriginal(cristalAlto)
local armadura = transparenciaOriginal(geoda.Caparazon)
local piezasGeoda = {}
for pieza in pairs(armadura) do
	local separacion = plano(pieza.Position - geoda.PrimaryPart.Position)
	piezasGeoda[pieza] = {
		marco = pieza.CFrame,
		direccion = if separacion.Magnitude > 0.1 then separacion.Unit else Vector3.yAxis,
	}
end

local function mostrar(partes, visible)
	for p, t in pairs(partes) do
		p.Transparency = if visible then t else 1
	end
end

local function animarGeoda(tiempo)
	if not revelacion then
		return
	end
	local edad = math.max(0, tiempo - revelacion.inicio)
	if revelacion.nuevo and not revelacion.rocaAbierta then
		local progreso = math.clamp((edad - APERTURA_GEODA) / 0.59, 0, 1)
		local vuelo = 1 - (1 - progreso) ^ 3
		for pieza, datos in pairs(piezasGeoda) do
			if edad < APERTURA_GEODA then
				local temblor = math.sin(edad * 38) * edad * 0.19
				pieza.CFrame = datos.marco + Vector3.new(temblor, 0, -temblor * 0.54)
			else
				local avance = datos.direccion * vuelo * 3.45
				pieza.CFrame = (datos.marco + avance + Vector3.yAxis * math.sin(vuelo * math.pi) * 1.65)
					* CFrame.Angles(vuelo * 0.35, 0, vuelo * 0.5)
				pieza.Transparency = armadura[pieza] + (1 - armadura[pieza]) * progreso
			end
		end
		revelacion.rocaAbierta = progreso >= 1
	end
	if edad >= APERTURA_GEODA then
		if not revelacion.visible then
			mostrar(pedernalPartes, true)
			revelacion.visible = true
		end
		local subida = 1 - (1 - math.clamp((edad - APERTURA_GEODA) / 0.73, 0, 1)) ^ 3
		local altura = -0.95 + subida * 2.52 + math.sin(edad * 4) * 0.12 * subida
		local lugar = posPedernal.Position + Vector3.yAxis * altura
		local frente = CFrame.lookAt(lugar, lugar + Vector3.new(-1, 0, -0.72))
		pedernal:PivotTo(frente * CFrame.Angles(0, (1 - subida) * 0.68, (1 - subida) * 0.13))
	end
	if edad >= DURACION_REVELACION then
		revelacion = nil
	end
end

local function orientar()
	guardian:PivotTo(CFrame.lookAt(posicion, posicion + direccion))
end

local function quitarAviso()
	if aviso then
		aviso:Destroy()
		aviso = nil
	end
end

local function quitarProyectil()
	if proyectil then
		proyectil.pieza:Destroy()
		proyectil = nil
	end
end

local function moverA(quien, destino)
	local char = quien.Character
	local root = char and char:FindFirstChild("HumanoidRootPart")
	if root then
		char:PivotTo(destino)
		root.AssemblyLinearVelocity = Vector3.zero
	end
end

local function restaurarEntrada()
	reto.ActionText = if tienePedernal then "Jugar revancha" else "Comenzar desafío"
	reto.Enabled = true
	abrir.Enabled = false
	lente.Transparency = 1
	aroLente.Transparency = 1
	retornoLente.Transparency = 1
	salidaLente.Enabled = false
	posicion = origenGuardian
	direccion = -Vector3.xAxis
	orientar()
	cambiarEstado("Acecha")
	cambiarFase("Inicio", "Cueva de la Geoda", "Acércate al tótem. Cometa conoce el punto débil del guardián.")
end

local function entrarCueva(quien, p)
	if not puedeUsar(quien, p, false) or isla:GetAttribute("Fase") == "Defensa"
		or quien:GetAttribute("EnMolino") or quien:GetAttribute("EnFaro") then
		return
	end
	local root, h = avatar()
	origenIsla = root.CFrame
	llevaCometa = quien:GetAttribute("Cometa") == true or (p == atajo and RunService:IsStudio())
	if not llevaCometa then
		return
	end
	quien:SetAttribute("EnCueva", true)
	h.Health = h.MaxHealth
	moverA(quien, cueva.Entrada.CFrame)
	cometa:PivotTo(posCometa)
	if tienePedernal then
		pedernal:PivotTo(cueva.Entrada.CFrame * CFrame.new(-3, 2.4, -1))
		mostrar(pedernalPartes, true)
	end
	if fase == "Derrota" then
		restaurarEntrada()
	end
end

atajo.Triggered:Connect(function(quien)
	entrarCueva(quien, atajo)
end)
entrada.Triggered:Connect(function(quien)
	entrarCueva(quien, entrada)
end)
volver.Triggered:Connect(function(quien)
	if not puedeUsar(quien, volver, true) then
		return
	end
	quien:SetAttribute("EnCueva", false)
	quien:SetAttribute("EscudoHasta", 0)
	escudoHasta = 0
	quitarProyectil()
	if fase == "Combate" then
		quitarAviso()
		restaurarEntrada()
	end
	moverA(quien, origenIsla or isla.Inicio.CFrame * CFrame.new(0, 3.4, 0))
end)

seguirMolino.Triggered:Connect(function(quien)
	if not puedeUsar(quien, seguirMolino, true) or fase == "Combate"
		or not quien:GetAttribute("MiradorGeoda") or not quien:GetAttribute("Pedernal") then
		return
	end
	quien:SetAttribute("EnCueva", false)
	quien:SetAttribute("EscudoHasta", 0)
	escudoHasta = 0
	quitarProyectil()
	local posicion = Vector3.new(playa.Position.X, 23.65, playa.Position.Z - 1.12)
	local llegadaMolino = playa.Parent.Llegada.Position
	moverA(quien, CFrame.lookAt(posicion, Vector3.new(llegadaMolino.X, posicion.Y, llegadaMolino.Z)))
end)

salidaLente.Triggered:Connect(function(quien)
	if fase ~= "Revancha" or not puedeUsar(quien, salidaLente, true) then
		return
	end
	quien:SetAttribute("EnCueva", false)
	quien:SetAttribute("EscudoHasta", 0)
	escudoHasta = 0
	quitarProyectil()
	local refugio = isla:FindFirstChild("RefugioDelViento")
	local farero = refugio and refugio:FindFirstChild("PuntoFarero")
	local llegada = Vector3.new(82.4, 23.65, 3.1)
	moverA(quien, if farero then CFrame.lookAt(llegada, Vector3.new(farero.Position.X, llegada.Y, farero.Position.Z))
		else origenIsla or isla.Inicio.CFrame * CFrame.new(0, 3.4, 0))
end)

local function explosion(centro, tono, radio, tiempo)
	local a = CFrame.new(centro) * CFrame.Angles(0, 0, math.pi / 2)
	local p = parte(efectos, "Pulso", Vector3.new(0.12, 1.5, 1.5), a, tono, Enum.PartType.Cylinder)
	p.Transparency = 0.25
	local tween = TweenService:Create(p, TweenInfo.new(tiempo), {
		Size = Vector3.new(0.12, 2 * radio, 2 * radio),
		Transparency = 1,
	})
	tween.Completed:Once(function()
		p:Destroy()
	end)
	tween:Play()
end

local function comenzar(quien)
	if not puedeUsar(quien, reto, true) or fase == "Combate" or fase == "Gana" then
		return
	end
	local _, h = avatar()
	h.Health = h.MaxHealth
	revancha = tienePedernal
	vida = MAX_VIDA
	hazana = false
	proximo = "Embestida"
	posicion = origenGuardian
	direccion = -Vector3.xAxis
	orientar()
	quitarAviso()
	quitarProyectil()
	mostrar(cristalPartes, true)
	reto.Enabled = false
	abrir.Enabled = false
	descubrir.Enabled = false
	retornoLente.Transparency = 1
	salidaLente.Enabled = false
	cueva:SetAttribute("VidaGuardian", vida)
	cueva:SetAttribute("Hazana", false)
	cambiarEstado("Acecha")
	cambiarFase("Combate", "Guardián de la Geoda", "Acércate. Llama a Cometa cuando veas la línea de embestida.")
end
reto.Triggered:Connect(comenzar)

local function fracasar()
	quitarAviso()
	cambiarEstado("Acecha")
	reto.ActionText = "Reintentar combate"
	reto.Enabled = true
	cambiarFase("Derrota", "Cometa te espera en la entrada", "Vuelve al tótem para intentarlo otra vez.")
end

local function recuperar(duracion)
	quitarAviso()
	cambiarEstado("Recupera")
	hasta = reloj() + duracion
end

local function mostrarPuntoDebil()
	quitarAviso()
	cambiarEstado("Expuesto")
	hasta = reloj() + 3.10
	informacion("¡Cristal expuesto!", "Acércate al cristal de su espalda y usa tu ráfaga.")
	explosion(Vector3.new(posicion.X, PISO, posicion.Z), VERDE, 8.3, 0.34)
end

local function avisar(destino, tiempo)
	local delta = plano(destino - posicion)
	if delta.Magnitude > 0.1 then
		direccion = delta.Unit
	end
	orientar()
	local base = Vector3.new(posicion.X, PISO, posicion.Z)
	if proximo == "Embestida" then
		proximo = "Onda"
		distanciaEmbestida = 23
		local centro = base + direccion * (distanciaEmbestida / 2)
		aviso = parte(efectos, "LineaDeEmbestida", Vector3.new(6.75, 0.10, distanciaEmbestida),
			CFrame.lookAt(centro, centro + direccion), CORAL)
		cambiarEstado("Aviso")
		informacion("¡Embestida!", "Llama a Cometa para distraer al guardián o sal de la línea.")
		hasta = tiempo + 1.32
	else
		proximo = "Embestida"
		aviso = parte(efectos, "AreaDeOnda", Vector3.new(0.12, 27, 27),
			CFrame.new(base) * CFrame.Angles(0, 0, math.pi / 2), VIOLETA, Enum.PartType.Cylinder)
		cambiarEstado("Onda")
		informacion("¡Onda de piedra!", "Salta justo antes del golpe o sal del círculo morado.")
		hasta = tiempo + 0.96
	end
	aviso.Transparency = 0.29
end

local function limitarArena(p)
	return Vector3.new(math.clamp(p.X, 288.5, 346), p.Y, math.clamp(p.Z, -23.6, 23.6))
end

local function jugarCombate(root, h, dt, tiempo)
	if estado == "Acecha" then
		local d = plano(root.Position - posicion)
		local alcance = if proximo == "Embestida" then 18.5 else 11.2
		if d.Magnitude <= alcance then
			avisar(root.Position, tiempo)
		elseif d.Magnitude > 0.1 then
			direccion = d.Unit
			posicion = limitarArena(posicion + direccion * math.min(d.Magnitude, 10.8 * dt))
			orientar()
		end
	elseif estado == "Aviso" and tiempo >= hasta then
		quitarAviso()
		golpeo = false
		cambiarEstado("Embestida")
	elseif estado == "Onda" and tiempo >= hasta then
		local d = plano(root.Position - posicion).Magnitude
		if d < 13.5 and root.Position.Y < 26.7 then
			h:TakeDamage(24)
		end
		explosion(Vector3.new(posicion.X, PISO, posicion.Z), VIOLETA, 13.5, 0.28)
		recuperar(1.2)
	elseif estado == "Embestida" then
		local avance = math.min(distanciaEmbestida, 36 * dt)
		posicion = limitarArena(posicion + direccion * avance)
		distanciaEmbestida -= avance
		orientar()
		if not golpeo and root.Position.Y < 27 and plano(root.Position - posicion).Magnitude < 3.9 then
			golpeo = true
			h:TakeDamage(34)
		end
		if not hazana and plano(posicion - puntoAlto).Magnitude < 4.9 then
			hazana = true
			cueva:SetAttribute("Hazana", true)
			mostrar(cristalPartes, false)
			explosion(puntoAlto, ORO, 9.2, 0.43)
			recuperar(1.8)
			informacion("¡Hazaña del cristal alto!", "Vence al guardián para que Pedernal aprenda Rebote.")
		elseif distanciaEmbestida <= 0 then
			recuperar(1.14)
		end
	elseif estado == "Expuesto" and tiempo >= hasta then
		recuperar(0.82)
		informacion("El guardián volvió a cubrirse", "Puedes distraerlo en su próxima embestida.")
	elseif estado == "Recupera" and tiempo >= hasta then
		cambiarEstado("Acecha")
		informacion("Guardián de la Geoda", "Aléjate de la onda. Llama a Cometa en la siguiente embestida.")
	end
end

local function ganar()
	quitarAviso()
	cambiarEstado("Recupera")
	guardian:PivotTo(CFrame.lookAt(posicion, posicion + direccion) * CFrame.Angles(math.rad(-22), 0, 0))
	local muestraLente = revancha and not jugador:GetAttribute("LenteGeoda")
	abrir.ActionText = if muestraLente then "Recoger lente" elseif revancha then "Canalizar geoda" else "Abrir geoda"
	if muestraLente then
		lente.Transparency = 0.15
		aroLente.Transparency = 0.08
	end
	abrir.Enabled = true
	cambiarFase("Gana", "¡Guardián derrotado!", if muestraLente then "Algo brilla en el pedestal. Acércate para recoger la lente."
		elseif hazana then "La geoda y la hazaña del cristal te esperan."
		else "El tesoro está a salvo. Acércate a la geoda.")
end

local function rafaga(root, tiempo)
	if fase ~= "Combate" or tiempo < siguientePulso then
		return
	end
	siguientePulso = tiempo + 0.83
	jugador:SetAttribute("PulsoCuevaListoEn", siguientePulso)
	local base = root.Position - Vector3.new(0, 2.4, 0)
	explosion(base, VERDE, 12.3, 0.22)
	local lado = plano(root.Position - posicion)
	if estado ~= "Expuesto" or not cerca(root, cristal.Position, 12.6)
		or (lado.Magnitude > 0.1 and direccion:Dot(lado.Unit) > 0.35) then
		if estado == "Expuesto" then
			informacion("Acierta al cristal", "Hay una abertura en la espalda. Acércate y usa la ráfaga.")
		elseif estado ~= "Aviso" and estado ~= "Onda" and lado.Magnitude < 13.8 then
			informacion("La ráfaga rebotó en la armadura", "Llama a Cometa cuando aparezca la línea de embestida.")
		end
		return
	end
	vida -= 1
	cueva:SetAttribute("VidaGuardian", vida)
	explosion(cristal.Position, ORO, 5.5, 0.32)
	if vida == 0 then
		ganar()
	else
		recuperar(1.08)
		informacion("¡Rompiste una capa de armadura!", "Quedan " .. vida .. " golpes al cristal.")
	end
end

local function orden(root, tiempo)
	if fase ~= "Combate" or not llevaCometa or tiempo < siguienteOrden then
		return
	end
	local haciaJugador = plano(root.Position - posicion)
	if estado ~= "Aviso" or haciaJugador.Magnitude > 26 or haciaJugador.Magnitude < 0.2 then
		siguienteOrden = tiempo + 0.24
		jugador:SetAttribute("OrdenCometaListaEn", siguienteOrden)
		return
	end
	direccion = -haciaJugador.Unit
	orientar()
	siguienteOrden = tiempo + 0.75
	jugador:SetAttribute("OrdenCometaListaEn", siguienteOrden)
	mostrarPuntoDebil()
end

local function escudo(root, tiempo)
	if not tienePedernal or fase == "Combate" or tiempo < escudoHasta then
		return
	end
	escudoHasta = tiempo + 3.3
	jugador:SetAttribute("EscudoHasta", escudoHasta)
	explosion(root.Position - Vector3.new(0, 2.5, 0), AZUL, 4.0, 0.33)
	if fase == "Salida" then
		informacion("Escudo activo", "Cruza el viento y toca la baliza del mirador.")
	end
end

remoto.OnServerEvent:Connect(function(quien, tipo)
	if quien ~= jugador or not quien:GetAttribute("EnCueva") then
		return
	end
	local root = avatar()
	if root and (root.Position - cueva.Entrada.Position).Magnitude <= 137 then
		local t = reloj()
		if tipo == "Rafaga" then
			rafaga(root, t)
		elseif tipo == "Cometa" then
			orden(root, t)
		elseif tipo == "Escudo" then
			escudo(root, t)
		end
	end
end)

abrir.Triggered:Connect(function(quien)
	if fase ~= "Gana" or not puedeUsar(quien, abrir, true) then
		return
	end
	abrir.Enabled = false
	local nuevo = not tienePedernal
	local nuevaMutacion = hazana and not tieneRebote
	tienePedernal = true
	if hazana then
		tieneRebote = true
		quien:SetAttribute("Rebote", true)
	end
	quien:SetAttribute("TesoroRevelado", true)
	quien:SetAttribute("Pedernal", true)
	reto.ActionText = "Jugar revancha"
	reto.Enabled = true
	descubrir.Enabled = not quien:GetAttribute("MiradorGeoda")
	if revancha then
		local nuevaLente = not quien:GetAttribute("LenteGeoda")
		quien:SetAttribute("LenteGeoda", true)
		lente.Transparency = 1
		aroLente.Transparency = 1
		retornoLente.Transparency = 0.1
		salidaLente.Enabled = true
		cambiarFase("Revancha", if nuevaLente then "¡Lente de la Geoda conseguida!" else "¡Revancha ganada!",
			"La salida verde te lleva al farero. Él sabe cómo montar la lente en las ruinas.")
	else
		cambiarFase("Salida", if hazana then "¡Pedernal aprendió Rebote!" else "¡Eco Pedernal rescatado!",
			"Usa su escudo junto al pasadizo de viento para abrirte camino.")
	end
	if nuevo or nuevaMutacion then
		local inicio = reloj() + 0.17
		revelacion = { inicio = inicio, nuevo = nuevo, rocaAbierta = false, visible = false }
		pedernal:PivotTo(posPedernal)
		mostrar(pedernalPartes, false)
		remoto:FireClient(quien, "Revelacion", inicio, nuevaMutacion, APERTURA_GEODA, DURACION_REVELACION)
	else
		explosion(geoda.PrimaryPart.Position, ORO, 9.5, 0.48)
	end
end)

descubrir.Triggered:Connect(function(quien)
	if not tienePedernal or not puedeUsar(quien, descubrir, true) then
		return
	end
	descubrir.Enabled = false
	ruta.Baliza.Color = ORO
	quien:SetAttribute("MiradorGeoda", true)
	cambiarFase("Final", "El molino se ve desde aquí", "Usa la baliza para seguir al Molino. Desde la playa podrás despegar con Cometa.")
end)

local function actualizarSalida(root, h, tiempo, dt)
	local activo = tiempo < escudoHasta
	local d = ruta.PuertaViento.CFrame:PointToObjectSpace(root.Position)
	local cruzando = math.abs(d.X) < 1.5 and math.abs(d.Z) < ruta.PuertaViento.Size.Z / 2 + 1
	puertaAbierta = activo or (puertaAbierta and cruzando)
	ruta.PuertaViento.CanCollide = not puertaAbierta
	ruta.PuertaViento.Transparency = if puertaAbierta then 0.93 else 0.72

	if activo and not defensaVisual then
		defensaVisual = parte(efectos, "EscudoPedernal", Vector3.new(6.5, 6.5, 6.5),
			CFrame.new(root.Position), AZUL, Enum.PartType.Ball)
		defensaVisual.Transparency = 0.83
	elseif not activo and defensaVisual then
		defensaVisual:Destroy()
		defensaVisual = nil
	end
	if defensaVisual then
		defensaVisual.Position = root.Position
	end

	if not proyectil and tiempo >= siguienteDisparo and dentro(root.Position, ruta.ZonaViento) then
		local origen = ruta.PuntoProyectil.Position
		local pieza = parte(efectos, "ProyectilDeViento", Vector3.new(1.6, 1.6, 1.6), CFrame.new(origen),
			VIOLETA, Enum.PartType.Ball)
		proyectil = { pieza = pieza, avanza = -Vector3.xAxis, reflejado = false }
		siguienteDisparo = tiempo + 2.6
	end
	if not proyectil then
		return
	end

	local p = proyectil.pieza
	if proyectil.reflejado then
		local delta = ruta.SelloRebote.Position - p.Position
		if delta.Magnitude < 1.55 then
			quitarProyectil()
			if not selloEncendido then
				selloEncendido = true
				cueva:SetAttribute("SelloEncendido", true)
				jugador:SetAttribute("SelloGeoda", true)
				ruta.SelloRebote.Color = ORO
				explosion(ruta.SelloRebote.Position, ORO, 7.5, 0.54)
				informacion("¡Pedernal devolvió el disparo!", "La mutación encendió el sello oculto del mirador.")
			end
			return
		end
		proyectil.avanza = delta.Unit
	end
	p.Position += proyectil.avanza * (if proyectil.reflejado then 26 else 16) * dt
	if not proyectil.reflejado and cerca(root, p.Position, 3.05) then
		if activo and tieneRebote then
			proyectil.reflejado = true
			p.Color = ORO
		else
			if not activo then
				h:TakeDamage(15)
				root:ApplyImpulse(Vector3.new(-19, 5, 0) * root.AssemblyMass)
			end
			quitarProyectil()
		end
	elseif p.Position.X < 350 then
		quitarProyectil()
	end
end

local function acompanar(root)
	local derecha = root.CFrame.RightVector
	local frente = root.CFrame.LookVector
	local t = reloj()
	local sitio = root.Position + derecha * 3.5 - frente * 2.1
		+ Vector3.new(0, 2 + math.sin(t * 3.8) * 0.25, 0)
	if estado == "Expuesto" and fase == "Combate" then
		sitio = posicion + direccion * 6 + Vector3.new(0, 3.7, 0)
	end
	cometa:PivotTo(cometa:GetPivot():Lerp(CFrame.lookAt(sitio, sitio + frente), 0.25))
	if tienePedernal and not revelacion then
		local piedra = root.Position - derecha * 3.2 - frente * 2.0
			+ Vector3.new(0, 1.3 + math.sin(t * 2.6) * 0.2, 0)
		pedernal:PivotTo(pedernal:GetPivot():Lerp(CFrame.lookAt(piedra, piedra + frente), 0.24))
	end
end

local function recibir(nuevo)
	if jugador then
		return
	end
	jugador = nuevo
	for _, atributo in ipairs({ "EnCueva", "Pedernal", "Rebote", "TesoroRevelado", "MiradorGeoda" }) do
		if nuevo:GetAttribute(atributo) == nil then
			jugador:SetAttribute(atributo, false)
		end
	end
	for _, atributo in ipairs({ "PulsoCuevaListoEn", "OrdenCometaListaEn", "EscudoHasta" }) do
		jugador:SetAttribute(atributo, 0)
	end
	local function recuperarProgreso()
		if nuevo:GetAttribute("Pedernal") and not tienePedernal then
			tienePedernal = true
			mostrar(armadura, false)
			reto.ActionText = "Jugar revancha"
		end
		if nuevo:GetAttribute("Rebote") then
			tieneRebote = true
		end
		if nuevo:GetAttribute("SelloGeoda") and not selloEncendido then
			selloEncendido = true
			cueva:SetAttribute("SelloEncendido", true)
			ruta.SelloRebote.Color = ORO
		end
	end
	for _, atributo in ipairs({ "ProgresoRevision", "Pedernal", "Rebote", "SelloGeoda" }) do
		nuevo:GetAttributeChangedSignal(atributo):Connect(recuperarProgreso)
	end
	recuperarProgreso()
	jugador.CharacterAdded:Connect(function(char)
		if not nuevo:GetAttribute("EnCueva") then
			return
		end
		local root = char:WaitForChild("HumanoidRootPart", 10)
		if root and nuevo:GetAttribute("EnCueva") then
			moverA(nuevo, cueva.Entrada.CFrame)
		end
	end)
end

orientar()
mostrar(pedernalPartes, false)
cambiarEstado("Acecha")
cambiarFase("Inicio", "Cueva de la Geoda", "Busca el tótem para desafiar al guardián. Cometa te acompaña.")
cueva:SetAttribute("VidaGuardian", MAX_VIDA)
cueva:SetAttribute("MaxVidaGuardian", MAX_VIDA)
cueva:SetAttribute("Hazana", false)
cueva:SetAttribute("SelloEncendido", false)
Players.PlayerAdded:Connect(recibir)
for _, conectado in ipairs(Players:GetPlayers()) do
	recibir(conectado)
end

while true do
	local dt = math.min(task.wait(0.055), 0.115)
	local t = reloj()
	animarGeoda(t)
	if jugador then
		local enCueva = jugador:GetAttribute("EnCueva") == true
		seguirMolino.Enabled = enCueva and not descubrir.Enabled and fase ~= "Combate"
			and jugador:GetAttribute("MiradorGeoda") == true and jugador:GetAttribute("Pedernal") == true
		entrada.Enabled = not enCueva and jugador:GetAttribute("Cometa") == true
		if enCueva then
			local root, h = avatar()
			if fase == "Combate" and not root then
				fracasar()
			elseif root then
				if fase == "Combate" then
					jugarCombate(root, h, dt, t)
				elseif tienePedernal then
					actualizarSalida(root, h, t, dt)
				end
				acompanar(root)
			end
		elseif defensaVisual then
			defensaVisual:Destroy()
			defensaVisual = nil
		end
	end
end
