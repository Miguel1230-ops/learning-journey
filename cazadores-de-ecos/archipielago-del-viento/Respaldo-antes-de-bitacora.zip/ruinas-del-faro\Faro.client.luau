local Players = game:GetService("Players")
local ContextActionService = game:GetService("ContextActionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local jugador = Players.LocalPlayer
local faro = workspace:WaitForChild("IslaDelViento"):WaitForChild("RuinasDelFaro")
local accion = ReplicatedStorage:WaitForChild("AccionFaro")
local refugio = ReplicatedStorage:WaitForChild("AccionRefugio")
local noche = Color3.fromRGB(17, 28, 44)
local claro = Color3.fromRGB(248, 246, 236)
local suave = Color3.fromRGB(202, 219, 233)
local agua = Color3.fromRGB(141, 232, 218)

local function crear(clase, padre, props)
	local objeto = Instance.new(clase)
	for nombre, valor in pairs(props) do
		objeto[nombre] = valor
	end
	objeto.Parent = padre
	return objeto
end

local gui = crear("ScreenGui", jugador:WaitForChild("PlayerGui"), {
	Name = "RuinasDelFaroHUD", ResetOnSpawn = false, DisplayOrder = 11,
	ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets, Enabled = false,
})
local tarjeta = crear("Frame", gui, {
	Name = "Objetivo", Size = UDim2.new(1, -30, 0, 77), Position = UDim2.fromOffset(14, 9),
	BackgroundColor3 = noche, BackgroundTransparency = 0.08, BorderSizePixel = 0,
})
crear("UISizeConstraint", tarjeta, { MaxSize = Vector2.new(326, 77) })
crear("UICorner", tarjeta, { CornerRadius = UDim.new(0, 11) })
crear("UIStroke", tarjeta, { Color = agua, Transparency = 0.63 })
local titulo = crear("TextLabel", tarjeta, {
	Name = "Titulo", Position = UDim2.fromOffset(12, 7), Size = UDim2.new(1, -24, 0, 23),
	BackgroundTransparency = 1, Font = Enum.Font.GothamBold, TextColor3 = agua, TextSize = 16,
	TextXAlignment = Enum.TextXAlignment.Left, TextTruncate = Enum.TextTruncate.AtEnd,
})
local pista = crear("TextLabel", tarjeta, {
	Name = "Pista", Position = UDim2.fromOffset(12, 33), Size = UDim2.new(1, -24, 0, 38),
	BackgroundTransparency = 1, Font = Enum.Font.GothamMedium, TextColor3 = suave, TextSize = 12,
	TextXAlignment = Enum.TextXAlignment.Left, TextWrapped = true,
})
local luz = crear("TextButton", gui, {
	Name = "Iluminar", AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -20),
	Size = UDim2.fromOffset(192, 47), BackgroundColor3 = noche, BorderSizePixel = 0, Visible = false,
	Text = "Iluminar", Font = Enum.Font.GothamBold, TextSize = 14, TextColor3 = claro,
})
crear("UICorner", luz, { CornerRadius = UDim.new(0, 10) })
crear("UIStroke", luz, { Color = agua, Transparency = 0.42 })

local function raiz()
	local c = jugador.Character
	local h = c and c:FindFirstChildOfClass("Humanoid")
	return if h and h.Health > 0 then c:FindFirstChild("HumanoidRootPart") else nil
end

local function cercaDelRastro(root)
	return root and jugador:GetAttribute("EnFaro") and faro:GetAttribute("TitularExpedicion") == jugador.UserId
		and not faro:GetAttribute("RastroRevelado")
		and (root.Position - faro.Rastro.Position).Magnitude <= 13
end

local espejos = {}
for _, soporte in {faro.Girar, faro.Montura, faro.Prisma} do
	table.insert(espejos, soporte:WaitForChild("Accion"))
end
local accesoLosa = faro.Rastro:WaitForChild("Accion")
local accesoCamara = faro.Prisma:WaitForChild("CaminoDePrisma")
local regreso = faro.Regreso:WaitForChild("Accion")
local salida = faro.SalidaTerraza:WaitForChild("Accion")
local function actualizarAccesos()
	local dentro = jugador:GetAttribute("EnFaro") == true
	local titular = dentro and faro:GetAttribute("TitularExpedicion") == jugador.UserId
	local viaPrisma = dentro and jugador:GetAttribute("Prisma") == true and jugador:GetAttribute("FaroEncendido") == true
	for _, prompt in espejos do
		prompt.Enabled = titular and prompt:GetAttribute("Disponible") == true
	end
	accesoLosa.Enabled, accesoCamara.Enabled = viaPrisma, viaPrisma
	regreso.Enabled = dentro
	salida.Enabled = viaPrisma or (titular and faro:GetAttribute("RastroRevelado") == true)
end
for _, prompt in espejos do
	prompt:GetAttributeChangedSignal("Disponible"):Connect(actualizarAccesos)
	prompt:GetPropertyChangedSignal("Enabled"):Connect(actualizarAccesos)
end
for _, atributo in {"EnFaro", "Prisma", "FaroEncendido"} do
	jugador:GetAttributeChangedSignal(atributo):Connect(actualizarAccesos)
end
faro:GetAttributeChangedSignal("TitularExpedicion"):Connect(actualizarAccesos)
faro:GetAttributeChangedSignal("RastroRevelado"):Connect(actualizarAccesos)
actualizarAccesos()

-- La luz que alguien ya ganó sigue viéndose desde su torre cuando el
-- siguiente turno vuelve a preparar el espejo para otro explorador.
local linterna = faro:WaitForChild("Linterna")
local haz = linterna:WaitForChild("HazDelMolino")
local cristalPropio = linterna:Clone()
cristalPropio:ClearAllChildren()
cristalPropio.Name = "LinternaDescubierta"
cristalPropio.Color = Color3.fromRGB(255, 203, 126)
cristalPropio.Material = Enum.Material.Neon
cristalPropio.Transparency = .08
cristalPropio.CanCollide, cristalPropio.CanQuery, cristalPropio.CanTouch = false, false, false
local luzPropia = linterna:WaitForChild("Luz"):Clone()
luzPropia.Enabled = true
luzPropia.Parent = cristalPropio
local hazPropio = haz:Clone()
hazPropio.Width1, hazPropio.Enabled = 7.3, true
hazPropio.Parent = cristalPropio
local function recordarLinterna()
	local propia = jugador:GetAttribute("FaroEncendido") == true and not haz.Enabled
	linterna.LocalTransparencyModifier = if propia then 1 else 0
	cristalPropio.Parent = if propia then faro else nil
end
jugador:GetAttributeChangedSignal("FaroEncendido"):Connect(recordarLinterna)
haz:GetPropertyChangedSignal("Enabled"):Connect(recordarLinterna)
recordarLinterna()

local function pedirLuz()
	if not cercaDelRastro(raiz()) then
		return false
	end
	accion:FireServer("Lucero")
	return true
end

luz.Activated:Connect(pedirLuz)
ContextActionService:BindActionAtPriority("LuzDeLucero", function(_, estado)
	if estado == Enum.UserInputState.Begin and pedirLuz() then
		return Enum.ContextActionResult.Sink
	end
	return Enum.ContextActionResult.Pass
end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.C, Enum.KeyCode.ButtonR1)

local despegueHasta = 0
local reintento = false
accion.OnClientEvent:Connect(function(evento)
	if evento == "ReintentarLlegada" then
		reintento = true
		despegueHasta = os.clock() + 12
	end
end)
refugio.OnClientEvent:Connect(function(evento, ok)
	if evento ~= "SalidaAlFaro" or not ok then
		return
	end
	reintento = false
	despegueHasta = os.clock() + 12
	task.delay(0.15, function()
		local root = raiz()
		local cam = workspace.CurrentCamera
		if root and cam and (root.Position - faro.Despegue.Position).Magnitude < 8 then
			local rumbo = (faro.Llegada.Position - faro.Despegue.Position) * Vector3.new(1, 0, 1)
			if rumbo.Magnitude > 0.1 then
				cam.CFrame = CFrame.lookAt(root.Position + Vector3.yAxis * 5.85 - rumbo.Unit * 13, faro.Llegada.Position + Vector3.yAxis * 2)
			end
		end
	end)
end)

local transcurrido = 0
RunService.Heartbeat:Connect(function(dt)
	transcurrido += dt
	if transcurrido < 0.09 then
		return
	end
	transcurrido = 0
	local root = raiz()
	local dentro = jugador:GetAttribute("EnFaro") == true
	local espera = jugador:GetAttribute("EsperaFaro") == true and not dentro
	local cercaSalida = root and os.clock() < despegueHasta and (root.Position - faro.Despegue.Position).Magnitude < 16
	gui.Enabled = root ~= nil and (dentro or espera or cercaSalida == true)
	if not gui.Enabled then
		return
	end
	local mando = UserInputService:GetLastInputType().Name:match("^Gamepad") ~= nil
	local tactil = UserInputService.TouchEnabled and not mando
	tarjeta.Position = UDim2.fromOffset(14, if dentro then 9 else 85)
	titulo.Text = if dentro then faro:GetAttribute("TituloFaro") or "Ruinas del Faro"
		elseif reintento then "Vuelve a probar el vuelo" else "Despegue hacia el faro"
	pista.Text = if dentro then faro:GetAttribute("PistaFaro") or ""
		else if tactil then "Salta y toca Planeo. Aterriza sobre la losa entre los pilares."
		elseif mando then "Salta y pulsa Y. Aterriza sobre la losa entre los pilares."
		else "Salta y pulsa F. Aterriza sobre la losa entre los pilares."
	luz.Visible = dentro and cercaDelRastro(root) == true
	if espera then
		titulo.Text = "El espejo está ocupado"
		pista.Text = "Espera en la losa de llegada. Tendrás tu turno cuando el otro explorador termine."
		return
	end
	local etapa = jugador:GetAttribute("RescateNimbo")
	if dentro and etapa then
		local aros = jugador:GetAttribute("ArosNimbo") or 0
		if etapa == "Subiendo" then
			titulo.Text, pista.Text = "Elevador de Prisma", "Mira los tres aros. El huevo está en la nube más allá del último."
		elseif etapa == "Caida" then
			titulo.Text, pista.Text = "Alas plegadas", "Aterriza en el nido o vuelve a intentarlo desde el balcón."
		elseif etapa == "Balcon" then
			titulo.Text, pista.Text = "Nido de tormenta", "Lánzate desde el borde dorado. Tres aros dan una oportunidad de Aurora (20 %)."
		elseif etapa == "Vuelo" then
			titulo.Text = ("Aros de Prisma   %d / 3"):format(aros)
			pista.Text = if tactil then "Dirige el planeador. Toca Plegar para cerrar las alas."
				elseif mando then "Dirige el planeador. Pulsa Y para plegar las alas."
				else "Dirige el planeador con WASD. Pulsa F para plegar las alas."
		elseif etapa == "Nido" then
			titulo.Text = if aros == 3 then "¡Tres aros de Prisma!" else "Llegaste al nido"
			pista.Text = "Acércate al huevo para abrir el cascarón."
		elseif etapa == "Eclosion" then
			titulo.Text, pista.Text = "El cascarón se mueve…", "Algo está a punto de salir."
		elseif etapa == "Rescatado" then
			titulo.Text = if jugador:GetAttribute("UltimaEclosionAurora") then "Nimbo Aurora" else "Nimbo, Eco de tormenta"
			pista.Text = "Ya vuela contigo. Usa la salida del nido para volver a la torre."
		end
	elseif dentro and jugador:GetAttribute("Prisma") and jugador:GetAttribute("FaroEncendido") then
		titulo.Text, pista.Text = "El huevo de la tormenta", "Desde el cristal o las marcas de la orilla, usa Camino de Prisma para llegar al elevador."
	end
	luz.Text = if mando then "R1  ·  Iluminar con Lucero" elseif tactil then "Iluminar con Lucero" else "C  ·  Iluminar con Lucero"
end)
