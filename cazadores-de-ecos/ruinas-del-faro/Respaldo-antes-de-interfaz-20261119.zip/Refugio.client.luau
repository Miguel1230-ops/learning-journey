local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local jugador = Players.LocalPlayer
local playerGui = jugador:WaitForChild("PlayerGui")
local isla = workspace:WaitForChild("IslaDelViento")
local remoto = ReplicatedStorage:WaitForChild("AccionRefugio")
local Planeadores = require(ReplicatedStorage:WaitForChild("Planeadores"))
local refugio = isla:WaitForChild("RefugioDelViento")
local rostroFarero = refugio:WaitForChild("Farero"):WaitForChild("Rostro")
local avisoFarero = refugio:WaitForChild("PuntoFarero"):WaitForChild("Accion")

local NOCHE = Color3.fromRGB(14, 24, 37)
local PANEL = Color3.fromRGB(22, 35, 52)
local TARJETA = Color3.fromRGB(26, 42, 60)
local BORDE = Color3.fromRGB(66, 87, 108)
local PERLA = Color3.fromRGB(250, 248, 237)
local SUAVE = Color3.fromRGB(194, 210, 225)
local ORO = Color3.fromRGB(255, 211, 126)
local MENTA = Color3.fromRGB(142, 243, 209)
local HIELO = Color3.fromRGB(158, 222, 252)
local CORAL = Color3.fromRGB(255, 168, 153)
local PRECIO_ESCUDO = 60
local PRECIO_PLANEADOR = 65
local NIVEL_MINIMO = 2
local ALTA = Enum.ContextActionPriority.High.Value + 7

local function crear(clase, padre, atributos)
	local objeto = Instance.new(clase)
	for nombre, valor in pairs(atributos) do
		objeto[nombre] = valor
	end
	objeto.Parent = padre
	return objeto
end

local function contorno(objeto, radio, color)
	crear("UICorner", objeto, { CornerRadius = UDim.new(0, radio) })
	return crear("UIStroke", objeto, {
		ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
		Color = color,
		Transparency = 0.37,
	})
end

local function marco(padre, nombre, posicion, medida, color)
	return crear("Frame", padre, {
		Name = nombre, Position = posicion, Size = medida,
		BackgroundColor3 = color, BorderSizePixel = 0,
	})
end

local function etiqueta(padre, nombre, posicion, medida, texto, color, tamano, negrita)
	return crear("TextLabel", padre, {
		Name = nombre, Position = posicion, Size = medida,
		BackgroundTransparency = 1, Text = texto, TextColor3 = color,
		TextSize = tamano, TextXAlignment = Enum.TextXAlignment.Left, TextWrapped = true,
		Font = if negrita then Enum.Font.GothamBold else Enum.Font.GothamMedium,
	})
end

local function boton(padre, nombre, posicion, medida, texto, color)
	local b = crear("TextButton", padre, {
		Name = nombre, Position = posicion, Size = medida, BackgroundColor3 = color,
		Text = texto, TextColor3 = PERLA, TextSize = 14, Font = Enum.Font.GothamBold,
		BorderSizePixel = 0, TextWrapped = true, Selectable = true,
	})
	contorno(b, 10, BORDE)
	return b
end

local function barra(padre, nombre, posicion, medida, color)
	local pista = marco(padre, nombre, posicion, medida, BORDE)
	crear("UICorner", pista, { CornerRadius = UDim.new(1, 0) })
	local relleno = marco(pista, "Relleno", UDim2.fromOffset(0, 0), UDim2.fromScale(0, 1), color)
	crear("UICorner", relleno, { CornerRadius = UDim.new(1, 0) })
	return relleno
end

local function desplazar(padre, nombre)
	local area = crear("ScrollingFrame", padre, {
		Name = nombre, Position = UDim2.fromOffset(13, 77), Size = UDim2.new(1, -26, 1, -89),
		BackgroundTransparency = 1, BorderSizePixel = 0, ScrollBarThickness = 5,
		ScrollBarImageColor3 = BORDE, ScrollingDirection = Enum.ScrollingDirection.Y,
		AutomaticCanvasSize = Enum.AutomaticSize.Y, CanvasSize = UDim2.fromOffset(0, 0),
	})
	crear("UIPadding", area, { PaddingLeft = UDim.new(0, 2), PaddingRight = UDim.new(0, 9),
		PaddingTop = UDim.new(0, 2), PaddingBottom = UDim.new(0, 4) })
	return area
end

local gui = crear("ScreenGui", playerGui, {
	Name = "RefugioHUD", ResetOnSpawn = false, DisplayOrder = 18,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling, ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets,
})

local progreso = marco(gui, "Progreso", UDim2.new(1, -13, 0, 9), UDim2.fromOffset(240, 65), PANEL)
progreso.AnchorPoint = Vector2.new(1, 0)
progreso.Visible = false
contorno(progreso, 10, BORDE)
local nivel = etiqueta(progreso, "Nivel", UDim2.fromOffset(12, 5), UDim2.fromOffset(104, 22), "", PERLA, 15, true)
local saldo = etiqueta(progreso, "Monedas", UDim2.new(1, -133, 0, 5), UDim2.fromOffset(119, 22), "", ORO, 13, true)
saldo.TextXAlignment = Enum.TextXAlignment.Right
local xp = etiqueta(progreso, "XP", UDim2.fromOffset(12, 29), UDim2.fromOffset(112, 18), "", SUAVE, 12, false)
local progresoXP = barra(progreso, "BarraXP", UDim2.fromOffset(12, 51), UDim2.fromOffset(112, 4), MENTA)
local etiquetaEcos = boton(progreso, "AccesoEcos", UDim2.new(1, -113, 0, 27), UDim2.fromOffset(101, 32),
	"Inventario [I]", BORDE)
etiquetaEcos.TextSize = 12

local aviso = marco(gui, "Aviso", UDim2.new(1, -13, 0, 83), UDim2.fromOffset(242, 58), PANEL)
aviso.AnchorPoint = Vector2.new(1, 0)
aviso.Visible = false
contorno(aviso, 11, ORO)
local avisoTitulo = etiqueta(aviso, "Titulo", UDim2.fromOffset(12, 5), UDim2.new(1, -24, 0, 24), "", ORO, 14, true)
local avisoDetalle = etiqueta(aviso, "Detalle", UDim2.fromOffset(12, 28), UDim2.new(1, -24, 0, 24), "", PERLA, 13, false)

local menu = marco(gui, "Menu", UDim2.fromOffset(0, 0), UDim2.fromScale(1, 1), NOCHE)
menu.BackgroundTransparency = 1
menu.Visible = false
menu.ZIndex = 5
local fondo = crear("TextButton", menu, {
	Name = "Fondo", Size = UDim2.fromScale(1, 1), BackgroundColor3 = NOCHE,
	BackgroundTransparency = 0.29, BorderSizePixel = 0, Text = "", AutoButtonColor = false,
	Selectable = false,
})
local panel = marco(menu, "Panel", UDim2.fromScale(0.5, 0.5), UDim2.new(1, -24, 1, -26), NOCHE)
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Active = true
panel.ZIndex = 2
contorno(panel, 17, BORDE)
crear("UISizeConstraint", panel, { MaxSize = Vector2.new(836, 500) })
local titulo = etiqueta(panel, "Titulo", UDim2.fromOffset(17, 10), UDim2.new(1, -82, 0, 32), "", PERLA, 23, true)
local subtitulo = etiqueta(panel, "Subtitulo", UDim2.fromOffset(17, 44), UDim2.new(1, -82, 0, 22), "", SUAVE, 13, false)
local cerrar = boton(panel, "Cerrar", UDim2.new(1, -58, 0, 12), UDim2.fromOffset(44, 44), "×", TARJETA)
cerrar.TextSize = 23

local bocadillo = crear("BillboardGui", playerGui, {
	Name = "VozDelFarero", Adornee = rostroFarero, AlwaysOnTop = true,
	StudsOffsetWorldSpace = Vector3.new(0, 2.75, 0), Size = UDim2.fromOffset(352, 91),
	Enabled = false,
})
local recuadroFarero = marco(bocadillo, "Conversacion", UDim2.fromOffset(0, 0), UDim2.fromScale(1, 1), NOCHE)
contorno(recuadroFarero, 12, ORO)
local nombreFarero = etiqueta(recuadroFarero, "Nombre", UDim2.fromOffset(14, 6), UDim2.new(1, -28, 0, 20),
	"Farero del viento", ORO, 13, true)
nombreFarero.TextXAlignment = Enum.TextXAlignment.Center
local fraseFarero = etiqueta(recuadroFarero, "Frase", UDim2.fromOffset(13, 28), UDim2.new(1, -26, 1, -35),
	"", PERLA, 15, false)
fraseFarero.TextXAlignment = Enum.TextXAlignment.Center

local dialogo = marco(menu, "Dialogo", UDim2.new(0.5, 0, 1, -50), UDim2.new(1, -30, 0, 147), NOCHE)
dialogo.AnchorPoint = Vector2.new(0.5, 1)
dialogo.Visible = false
dialogo.ZIndex = 3
dialogo.BackgroundTransparency = 0.1
contorno(dialogo, 12, ORO)
crear("UISizeConstraint", dialogo, { MaxSize = Vector2.new(370, 147) })
local temaFaro = boton(dialogo, "Faro", UDim2.fromOffset(9, 7), UDim2.new(1, -18, 0, 41),
	"La señal del faro", TARJETA)
local temaMejoras = boton(dialogo, "Mejoras", UDim2.fromOffset(9, 53), UDim2.new(1, -18, 0, 41),
	"Ver mejoras", TARJETA)
local seguirSenal = boton(dialogo, "SeguirSenal", UDim2.fromOffset(9, 7), UDim2.new(1, -18, 0, 41),
	"Seguir la señal", ORO)
local volverDeSenal = boton(dialogo, "Volver", UDim2.fromOffset(9, 53), UDim2.new(1, -18, 0, 41),
	"Volver a hablar", TARJETA)
local despedir = boton(dialogo, "Despedir", UDim2.fromOffset(9, 99), UDim2.new(1, -18, 0, 41),
	"Hasta luego", PANEL)

local verEcos = boton(panel, "VerEcos", UDim2.fromOffset(15, 69), UDim2.new(0.5, -20, 0, 39),
	"Ecos", TARJETA)
local verPlaneadores = boton(panel, "VerPlaneadores", UDim2.new(0.5, 5, 0, 69), UDim2.new(0.5, -20, 0, 39),
	"Planeadores", TARJETA)
local inventario = desplazar(panel, "Inventario")
local grid = crear("UIGridLayout", inventario, {
	CellPadding = UDim2.fromOffset(12, 12), CellSize = UDim2.fromOffset(204, 262),
	FillDirectionMaxCells = 3, SortOrder = Enum.SortOrder.LayoutOrder,
})

local datosEcos = {
	{ nombre = "Cometa", lugar = "Isla del Viento", color = MENTA, habilidad = "Planea al saltar.",
		mutacion = "Vendaval", beneficio = "Asciende en corrientes de aire." },
	{ nombre = "Pedernal", lugar = "Cueva de la Geoda", color = HIELO, habilidad = "Su escudo te protege del viento.",
		mutacion = "Rebote", beneficio = "Devuelve los disparos del viento." },
	{ nombre = "Lucero", lugar = "Molino del Viento", color = ORO, habilidad = "Ilumina las huellas que llevan al faro.",
		mutacion = "Prisma", beneficio = "Divide su luz para revelar nuevos caminos." },
}

local fichas = {}
for i, eco in ipairs(datosEcos) do
	local ficha = marco(inventario, eco.nombre, UDim2.fromOffset(0, 0), UDim2.fromOffset(204, 262), TARJETA)
	ficha.LayoutOrder = i
	contorno(ficha, 13, eco.color)
	local lienzo = marco(ficha, "Ilustracion", UDim2.fromOffset(11, 11), UDim2.new(1, -22, 0, 111), NOCHE)
	crear("UICorner", lienzo, { CornerRadius = UDim.new(0, 10) })
	crear("UIGradient", lienzo, { Color = ColorSequence.new(PERLA, eco.color), Rotation = 23 })
	local retrato = crear("ViewportFrame", lienzo, {
		Name = "Retrato", Position = UDim2.fromScale(0.03, 0), Size = UDim2.fromScale(0.94, 1),
		Ambient = Color3.fromRGB(176, 189, 213), LightColor = PERLA, LightDirection = Vector3.new(0.4, -1, 0.5),
		BackgroundTransparency = 1, Visible = false,
	})
	local pendiente = etiqueta(lienzo, "PorDescubrir", UDim2.fromOffset(5, 0), UDim2.new(1, -10, 1, 0),
		"Por descubrir", SUAVE, 15, true)
	pendiente.TextXAlignment = Enum.TextXAlignment.Center
	local nombre = etiqueta(ficha, "Nombre", UDim2.fromOffset(13, 126), UDim2.new(1, -26, 0, 28),
		eco.nombre, PERLA, 19, true)
	local lugar = etiqueta(ficha, "Origen", UDim2.fromOffset(13, 151), UDim2.new(1, -26, 0, 23),
		eco.lugar, eco.color, 12, true)
	local habilidad = etiqueta(ficha, "Habilidad", UDim2.fromOffset(13, 176), UDim2.new(1, -26, 0, 33),
		"", PERLA, 13, false)
	habilidad.TextYAlignment = Enum.TextYAlignment.Top
	local mutacion = etiqueta(ficha, "Mutacion", UDim2.fromOffset(13, 212), UDim2.new(1, -26, 0, 42),
		"", eco.color, 12, false)
	mutacion.TextYAlignment = Enum.TextYAlignment.Top
	fichas[i] = { retrato = retrato, pendiente = pendiente, nombre = nombre, lugar = lugar,
		habilidad = habilidad, mutacion = mutacion }
end

local fichaLente = marco(inventario, "LenteGeoda", UDim2.fromOffset(0, 0), UDim2.fromOffset(204, 262), TARJETA)
fichaLente.LayoutOrder = #datosEcos + 1
fichaLente.Visible = false
contorno(fichaLente, 13, ORO)
local lienzoLente = marco(fichaLente, "Lente", UDim2.fromOffset(11, 11), UDim2.new(1, -22, 0, 111), NOCHE)
contorno(lienzoLente, 10, BORDE)
local brilloLente = marco(lienzoLente, "Cristal", UDim2.fromScale(0.5, 0.5), UDim2.fromOffset(44, 44), ORO)
brilloLente.AnchorPoint = Vector2.new(0.5, 0.5)
brilloLente.Rotation = 45
contorno(brilloLente, 8, PERLA)
crear("UIGradient", brilloLente, { Color = ColorSequence.new(PERLA, ORO), Rotation = 90 })
etiqueta(fichaLente, "Nombre", UDim2.fromOffset(13, 126), UDim2.new(1, -26, 0, 28),
	"Lente de la Geoda", PERLA, 17, true)
etiqueta(fichaLente, "Origen", UDim2.fromOffset(13, 155), UDim2.new(1, -26, 0, 23),
	"Revancha del guardián", ORO, 12, true)
etiqueta(fichaLente, "Uso", UDim2.fromOffset(13, 185), UDim2.new(1, -26, 0, 53),
	"Móntala junto al espejo del faro.", PERLA, 13, false)

local equipo = desplazar(panel, "Planeadores")
local gridEquipo = crear("UIGridLayout", equipo, {
	CellPadding = UDim2.fromOffset(12, 12), CellSize = UDim2.fromOffset(260, 229),
	FillDirectionMaxCells = 2, SortOrder = Enum.SortOrder.LayoutOrder,
})
local fichasPlaneadores = {}
for orden, datos in ipairs({
	{ nombre = "Básico", id = "Basico", color = ORO },
	{ nombre = "Avanzado", id = "Avanzado", color = MENTA },
}) do
	local ficha = marco(equipo, datos.id, UDim2.fromOffset(0, 0), UDim2.fromOffset(260, 229), TARJETA)
	ficha.LayoutOrder = orden
	contorno(ficha, 13, datos.color)
	local retrato = crear("ViewportFrame", ficha, {
		Name = "Retrato", Position = UDim2.fromOffset(10, 10), Size = UDim2.new(1, -20, 0, 121),
		BackgroundColor3 = NOCHE, BorderSizePixel = 0, Ambient = Color3.fromRGB(187, 202, 218),
		LightColor = PERLA, LightDirection = Vector3.new(0.35, -1, -0.5),
	})
	crear("UICorner", retrato, { CornerRadius = UDim.new(0, 9) })
	etiqueta(ficha, "Nombre", UDim2.fromOffset(12, 137), UDim2.new(1, -24, 0, 25),
		"Planeador " .. datos.nombre, PERLA, 16, true)
	local estado = etiqueta(ficha, "Estado", UDim2.fromOffset(12, 164), UDim2.new(1, -24, 0, 23),
		"", datos.color, 13, true)
	local detalle = etiqueta(ficha, "Detalle", UDim2.fromOffset(12, 188), UDim2.new(1, -24, 0, 35),
		"", SUAVE, 12, false)
	fichasPlaneadores[orden] = { retrato = retrato, estado = estado, detalle = detalle }
end

local tienda = desplazar(panel, "Tienda")
tienda.Position = UDim2.fromOffset(13, 129)
tienda.Size = UDim2.new(1, -26, 1, -141)
tienda.Visible = false
local volverDeTienda = boton(panel, "Volver", UDim2.new(1, -145, 0, 12), UDim2.fromOffset(76, 44), "Volver", TARJETA)
volverDeTienda.Visible = false
local palabrasFarero = etiqueta(panel, "PalabrasFarero", UDim2.fromOffset(17, 72), UDim2.new(1, -34, 0, 52),
	"", PERLA, 14, false)
palabrasFarero.Visible = false
local contenido = marco(tienda, "Contenido", UDim2.fromOffset(0, 0), UDim2.new(1, 0, 0, 0), TARJETA)
contenido.BackgroundTransparency = 1
local mejoras = {
	{
		nombre = "MejorarPedernal", compra = "ComprarPedernal", atributo = "MejoraPedernal",
		titulo = "Escudo rápido", eco = "Pedernal", precio = PRECIO_ESCUDO, color = HIELO,
		efecto = "El escudo se recarga en 2,65 s en el molino y el relevo de los faroles.",
	},
	{
		nombre = "MejorarPlaneador", compra = "ComprarPlaneador", atributo = "PlaneadorAvanzado",
		titulo = "Planeador avanzado", eco = "Cometa", precio = PRECIO_PLANEADOR, color = MENTA,
		efecto = "Gira con más agilidad y planea 0,60 s más. Se equipa cuando lo compras.",
	},
}
for _, mejora in ipairs(mejoras) do
	local tarjeta = marco(contenido, mejora.nombre, UDim2.fromOffset(0, 0), UDim2.new(1, 0, 0, 213), TARJETA)
	contorno(tarjeta, 12, mejora.color)
	local distintivo = marco(tarjeta, "Distintivo", UDim2.fromOffset(16, 13), UDim2.fromOffset(42, 42), PANEL)
	contorno(distintivo, 9, mejora.color)
	local cristal = marco(distintivo, "Cristal", UDim2.fromOffset(12, 12), UDim2.fromOffset(18, 18), mejora.color)
	cristal.Rotation = if mejora.atributo == "MejoraPedernal" then 45 else 15
	crear("UICorner", cristal, { CornerRadius = UDim.new(0, 3) })
	etiqueta(tarjeta, "Mejora", UDim2.fromOffset(70, 10), UDim2.new(1, -83, 0, 30),
		mejora.titulo, PERLA, 17, true)
	etiqueta(tarjeta, "Eco", UDim2.fromOffset(70, 39), UDim2.new(1, -83, 0, 19),
		mejora.eco, mejora.color, 13, true)
	local efecto = etiqueta(tarjeta, "Efecto", UDim2.fromOffset(13, 67), UDim2.new(1, -26, 0, 46),
		mejora.efecto, PERLA, 14, false)
	efecto.TextYAlignment = Enum.TextYAlignment.Top
	local comprar = boton(tarjeta, mejora.compra, UDim2.fromOffset(13, 119), UDim2.new(1, -26, 0, 44),
		("Comprar · %d monedas"):format(mejora.precio), PANEL)
	local estado = etiqueta(tarjeta, "CompraEstado", UDim2.fromOffset(13, 167), UDim2.new(1, -26, 0, 35),
		"", SUAVE, 12, false)
	mejora.tarjeta, mejora.boton, mejora.estado = tarjeta, comprar, estado
end

local encargo = marco(gui, "Encargo", UDim2.new(0.5, 0, 1, -56), UDim2.new(1, -30, 0, 75), PANEL)
encargo.AnchorPoint = Vector2.new(0.5, 1)
encargo.Visible = false
contorno(encargo, 11, ORO)
crear("UISizeConstraint", encargo, { MaxSize = Vector2.new(395, 75) })
local encargoTitulo = etiqueta(encargo, "Titulo", UDim2.fromOffset(13, 5), UDim2.new(1, -26, 0, 25),
	"", ORO, 15, true)
local encargoPista = etiqueta(encargo, "Pista", UDim2.fromOffset(13, 30), UDim2.new(1, -26, 0, 32),
	"", PERLA, 13, false)
local tomaTiempo = barra(encargo, "Tiempo", UDim2.new(0, 13, 1, -8), UDim2.new(1, -26, 0, 3), ORO)
local escudo = boton(gui, "EscudoEncargo", UDim2.new(1, -15, 1, -143), UDim2.fromOffset(105, 47),
	"Escudo", PANEL)
escudo.AnchorPoint = Vector2.new(1, 1)
escudo.Visible = false

local seleccionAnterior
local pantalla = "Inventario"
local viendoPlaneadores = false
local tomaFarero
local avisoHabilitado
local partesOcultas = {}
local CAMARA_FARERO = "EncuadreDelFarero"
local dialogoAutorizado = false
local enAlcance = false
local hastaSolicitud = 0
local solicitud
local proximoEscudo = 0
local respuestaFarero
local toastPendiente
local toastHasta = 0
local sumarXP, sumarMonedas = 0, 0
local saldoPrevio = jugador:GetAttribute("Monedas") or 0
local xpPrevio = jugador:GetAttribute("Experiencia") or 0
local nivelMostrado = jugador:GetAttribute("Nivel") or 1
local mostrarPremioEn
local premioEncargo = false
local finAnterior
local tiempoTotal = 1

local mensajes = {
	FaltaNivel = "Ven a verme al llegar al nivel 2.",
	FaltaPedernal = "Primero trae a Pedernal. Lo encontrarás en la Cueva de la Geoda.",
	FaltaCometa = "Rescata a Cometa. Cuando pueda ayudarte a planear, ven a verme.",
	FaltaLucero = "Necesito que Lucero te acompañe. Ve por él al Molino del Viento.",
	MonedasInsuficientes = "Te faltan monedas para esta mejora.",
	ProgresoNoListo = "Aún estoy consultando tu progreso.",
	GuardadoNoDisponible = "Ahora mismo no puedo guardar la compra. Inténtalo de nuevo en un momento.",
	Comprando = "Estoy registrando tu compra.",
	Lejos = "Acércate a mi taller para que podamos hablar.",
}

local function ocupado()
	return jugador:GetAttribute("MolinoPresentando") or jugador:GetAttribute("GeodaPresentando")
		or jugador:GetAttribute("FaroPresentando")
end

local function dispositivo()
	local entrada = UserInputService:GetLastInputType()
	local mando = entrada.Name:match("^Gamepad") ~= nil
	local tactil = entrada == Enum.UserInputType.Touch
		or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and not mando)
	return mando, tactil
end

local function cercaDelFarero()
	local personaje = jugador.Character
	local raiz = personaje and personaje:FindFirstChild("HumanoidRootPart")
	local refugio = isla:FindFirstChild("RefugioDelViento")
	local punto = refugio and refugio:FindFirstChild("PuntoFarero")
	local prompt = punto and punto:FindFirstChildOfClass("ProximityPrompt")
	return raiz ~= nil and punto ~= nil
		and (raiz.Position - punto.Position).Magnitude <= (if prompt then prompt.MaxActivationDistance + 0.5 else 10)
end

local function modeloDeEco(nombre)
	if nombre == "Cometa" then
		local nido = isla:FindFirstChild("Nido")
		return nido and nido:FindFirstChild(nombre)
	elseif nombre == "Pedernal" then
		local geoda = workspace:FindFirstChild("CuevaDeLaGeoda")
		return geoda and geoda:FindFirstChild(nombre)
	end
	local molino = isla:FindFirstChild("MolinoDelViento")
	return molino and molino:FindFirstChild(nombre)
end

local function mostrarModelo(modelo, retrato, direccion, altura)
	if retrato.CurrentCamera then
		return
	end
	if not (modelo and modelo:IsA("Model")) then
		return
	end
	local copia = modelo:Clone()
	if not copia then
		return
	end
	for _, pieza in ipairs(copia:GetDescendants()) do
		if pieza:IsA("LuaSourceContainer") then
			pieza:Destroy()
		elseif pieza:IsA("BasePart") then
			pieza.Anchored = true
			pieza.LocalTransparencyModifier = 0
			if pieza.Transparency == 1 and pieza.Size.Magnitude > 0.55 then
				pieza.Transparency = 0
			end
		end
	end
	local mundo = crear("WorldModel", retrato, {})
	copia.Parent = mundo
	copia:PivotTo(CFrame.new())
	local marcoEco, escala = copia:GetBoundingBox()
	local distancia = math.max(escala.X, escala.Y, escala.Z, 1) * 1.9
	local mira = marcoEco.Position + Vector3.new(0, altura or 0, 0)
	local camara = crear("Camera", retrato, { FieldOfView = 35,
		CFrame = CFrame.lookAt(mira + direccion * distancia, mira) })
	retrato.CurrentCamera = camara
end

local function dibujarColeccion()
	local cantidad = 0
	for i, eco in ipairs(datosEcos) do
		local ficha = fichas[i]
		local descubierto = jugador:GetAttribute(eco.nombre) == true
		if descubierto then
			cantidad += 1
			mostrarModelo(modeloDeEco(eco.nombre), ficha.retrato, Vector3.new(-0.57, 0.28, -0.79))
		end
		ficha.retrato.Visible = descubierto and ficha.retrato.CurrentCamera ~= nil
		ficha.pendiente.Text = if descubierto then eco.nombre else "Por descubrir"
		ficha.pendiente.Visible = not ficha.retrato.Visible
		ficha.nombre.Text = if descubierto then eco.nombre else "Eco desconocido"
		ficha.habilidad.Text = if descubierto then eco.habilidad else "Explora este lugar para encontrarlo."
		local mutado = eco.mutacion and jugador:GetAttribute(eco.mutacion)
		local evolucion = {}
		if descubierto and mutado then
			table.insert(evolucion, eco.mutacion .. " · " .. eco.beneficio)
		end
		if descubierto and eco.nombre == "Pedernal" and jugador:GetAttribute("MejoraPedernal") then
			table.insert(evolucion, "Mejora · Escudo rápido")
		elseif descubierto and eco.nombre == "Cometa" then
			table.insert(evolucion, if jugador:GetAttribute("PlaneadorAvanzado")
				then "Equipo · Planeador avanzado" else "Equipo · Planeador básico")
		end
		ficha.mutacion.Text = table.concat(evolucion, "\n")
	end
	fichaLente.Visible = jugador:GetAttribute("LenteGeoda") == true
	return cantidad
end

local function dibujarPlaneadores()
	local tengoBasico = jugador:GetAttribute("Cometa") == true
	local tengoAvanzado = jugador:GetAttribute("PlaneadorAvanzado") == true
	for orden, ficha in ipairs(fichasPlaneadores) do
		local avanzado = orden == 2
		if not ficha.retrato.CurrentCamera then
			local rig = Planeadores.crear(avanzado)
			Planeadores.colocar(rig, Vector3.zero, -Vector3.zAxis, 1, 0)
			mostrarModelo(rig.modelo, ficha.retrato, Vector3.new(-0.52, 0.62, -0.62))
			rig.modelo:Destroy()
		end
		local obtenido = if avanzado then tengoAvanzado else tengoBasico
		local equipado = obtenido and (avanzado or not tengoAvanzado)
		ficha.estado.Text = if equipado then "Equipado" elseif obtenido then "Obtenido" else "Por conseguir"
		ficha.detalle.Text = if avanzado
			then (if obtenido then "Mejor giro y hasta 3,05 s de planeo." else "Disponible con el farero por 65 monedas.")
			else (if obtenido then "Hasta 2,45 s de planeo." else "Rescata a Cometa para desbloquearlo.")
	end
end

local function dibujarProgreso()
	local listo = jugador:GetAttribute("ProgresoListo") == true
	local nivelActual = jugador:GetAttribute("Nivel") or 1
	local xpActual = jugador:GetAttribute("XpNivel") or 0
	local meta = math.max(1, jugador:GetAttribute("XpMeta") or 100)
	local monedas = jugador:GetAttribute("Monedas") or 0
	local mando, tactil = dispositivo()
	nivel.Text = if listo then ("Nivel %d"):format(nivelActual) else "Cargando"
	saldo.Text = if listo then ("%d monedas"):format(monedas) else ""
	xp.Text = if listo then ("%d / %d XP"):format(xpActual, meta) else ""
	progresoXP.Size = UDim2.fromScale(if listo then math.clamp(xpActual / meta, 0, 1) else 0, 1)
	etiquetaEcos.Text = if mando then "Inventario ↑" elseif tactil then "Inventario" else "Inventario [I]"
	etiquetaEcos.Active = mando or tactil
	etiquetaEcos.Selectable = mando
	etiquetaEcos.AutoButtonColor = mando or tactil
end

local function dibujarDialogo()
	local tema = pantalla == "SenalFaro"
	temaFaro.Visible = not tema
	temaMejoras.Visible = not tema
	seguirSenal.Visible = tema
	volverDeSenal.Visible = tema
	local puedoEnviar = dialogoAutorizado and enAlcance and jugador:GetAttribute("ProgresoListo")
		and jugador:GetAttribute("Lucero") and (jugador:GetAttribute("Nivel") or 1) >= NIVEL_MINIMO
		and not solicitud
	seguirSenal.Active = puedoEnviar == true
	seguirSenal.Selectable = seguirSenal.Active
	seguirSenal.AutoButtonColor = seguirSenal.Active
	seguirSenal.BackgroundColor3 = if seguirSenal.Active then ORO else PANEL
	seguirSenal.TextColor3 = if seguirSenal.Active then NOCHE else SUAVE
	seguirSenal.Text = if solicitud == "PrepararFaro" then "Preparando la salida…" else "Seguir la señal"
	if respuestaFarero then
		fraseFarero.Text = respuestaFarero
	elseif not tema then
		fraseFarero.Text = "¡Pasa! Anoche vi una luz entre las nubes. También tengo equipo para tu viaje."
	elseif not jugador:GetAttribute("Lucero") then
		fraseFarero.Text = "Anoche vi una luz entre las nubes. Recoge a Lucero en el Molino del Viento y ven conmigo. Su luz puede revelar el camino."
	elseif (jugador:GetAttribute("Nivel") or 1) < NIVEL_MINIMO then
		fraseFarero.Text = "La señal viene de las ruinas del faro. Ven a verme al llegar al nivel 2 y te mostraré dónde despegar con Lucero."
	elseif jugador:GetAttribute("LenteGeoda") and not jugador:GetAttribute("Prisma") then
		fraseFarero.Text = "¡Esa lente es del guardián! Móntala junto al espejo del faro y apunta al cristal que brilla distinto. Así podrás abrir la cámara."
	else
		fraseFarero.Text = "Anoche vi una luz entre las nubes. Lleva a Lucero al faro y sigue las huellas que revele. El espejo te ayudará a encender la linterna."
	end
end

local function dibujarTienda()
	local listo = jugador:GetAttribute("ProgresoListo") == true
	local escudoEquipado = jugador:GetAttribute("MejoraPedernal") == true
	local planeadorEquipado = jugador:GetAttribute("PlaneadorAvanzado") == true
	local nivelActual = jugador:GetAttribute("Nivel") or 1
	local monedas = jugador:GetAttribute("Monedas") or 0
	subtitulo.Text = if listo then ("%d monedas disponibles"):format(monedas) else "Consultando tu progreso…"
	palabrasFarero.Text = respuestaFarero or (if escudoEquipado and planeadorEquipado
		then "Ya equipé a Pedernal con Escudo rápido y a Cometa con el planeador avanzado."
		elseif escudoEquipado then "Pedernal ya tiene Escudo rápido. Si quieres probarlo, acércate al relevo de los faroles."
		elseif planeadorEquipado then "Ya te entregué el planeador avanzado. Salta y activa el planeo para desplegarlo."
		else "Puedo ajustar el escudo de Pedernal o preparar un planeador más ágil para tus viajes.")
	for _, mejora in ipairs(mejoras) do
		local equipada = jugador:GetAttribute(mejora.atributo) == true
		local causa
		if not listo then
			causa = "ProgresoNoListo"
		elseif not jugador:GetAttribute(mejora.eco) then
			causa = if mejora.eco == "Pedernal" then "FaltaPedernal" else "FaltaCometa"
		elseif mejora.eco == "Pedernal" and nivelActual < NIVEL_MINIMO then
			causa = "FaltaNivel"
		elseif monedas < mejora.precio then
			causa = "MonedasInsuficientes"
		elseif not dialogoAutorizado or not enAlcance then
			causa = "Lejos"
		end
		local disponible = not equipada and not causa and not solicitud
		local comprar = mejora.boton
		comprar.Active = disponible
		comprar.Selectable = disponible
		comprar.AutoButtonColor = disponible
		comprar.BackgroundColor3 = if disponible then mejora.color else PANEL
		comprar.TextColor3 = if disponible then NOCHE else SUAVE
		comprar.Text = if equipada then "Equipado"
			elseif solicitud == mejora.compra then "Comprando…"
			else ("Comprar · %d monedas"):format(mejora.precio)
		mejora.estado.Text = if equipada and mejora.eco == "Pedernal" and not jugador:GetAttribute("EncargoPedernal")
			then "Prueba el escudo en el relevo de los faroles."
			elseif equipada then ""
			elseif causa then mensajes[causa] else "Desbloqueo único"
	end
end

local function actualizarPanel()
	local coleccion = pantalla == "Inventario"
	local intercambio = pantalla == "Mejoras"
	local conversacion = not coleccion and not intercambio
	panel.Visible = not conversacion
	fondo.BackgroundTransparency = if conversacion then 1 else 0.29
	dialogo.Visible = conversacion
	bocadillo.Enabled = menu.Visible and conversacion
	inventario.Visible = coleccion and not viendoPlaneadores
	equipo.Visible = coleccion and viendoPlaneadores
	verEcos.Visible = coleccion
	verPlaneadores.Visible = coleccion
	verEcos.BackgroundColor3 = if viendoPlaneadores then TARJETA else BORDE
	verPlaneadores.BackgroundColor3 = if viendoPlaneadores then BORDE else TARJETA
	tienda.Visible = intercambio
	volverDeTienda.Visible = intercambio
	palabrasFarero.Visible = intercambio
	titulo.Text = if coleccion then "Inventario" else "Farero del refugio"
	titulo.Size = UDim2.new(1, if intercambio then -169 else -82, 0, 32)
	if coleccion then
		if viendoPlaneadores then
			dibujarPlaneadores()
			subtitulo.Text = if jugador:GetAttribute("ProgresoListo") then "" else "Cargando el equipo…"
		else
			local descubiertos = dibujarColeccion()
			subtitulo.Text = if jugador:GetAttribute("ProgresoListo")
				then ("%d de %d Ecos descubiertos"):format(descubiertos, #datosEcos) else "Cargando la colección…"
		end
	elseif intercambio then
		dibujarTienda()
	else
		subtitulo.Text = if pantalla == "SenalFaro" then "Las Ruinas del Faro" else ""
		dibujarDialogo()
	end
	dibujarProgreso()
end

local function enfocarAlFarero()
	if avisoHabilitado == nil then
		avisoHabilitado = avisoFarero.Enabled
		avisoFarero.Enabled = false
		for _, pieza in isla.Nido.Cometa:GetDescendants() do
			if pieza:IsA("BasePart") then
				partesOcultas[pieza] = pieza.LocalTransparencyModifier
				pieza.LocalTransparencyModifier = 1
			end
		end
	end
	jugador:SetAttribute("FareroConversando", true)
	local camara = workspace.CurrentCamera
	if camara and not tomaFarero and camara.CameraType == Enum.CameraType.Custom and not GuiService.ReducedMotionEnabled then
		local cabeza = rostroFarero.Position
		local raiz = jugador.Character and jugador.Character:FindFirstChild("HumanoidRootPart")
		local lado = if raiz and raiz.Position.X > cabeza.X then -1 else 1
		local mira = cabeza + Vector3.yAxis * 0.97
		tomaFarero = { camara = camara, marco = camara.CFrame, foco = camara.Focus, fov = camara.FieldOfView }
		local plano = CFrame.lookAt(cabeza + Vector3.new(lado * 3.75, 2.35, 9.1), mira)
		camara.CameraType = Enum.CameraType.Scriptable
		RunService:BindToRenderStep(CAMARA_FARERO, Enum.RenderPriority.Camera.Value + 1, function()
			camara.CFrame = plano
			camara.Focus = CFrame.new(mira)
			camara.FieldOfView = 57
		end)
	end
end

local function recuperarVista()
	if avisoHabilitado ~= nil then
		avisoFarero.Enabled = avisoHabilitado
		avisoHabilitado = nil
		for pieza, opacidad in pairs(partesOcultas) do
			if pieza.Parent then
				pieza.LocalTransparencyModifier = opacidad
			end
		end
		table.clear(partesOcultas)
		jugador:SetAttribute("FareroConversando", false)
	end
	if tomaFarero then
		RunService:UnbindFromRenderStep(CAMARA_FARERO)
		local camara = tomaFarero.camara
		if camara == workspace.CurrentCamera and camara.CameraType == Enum.CameraType.Scriptable then
			camara.CFrame = tomaFarero.marco
			camara.Focus = tomaFarero.foco
			camara.FieldOfView = tomaFarero.fov
			camara.CameraType = Enum.CameraType.Custom
		end
		tomaFarero = nil
	end
end

local function abrir(destino, conFarero)
	if ocupado() then
		return
	end
	if not menu.Visible then
		seleccionAnterior = GuiService.SelectedObject
	end
	if conFarero then
		dialogoAutorizado = true
	end
	if destino == "Inventario" then
		dialogoAutorizado = false
		recuperarVista()
	end
	respuestaFarero = nil
	enAlcance = cercaDelFarero()
	pantalla = destino
	menu.Visible = true
	progreso.Visible = false
	aviso.Visible = false
	if conFarero then
		enfocarAlFarero()
	end
	actualizarPanel()
	local mando = dispositivo()
	if mando then
		GuiService.SelectedObject = if destino == "Dialogo" then temaFaro
			elseif destino == "Mejoras" then volverDeTienda
			elseif destino == "SenalFaro" and seguirSenal.Active then seguirSenal
			elseif destino == "SenalFaro" then volverDeSenal elseif viendoPlaneadores then verPlaneadores else verEcos
	end
end

local function cerrarPanel()
	if not menu.Visible then
		return
	end
	menu.Visible = false
	bocadillo.Enabled = false
	recuperarVista()
	dialogoAutorizado = false
	local seleccionado = GuiService.SelectedObject
	if not seleccionado or seleccionado:IsDescendantOf(panel) or seleccionado:IsDescendantOf(dialogo) then
		GuiService.SelectedObject = if seleccionAnterior and seleccionAnterior.Parent then seleccionAnterior else nil
	end
	seleccionAnterior = nil
end

local function alternar()
	if menu.Visible and pantalla == "Inventario" then
		cerrarPanel()
	else
		abrir("Inventario")
	end
end

local function adaptar()
	local ancho = gui.AbsoluteSize.X
	local mayor = ancho >= 680
	progreso.Position = UDim2.new(1, -13, 0, if mayor then 9 else 100)
	aviso.Position = UDim2.new(1, -13, 0, if mayor then 83 else 172)
	local disponible = inventario.AbsoluteSize.X - 11
	local columnas = if disponible >= 590 then 3 elseif disponible >= 400 then 2 else 1
	grid.FillDirectionMaxCells = columnas
	grid.CellSize = UDim2.fromOffset(math.max(0, math.floor((disponible - (columnas - 1) * 12) / columnas)), 262)
	local anchoEquipo = equipo.AbsoluteSize.X - 11
	local columnasEquipo = if anchoEquipo >= 430 then 2 else 1
	gridEquipo.FillDirectionMaxCells = columnasEquipo
	gridEquipo.CellSize = UDim2.fromOffset(math.max(0, math.floor((anchoEquipo - (columnasEquipo - 1) * 12) / columnasEquipo)), 229)
	local anchoTienda = tienda.AbsoluteSize.X - 11
	local ladoALado = anchoTienda >= 575
	contenido.Size = UDim2.new(1, 0, 0, if ladoALado then 216 else 443)
	for i, mejora in ipairs(mejoras) do
		mejora.tarjeta.Position = if ladoALado then UDim2.new((i - 1) * 0.5, (i - 1) * 6, 0, 0)
			else UDim2.fromOffset(0, (i - 1) * 225)
		mejora.tarjeta.Size = if ladoALado then UDim2.new(0.5, -6, 0, 213) else UDim2.new(1, 0, 0, 213)
	end
	local estrecho = ancho < 445
	palabrasFarero.TextSize = if estrecho then 13 else 14
	palabrasFarero.Size = UDim2.new(1, -34, 0, if estrecho then 72 else 52)
	tienda.Position = UDim2.fromOffset(13, if estrecho then 149 else 129)
	tienda.Size = UDim2.new(1, -26, 1, if estrecho then -161 else -141)
	bocadillo.Size = UDim2.fromOffset(math.max(0, math.min(ancho - 24, 352)), if estrecho then 105 else 91)
	fraseFarero.TextSize = if estrecho then 14 else 15
end

local function usarEscudo()
	if ocupado() or menu.Visible or not jugador:GetAttribute("EnEncargoPedernal") then
		return false
	end
	local tiempo = workspace:GetServerTimeNow()
	if tiempo >= (jugador:GetAttribute("EscudoRefugioListoEn") or 0) and os.clock() >= proximoEscudo then
		proximoEscudo = os.clock() + 0.2
		remoto:FireServer("Escudo")
	end
	return true
end

local function pedir(accion)
	if solicitud then
		return
	end
	solicitud = accion
	hastaSolicitud = os.clock() + 4
	respuestaFarero = nil
	actualizarPanel()
	remoto:FireServer(accion)
end

etiquetaEcos.Activated:Connect(function()
	local mando, tactil = dispositivo()
	if mando or tactil then
		alternar()
	end
end)
fondo.Activated:Connect(cerrarPanel)
cerrar.Activated:Connect(cerrarPanel)
despedir.Activated:Connect(cerrarPanel)
verEcos.Activated:Connect(function()
	viendoPlaneadores = false
	actualizarPanel()
end)
verPlaneadores.Activated:Connect(function()
	viendoPlaneadores = true
	actualizarPanel()
end)
temaFaro.Activated:Connect(function() abrir("SenalFaro") end)
temaMejoras.Activated:Connect(function() abrir("Mejoras") end)
volverDeSenal.Activated:Connect(function() abrir("Dialogo") end)
volverDeTienda.Activated:Connect(function() abrir("Dialogo") end)
seguirSenal.Activated:Connect(function()
	if seguirSenal.Active then
		pedir("PrepararFaro")
	end
end)
escudo.Activated:Connect(usarEscudo)
for _, mejora in ipairs(mejoras) do
	mejora.boton.Activated:Connect(function()
		if mejora.boton.Active then
			pedir(mejora.compra)
		end
	end)
end

ContextActionService:BindActionAtPriority("AbrirInventarioEcos", function(_, estado, entrada)
	if ocupado() or UserInputService:GetFocusedTextBox()
		or (entrada.KeyCode == Enum.KeyCode.DPadUp and menu.Visible) then
		return Enum.ContextActionResult.Pass
	end
	if estado == Enum.UserInputState.Begin then
		alternar()
	end
	return Enum.ContextActionResult.Sink
end, false, ALTA, Enum.KeyCode.I, Enum.KeyCode.DPadUp)

ContextActionService:BindActionAtPriority("CerrarInventarioEcos", function(_, estado)
	if not menu.Visible then
		return Enum.ContextActionResult.Pass
	end
	if estado == Enum.UserInputState.Begin then
		cerrarPanel()
	end
	return Enum.ContextActionResult.Sink
end, false, ALTA, Enum.KeyCode.Backspace, Enum.KeyCode.ButtonB)

ContextActionService:BindActionAtPriority("EscudoDelRefugio", function(_, estado)
	if estado == Enum.UserInputState.Begin and usarEscudo() then
		return Enum.ContextActionResult.Sink
	end
	return Enum.ContextActionResult.Pass
end, false, ALTA, Enum.KeyCode.C, Enum.KeyCode.ButtonR1)

ContextActionService:BindActionAtPriority("InteraccionesInventarioEcos", function()
	return if menu.Visible then Enum.ContextActionResult.Sink else Enum.ContextActionResult.Pass
end, false, ALTA, Enum.KeyCode.E, Enum.KeyCode.Q, Enum.KeyCode.C, Enum.KeyCode.F,
	Enum.KeyCode.ButtonX, Enum.KeyCode.ButtonY, Enum.KeyCode.ButtonR1)

local function guardarToast(tituloAviso, detalleAviso)
	toastPendiente = { tituloAviso, detalleAviso }
end

remoto.OnClientEvent:Connect(function(evento, ok, codigo)
	if evento == "AbrirTienda" then
		abrir("Dialogo", true)
	elseif evento == "ResultadoCompra" or evento == "ResultadoPlaneador" then
		local planeador = evento == "ResultadoPlaneador"
		local esperada = if planeador then "ComprarPlaneador" else "ComprarPedernal"
		if solicitud == esperada then
			solicitud, hastaSolicitud = nil, 0
		end
		local respuesta
		if ok then
			respuesta = if planeador
				then "Aquí tienes tu planeador avanzado. Lo dejé equipado. Salta y planea para sentir cómo gira."
				else "¡Listo! El escudo de Pedernal se recupera más rápido. Ahora ve al relevo y enciende los dos faroles."
		elseif codigo == "YaComprada" then
			respuesta = if planeador then "Ya te entregué ese planeador. Lo tienes equipado."
				else "Pedernal ya tiene equipado Escudo rápido. Pruébalo en el relevo de los faroles."
		else
			respuesta = mensajes[codigo] or "No pude registrar la compra. Inténtalo otra vez."
		end
		if menu.Visible and pantalla ~= "Inventario" then
			if (ok or codigo == "YaComprada") and cercaDelFarero() then
				abrir("Dialogo")
			end
			respuestaFarero = respuesta
			actualizarPanel()
		end
	elseif evento == "SalidaAlFaro" then
		if solicitud == "PrepararFaro" then
			solicitud, hastaSolicitud = nil, 0
		end
		if ok then
			if pantalla ~= "Inventario" then
				cerrarPanel()
			end
		else
			respuestaFarero = mensajes[codigo] or "Todavía no puedo indicarte la salida."
			if menu.Visible and pantalla == "SenalFaro" then
				actualizarPanel()
			end
		end
	elseif evento == "EncargoCompleto" then
		premioEncargo = true
		mostrarPremioEn = os.clock() + 0.45
	end
end)

local function leerPremio()
	local exp = jugador:GetAttribute("Experiencia") or 0
	local dinero = jugador:GetAttribute("Monedas") or 0
	if jugador:GetAttribute("ProgresoListo") then
		local diferenciaXP = math.max(0, exp - xpPrevio)
		local diferenciaMonedas = math.max(0, dinero - saldoPrevio)
		sumarXP += diferenciaXP
		sumarMonedas += diferenciaMonedas
		if diferenciaXP > 0 or diferenciaMonedas > 0 then
			mostrarPremioEn = os.clock() + 0.45
		end
	end
	xpPrevio, saldoPrevio = exp, dinero
end

local function actualizarEncargo(ahora)
	local mando, tactil = dispositivo()
	local accion = if tactil then "Toca Escudo" elseif mando then "Pulsa R1" else "Pulsa C"
	local estado = jugador:GetAttribute("EstadoEncargo")
	local restante = math.max(0, (jugador:GetAttribute("EncargoHasta") or 0) - ahora)
	local escudado = math.max(0, (jugador:GetAttribute("EscudoRefugioHasta") or 0) - ahora)
	local recarga = math.max(0, (jugador:GetAttribute("EscudoRefugioListoEn") or 0) - ahora)
	if estado == "Segundo" then
		encargoTitulo.Text = ("Segundo faro · %.0f s"):format(math.ceil(restante))
		encargoPista.Text = if recarga > 0 then ("Corre al segundo faro. Escudo listo en %.1f s."):format(recarga)
			else accion .. " junto al segundo faro."
	elseif estado == "Meta" or estado == "Final" then
		encargoTitulo.Text = "Faros protegidos"
		encargoPista.Text = "Interactúa con la baliza para completar el encargo."
	elseif estado == "Reintentar" then
		encargoTitulo.Text = "Vuelve al primer faro"
		encargoPista.Text = accion .. " cuando estés junto a él."
	else
		encargoTitulo.Text = "Primer faro"
		encargoPista.Text = accion .. " junto a la luz para protegerla."
	end
	if estado == "Segundo" then
		if not finAnterior or finAnterior ~= jugador:GetAttribute("EncargoHasta") then
			finAnterior = jugador:GetAttribute("EncargoHasta")
			tiempoTotal = math.max(1, restante)
		end
		tomaTiempo.Size = UDim2.fromScale(math.clamp(restante / tiempoTotal, 0, 1), 1)
	end
	tomaTiempo.Parent.Visible = estado == "Segundo"
	escudo.Visible = tactil and estado ~= "Meta" and estado ~= "Final"
	escudo.Active = recarga <= 0
	escudo.Text = if escudado > 0 then "Protegido" elseif recarga > 0 then ("Escudo · %.1f s"):format(recarga) else "Escudo"
	escudo.TextColor3 = if escudado > 0 then MENTA elseif recarga > 0 then SUAVE else HIELO
end

for _, nombre in ipairs({ "Experiencia", "Monedas" }) do
	jugador:GetAttributeChangedSignal(nombre):Connect(leerPremio)
end
jugador:GetAttributeChangedSignal("ProgresoListo"):Connect(function()
	xpPrevio = jugador:GetAttribute("Experiencia") or 0
	saldoPrevio = jugador:GetAttribute("Monedas") or 0
	nivelMostrado = jugador:GetAttribute("Nivel") or 1
end)

for _, nombre in ipairs({ "Nivel", "XpNivel", "XpMeta", "Monedas", "Cometa", "Vendaval", "Pedernal", "Rebote",
	"Lucero", "Prisma", "LenteGeoda", "MejoraPedernal", "EncargoPedernal", "PlaneadorAvanzado", "ProgresoListo" }) do
	jugador:GetAttributeChangedSignal(nombre):Connect(function()
		if menu.Visible then
			actualizarPanel()
		else
			dibujarProgreso()
		end
	end)
end
gui:GetPropertyChangedSignal("AbsoluteSize"):Connect(adaptar)
inventario:GetPropertyChangedSignal("AbsoluteSize"):Connect(adaptar)
equipo:GetPropertyChangedSignal("AbsoluteSize"):Connect(adaptar)
tienda:GetPropertyChangedSignal("AbsoluteSize"):Connect(adaptar)
UserInputService.LastInputTypeChanged:Connect(dibujarProgreso)
jugador.CharacterRemoving:Connect(cerrarPanel)
adaptar()
actualizarPanel()

local refresco = 0
RunService.Heartbeat:Connect(function(dt)
	refresco += dt
	if refresco < 0.09 then
		return
	end
	refresco = 0

	local ahora = os.clock()
	local presenta = ocupado()
	local enEncargo = jugador:GetAttribute("EnEncargoPedernal") == true
	local humanoide = jugador.Character and jugador.Character:FindFirstChildOfClass("Humanoid")
	local vivo = humanoide ~= nil and humanoide.Health > 0
	if presenta or not vivo then
		cerrarPanel()
	end
	progreso.Visible = not presenta and not menu.Visible and vivo
	encargo.Visible = enEncargo and not presenta and not menu.Visible and vivo
	if encargo.Visible then
		actualizarEncargo(workspace:GetServerTimeNow())
	else
		escudo.Visible = false
	end
	if solicitud and ahora >= hastaSolicitud then
		solicitud, hastaSolicitud = nil, 0
		if menu.Visible and pantalla ~= "Inventario" then
			actualizarPanel()
		end
	end
	if menu.Visible and pantalla ~= "Inventario" and dialogoAutorizado then
		local cerca = cercaDelFarero()
		if not cerca then
			cerrarPanel()
		elseif cerca ~= enAlcance then
			enAlcance = cerca
			actualizarPanel()
		end
	end
	if mostrarPremioEn and ahora >= mostrarPremioEn then
		local actual = jugador:GetAttribute("Nivel") or 1
		local premio = {}
		if sumarXP > 0 then
			table.insert(premio, ("+%d XP"):format(sumarXP))
		end
		if sumarMonedas > 0 then
			table.insert(premio, ("+%d monedas"):format(sumarMonedas))
		end
		local tituloPremio = if premioEncargo then "Encargo completado"
			elseif actual > nivelMostrado then ("¡Nivel %d!"):format(actual)
			else "Progreso de expedición"
		guardarToast(tituloPremio, if #premio > 0 then table.concat(premio, "  ·  ") else "Protegiste los dos faros.")
		premioEncargo = false
		nivelMostrado = actual
		mostrarPremioEn = nil
		sumarXP, sumarMonedas = 0, 0
	end
	if progreso.Visible and toastPendiente then
		avisoTitulo.Text = toastPendiente[1]
		avisoDetalle.Text = toastPendiente[2]
		toastHasta = ahora + 4.2
		toastPendiente = nil
	end
	aviso.Visible = progreso.Visible and ahora < toastHasta
end)
