-- Instalar temporalmente en ServerScriptService y ejecutar en Edit con el LocalScript de pruebas.
-- ExecuteMultiplayerTestAsync(2, "TurnosExpedicionQA") prueba Cueva y Molino.
-- ExecuteMultiplayerTestAsync(2, "TurnosFaroQA") usa perfiles nuevos con Lucero para el Faro.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local pruebas = game:GetService("StudioTestService")
if not game:GetService("RunService"):IsStudio() then return end
local caso = pruebas:GetTestArgs()
if caso ~= "TurnosExpedicionQA" and caso ~= "TurnosFaroQA" then return end

local etapa = "iniciar"
local finalizada = false
local function finalizar(mensaje)
	if finalizada then return end
	finalizada = true
	pruebas:EndTest(mensaje)
end
task.delay(160, function() finalizar("FALLO: tiempo total en " .. etapa) end)

local function esperar(nombre, segundos, evaluar)
	etapa = nombre
	local limite = os.clock() + segundos
	repeat
		local valor = evaluar()
		if valor then return valor end
		task.wait(.05)
	until os.clock() >= limite
	local estados = {}
	for _, p in Players:GetPlayers() do
		local c = p.Character
		local r = c and c:FindFirstChild("HumanoidRootPart")
		local h = c and c:FindFirstChildOfClass("Humanoid")
		if r and h then
			local filtro = RaycastParams.new()
			filtro.FilterDescendantsInstances = {c}
			filtro.RespectCanCollide = true
			local suelo = workspace:Raycast(r.Position, -Vector3.yAxis * 20, filtro)
			table.insert(estados, ("%s en %s, suelo %s/%s, Lucero=%s, EnFaro=%s, espera=%s"):format(
				p.Name, tostring(r.Position), h.FloorMaterial.Name, suelo and suelo.Instance.Name or "vacío",
				tostring(p:GetAttribute("Lucero")), tostring(p:GetAttribute("EnFaro")), tostring(p:GetAttribute("EsperaFaro"))))
			table.insert(estados, ("altura %.2f; alcance %.2f; ocupaciones %s/%s/%s; perfil %s"):format(
				suelo and suelo.Distance or -1, h.HipHeight + r.Size.Y/2 + .65,
				tostring(p:GetAttribute("EnCueva")), tostring(p:GetAttribute("EnMolino")),
				tostring(p:GetAttribute("EnEncargoPedernal")), tostring(p:GetAttribute("ProgresoListo"))))
		end
	end
	error("Tiempo agotado en " .. nombre .. " | " .. table.concat(estados, " | "))
end

local canal = Instance.new("RemoteEvent")
canal.Name = "PruebaTurnosExpediciones"
local listos, pendiente = {}, nil
local numero = 0
canal.OnServerEvent:Connect(function(p, id, ok, detalle)
	if id == 0 then listos[p] = true
	elseif pendiente and pendiente.p == p and pendiente.id == id then
		pendiente.respuesta = {ok == true, detalle}
	end
end)
canal.Parent = ReplicatedStorage

local function pedir(p, accion, objeto)
	numero += 1
	pendiente = {p = p, id = numero}
	if objeto and objeto:IsA("ProximityPrompt") then
		local pos = objeto.Parent.Position
		local junto = pos + Vector3.new(-2.5, 2, 1.4)
		p.Character:PivotTo(CFrame.lookAt(junto, Vector3.new(pos.X, junto.Y, pos.Z)))
		p.Character.HumanoidRootPart.AssemblyLinearVelocity = Vector3.zero
	end
	canal:FireClient(p, numero, accion, objeto)
	local descripcion = accion .. " " .. (objeto and objeto.Parent.Name or "") .. " por " .. p.Name
	local respuesta = esperar(descripcion, 12, function() return pendiente.respuesta end)
	pendiente = nil
	assert(respuesta[1], descripcion .. ": " .. tostring(respuesta[2]))
end

local function personaje(p)
	local c = p.Character
	local h = c and c:FindFirstChildOfClass("Humanoid")
	return c and h and h.Health > 0 and c:FindFirstChild("HumanoidRootPart")
end

local function situar(p, posicion)
	local raiz = assert(personaje(p), "Falta el personaje de " .. p.Name)
	p.Character:PivotTo(CFrame.new(posicion))
	raiz.AssemblyLinearVelocity = Vector3.zero
	return raiz
end

local function turno(modelo, p)
	local esperado = if p then p.UserId else nil
	esperar("turno " .. modelo.Name .. " para " .. tostring(esperado), 8, function()
		return modelo:GetAttribute("TitularExpedicion") == esperado
	end)
end

local function cuevaYMolino(a, b, isla)
	local cueva = workspace.CuevaDeLaGeoda
	local portal = isla.Rutas.PortalDeLaGeoda.Accion
	local molino = isla.MolinoDelViento
	local origenChispa = molino.Chispa.CFrame
	turno(cueva, nil)
	turno(molino, nil)
	pedir(a, "activar", portal)
	turno(cueva, a)
	pedir(b, "portalOcupado", portal)
	assert(a:GetAttribute("EnCueva") and not b:GetAttribute("EnCueva"))
	local anterior = a.Character
	anterior:FindFirstChildOfClass("Humanoid").Health = 0
	turno(cueva, nil)
	pedir(b, "activar", portal)
	turno(cueva, b)
	pedir(b, "activar", cueva.SalidaIsla.Accion)
	turno(cueva, nil)
	assert(not b:GetAttribute("EnCueva"))
	esperar("reaparición del primero", 14, function() return a.Character ~= anterior and personaje(a) end)

	local function llegar(p, lateral)
		p:SetAttribute("Pedernal", true)
		-- Coloca el planeador ya en su último tramo. La detección de llegada, el turno y los premios son del juego.
		p:SetAttribute("PlaneoIslaHasta", workspace:GetServerTimeNow() + 2.6)
		situar(p, molino.Llegada.Position + Vector3.new(lateral, 5, 0))
	end
	llegar(a, 3)
	turno(molino, a)
	esperar("chispa disponible", 12, function() return molino.Chispa.Accion.Enabled end)
	pedir(a, "activar", molino.Chispa.Accion)
	esperar("primero transporta", 4, function() return a:GetAttribute("LlevaChispa") end)
	llegar(b, -3)
	esperar("segundo espera en el muelle", 5, function() return b:GetAttribute("EsperaMolino") end)
	assert(molino:GetAttribute("TitularExpedicion") == a.UserId and not b:GetAttribute("LlevaChispa"))
	assert(not a:GetAttribute("Lucero") and not b:GetAttribute("Lucero"))
	-- Ambos perfiles son exclusivos de esta sesión de Studio. El segundo permanece conectado.
	a:Kick("Desconexión programada durante la prueba del relevo")
	esperar("desconexión real del portador", 7, function() return a.Parent ~= Players end)
	turno(molino, b)
	esperar("chispa vuelve al pedestal", 12, function() return molino.Chispa.Accion.Enabled end)
	assert((molino.Chispa.Position - origenChispa.Position).Magnitude < .15)
	assert(not molino:GetAttribute("MolinoEncendido") and not b:GetAttribute("EsperaMolino"))
	local saldo = b:GetAttribute("Monedas")
	assert(type(saldo) == "number")
	pedir(b, "activar", molino.Chispa.Accion)
	esperar("segundo transporta", 4, function() return b:GetAttribute("LlevaChispa") end)
	situar(b, molino.ZonaViento.CFrame:PointToWorldSpace(Vector3.new(1.2, 1.25, 0)))
	pedir(b, "escudo")
	esperar("cruce protegido", 3, function() return molino.Farol.Accion.Enabled end)
	pedir(b, "activar", molino.Farol.Accion)
	esperar("Lucero y premio", 5, function() return b:GetAttribute("Lucero") and b:GetAttribute("Monedas") == saldo + 50 end)
	turno(molino, nil)
	pedir(b, "activar", molino.Regreso.Accion)
	esperar("salida con Lucero", 4, function() return not b:GetAttribute("EnMolino") end)
	llegar(b, 0)
	esperar("revisita al molino", 5, function() return b:GetAttribute("EnMolino") end)
	assert(not molino:GetAttribute("TitularExpedicion") and not molino.Chispa.Accion.Enabled)
	assert(b:GetAttribute("Monedas") == saldo + 50, "Se duplicó el premio al regresar")
	return "OK: Cueva ocupada y liberada al morir; Molino recuperado tras desconexión con chispa; segundo completa, recibe +50 y revisita sin duplicados."
end

local function probarFaro(a, b, isla)
	local f = isla.RuinasDelFaro
	esperar("inicio del controlador del Faro", 10, function()
		return f:GetAttribute("RastroRevelado") ~= nil and f.Prisma:FindFirstChild("CaminoDePrisma")
	end)
	local losa = f.Plataformas["Plataforma de llegada"]
	local function aterrizar(p, lateral)
		local pos = losa.Position + Vector3.new(lateral, 10, 0)
		local raiz = situar(p, pos)
		raiz.Anchored = true
		-- Los dos clientes pueden seguir cargando el mapa. Mantener el vuelo vigente
		-- mientras se sostiene al personaje y empezar la ventana de caída al soltarlo.
		local hasta = os.clock() + .4
		repeat
			p:SetAttribute("PlaneoIslaHasta", workspace:GetServerTimeNow() + 3)
			task.wait(.05)
		until os.clock() >= hasta
		assert(not p:GetAttribute("EnFaro") and f:GetAttribute("TitularExpedicion") ~= p.UserId, "Entrada antes de aterrizar")
		p:SetAttribute("PlaneoIslaHasta", workspace:GetServerTimeNow() + 3)
		raiz.Anchored = false
	end
	for _, p in {a, b} do p:SetAttribute("Lucero", true) end
	turno(f, nil)
	aterrizar(a, 3)
	turno(f, a)
	situar(a, f.Rastro.Position + Vector3.new(-2, 2, 0))
	pedir(a, "lucero")
	esperar("rastro del primer jugador", 4, function() return f:GetAttribute("RastroRevelado") end)
	pedir(a, "activar", f.Girar.Accion)
	esperar("primero enciende el faro", 4, function() return a:GetAttribute("FaroEncendido") end)
	aterrizar(b, -3)
	esperar("segundo espera en la losa", 5, function() return b:GetAttribute("EsperaFaro") end)
	assert(f:GetAttribute("TitularExpedicion") == a.UserId and not b:GetAttribute("EnFaro"))
	assert(not b:GetAttribute("FaroEncendido") and not b:GetAttribute("Prisma"))
	local anterior = a.Character
	anterior:FindFirstChildOfClass("Humanoid").Health = 0
	turno(f, b)
	assert(b:GetAttribute("EnFaro") and not b:GetAttribute("EsperaFaro"))
	assert(not f:GetAttribute("RastroRevelado") and not f.Girar.Accion.Enabled, "El segundo heredó el espejo")
	assert(f.Puerta.CanCollide and not f.Linterna.Luz.Enabled, "El segundo heredó la luz o la cámara del primero")
	assert(not b:GetAttribute("FaroEncendido") and not b:GetAttribute("Prisma"))
	b:SetAttribute("LenteGeoda", true)
	situar(b, f.Rastro.Position + Vector3.new(-2, 2, 0))
	pedir(b, "lucero")
	esperar("rastro del segundo jugador", 4, function() return f.Montura.Accion.Enabled end)
	pedir(b, "activar", f.Montura.Accion)
	pedir(b, "activar", f.Girar.Accion)
	esperar("segundo enciende su faro", 4, function() return b:GetAttribute("FaroEncendido") end)
	pedir(b, "activar", f.Girar.Accion)
	esperar("cámara abierta", 4, function() return f.Prisma.Accion.Enabled end)
	esperar("reaparición en el faro", 12, function() return a.Character ~= anterior and personaje(a) end)
	aterrizar(a, 3)
	esperar("reingreso del primero en espera", 5, function() return a:GetAttribute("EsperaFaro") end)
	pedir(b, "activar", f.Prisma.Accion)
	turno(f, a)
	assert(a:GetAttribute("EnFaro") and b:GetAttribute("EnFaro") and b:GetAttribute("Prisma"))
	assert(not a:GetAttribute("Prisma") and not f:GetAttribute("RastroRevelado") and f.Puerta.CanCollide)
	assert(f.Linterna.Luz.Enabled, "No se restauró la linterna del jugador que vuelve")
	pedir(b, "activar", f.Prisma.CaminoDePrisma)
	local torre = f.RescateNimbo
	esperar("paso personal al pie de la torre", 4, function()
		return (personaje(b).Position - torre.Ascensor.Position).Magnitude < 7
	end)
	pedir(b, "activar", torre.Ascensor.Subir)
	esperar("jugador con Prisma llega al balcón", 5, function() return b:GetAttribute("RescateNimbo") == "Balcon" end)
	pedir(b, "activar", f.Regreso.Accion)
	esperar("salida del visitante con Prisma", 4, function() return not b:GetAttribute("EnFaro") end)
	assert(a:GetAttribute("EnFaro") and f:GetAttribute("TitularExpedicion") == a.UserId)
	pedir(a, "activar", f.Regreso.Accion)
	turno(f, nil)
	assert(not a:GetAttribute("EnFaro"))
	return "OK: aterrizaje físico; relevo por muerte y al ganar Prisma; progreso aislado, luz restaurada y acceso personal a la torre mientras el otro usa el espejo."
end

local ok, mensaje = xpcall(function()
	local pareja = esperar("dos clientes y perfiles", 65, function()
		local jugadores = Players:GetPlayers()
		if #jugadores ~= 2 then return end
		for _, p in jugadores do
			if not listos[p] or not p:GetAttribute("ProgresoListo") or not personaje(p) then return end
		end
		return jugadores
	end)
	for _, p in pareja do
		assert(p:GetAttribute("ModoGuardado") == "Sesion", "Esta prueba requiere perfiles temporales")
		assert(not p:GetAttribute("Cometa") and not p:GetAttribute("Lucero"), "Se necesitan perfiles nuevos")
	end
	for _, p in pareja do p:SetAttribute("Cometa", true) end
	local isla = workspace.IslaDelViento
	if caso == "TurnosFaroQA" then return probarFaro(pareja[1], pareja[2], isla) end
	return cuevaYMolino(pareja[1], pareja[2], isla)
end, debug.traceback)
finalizar(if ok then mensaje else "FALLO en " .. etapa .. ": " .. tostring(mensaje))
