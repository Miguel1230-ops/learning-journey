local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")

local datos = require(ServerScriptService:WaitForChild("ProgresoDatos"))
local isla = workspace:WaitForChild("IslaDelViento")
local molino = isla:WaitForChild("MolinoDelViento")
local remoto = ReplicatedStorage:WaitForChild("AccionMolino")
local llegada = molino:WaitForChild("Llegada")
local despegue = molino:WaitForChild("PlayaDespegue")
local zona = molino:WaitForChild("ZonaViento")
local chispa = molino:WaitForChild("Chispa")
local farol = molino:WaitForChild("Farol")
local lucero = molino:WaitForChild("Lucero")
local aspas = molino:WaitForChild("Aspas")
local marcoAspas = aspas:GetPivot()
local marcoChispa = chispa.CFrame
local marcoLucero = lucero:GetPivot()

local ORO = Color3.fromRGB(255, 213, 131)
local MENTA = Color3.fromRGB(149, 244, 224)
local CIELO = Color3.fromRGB(120, 207, 255)
local LLEGADA_DURACION = 6.25
local FINAL_DURACION = 3.7
local ESCUDO_DURACION = 2.35
local MEDIO = zona.Position.X

local luces = {}
for _, hijo in ipairs(molino:WaitForChild("Luces"):GetChildren()) do
	if hijo:IsA("BasePart") then
		table.insert(luces, hijo)
	end
end
table.sort(luces, function(a, b)
	return a.Name < b.Name
end)

local partesLucero = {}
for _, objeto in ipairs(lucero:GetDescendants()) do
	if objeto:IsA("BasePart") then
		partesLucero[objeto] = objeto.Transparency
		objeto.Transparency = 1
	elseif objeto:IsA("Light") then
		objeto.Enabled = false
	end
end

local fase = "Fuera"
local jugador
local hasta = 0
local escenaDesde = 0
local apagadaHasta = 0
local oleadasDesde = 0
local escudoHasta = 0
local escudoListo = 0
local desgaste = 0
local cruzoProtegido = false
local chispaEnManos = false
local iluminado = false
local origenLuz = 0
local lucesEncendidas = 0
local luceroVisible = false
local saludInicial
local burbuja

local function reloj()
	return workspace:GetServerTimeNow()
end

local function estadoPieza(pieza, brillo, activa)
	pieza.Color = brillo
	pieza.Material = if activa then Enum.Material.Neon else Enum.Material.SmoothPlastic
	local luz = pieza:FindFirstChildWhichIsA("Light")
	if luz then
		luz.Color = brillo
		luz.Enabled = activa
	end
end

local function ponerFase(nueva, pista)
	fase = nueva
	molino:SetAttribute("MolinoFase", nueva)
	molino:SetAttribute("PistaMolino", pista)
end

local function interactuar(pieza, accion, titulo, distancia, tecla)
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "Accion"
	prompt.ActionText = accion
	prompt.ObjectText = titulo
	prompt.MaxActivationDistance = distancia
	prompt.RequiresLineOfSight = false
	prompt.KeyboardKeyCode = tecla or Enum.KeyCode.E
	prompt.ClickablePrompt = true
	prompt.Enabled = false
	prompt.Parent = pieza
	return prompt
end

local recoger = interactuar(chispa, "Recoger chispa", "Chispa del molino", 7.5)
local encender = interactuar(farol, "Colocar chispa", "Farol del molino", 7.2)
local salir = interactuar(molino:WaitForChild("Regreso"), "Volver a la plaza", "Isla del Viento", 7.3)

local function avatar(quien)
	local personaje = quien and quien.Character
	local h = personaje and personaje:FindFirstChildOfClass("Humanoid")
	local root = personaje and personaje:FindFirstChild("HumanoidRootPart")
	if root and h and h.Health > 0 then
		return root, h
	end
	return nil, nil
end

local function cerca(quien, prompt)
	local root = avatar(quien)
	return quien == jugador and root and prompt.Enabled
		and (root.Position - prompt.Parent.Position).Magnitude <= prompt.MaxActivationDistance + 0.65
end

local function mover(quien, punto, objetivo)
	local root = avatar(quien)
	if root then
		local frente = Vector3.new(objetivo.X, punto.Y, objetivo.Z)
		quien.Character:PivotTo(CFrame.lookAt(punto, frente))
		root.AssemblyLinearVelocity = Vector3.zero
	end
end

local function dentroXZ(pieza, posicion, margen)
	local localPos = pieza.CFrame:PointToObjectSpace(posicion)
	local media = pieza.Size * 0.5
	return math.abs(localPos.X) <= media.X + margen and math.abs(localPos.Z) <= media.Z + margen
end

local function limpiarEscudo()
	escudoHasta, escudoListo = 0, 0
	jugador:SetAttribute("EscudoMolinoHasta", 0)
	jugador:SetAttribute("EscudoMolinoListoEn", 0)
	if burbuja then
		burbuja:Destroy()
		burbuja = nil
	end
end

local function soltar()
	chispaEnManos = false
	jugador:SetAttribute("LlevaChispa", false)
	chispa.CFrame = marcoChispa
	chispa.Transparency = if iluminado then 1 else 0.04
	estadoPieza(chispa, ORO, not iluminado)
	encender.Enabled = false
end

local function prepararChispa()
	hasta = 0
	if iluminado then
		ponerFase("Final", "Lucero despertó. El molino ya ilumina la isla.")
		salir.ActionText = if isla:FindFirstChild("RefugioDelViento") then "Volver al refugio" else "Volver a la plaza"
	else
		ponerFase("BuscarChispa", "Recoge la chispa. Pedernal puede protegerla en el pasadizo.")
		recoger.Enabled = true
	end
	salir.Enabled = true
end

local function empezarLlegada(t)
	if jugador:GetAttribute("MolinoVista") then
		prepararChispa()
		return
	end
	jugador:SetAttribute("MolinoVista", true)
	escenaDesde = t + 0.20
	hasta = escenaDesde + LLEGADA_DURACION + 0.1
	ponerFase("Llegada", "")
	remoto:FireClient(jugador, "Llegada", escenaDesde, LLEGADA_DURACION)
end

local function iniciarAterrizaje(root, t)
	jugador:SetAttribute("EnMolino", true)
	jugador:SetAttribute("EstadoChispa", "Segura")
	apagadaHasta = 0
	ponerFase("Aterrizando", "Estás llegando al molino.")
	hasta = t + 0.72
	root.AssemblyLinearVelocity = Vector3.new(0, math.min(root.AssemblyLinearVelocity.Y, -6), 0)
end

local function restaurarPlaza(quien)
	limpiarEscudo()
	soltar()
	recoger.Enabled = false
	salir.Enabled = false
	apagadaHasta = 0
	ponerFase("Fuera", "")
	quien:SetAttribute("EnMolino", false)
	quien:SetAttribute("EstadoChispa", "Segura")
end

salir.Triggered:Connect(function(quien)
	if cerca(quien, salir) and quien:GetAttribute("EnMolino") then
		restaurarPlaza(quien)
		local refugio = isla:FindFirstChild("RefugioDelViento")
		local farero = refugio and refugio:FindFirstChild("PuntoFarero")
		if iluminado and farero then
			quien:SetAttribute("Refugio", true)
			mover(quien, Vector3.new(80.75, 23.65, 5.5), farero.Position)
		else
			mover(quien, Vector3.new(despegue.Position.X, 23.65, despegue.Position.Z - 1.05), llegada.Position)
		end
	end
end)

local function tomar(quien)
	if not cerca(quien, recoger) or fase ~= "BuscarChispa" or iluminado then
		return
	end
	recoger.Enabled = false
	salir.Enabled = false
	chispaEnManos = true
	cruzoProtegido = false
	desgaste = 0
	oleadasDesde = reloj()
	jugador:SetAttribute("LlevaChispa", true)
	jugador:SetAttribute("EstadoChispa", "Segura")
	jugador:SetAttribute("FuerzaChispa", 1)
	ponerFase("Transportar", "Protege la chispa con Pedernal mientras la llevas al farol.")
end
recoger.Triggered:Connect(tomar)

local function despertar(t)
	iluminado = true
	origenLuz = t
	molino:SetAttribute("MolinoEncendido", true)
end

local function premio(quien)
	if not cerca(quien, encender) or fase ~= "Transportar" or not chispaEnManos or not cruzoProtegido then
		return
	end
	escenaDesde = reloj() + 0.20
	hasta = escenaDesde + FINAL_DURACION + 0.10
	despertar(escenaDesde)
	soltar()
	limpiarEscudo()
	salir.Enabled = false
	ponerFase("Despertar", "")
	quien:SetAttribute("Lucero", true)
	remoto:FireClient(quien, "Despertar", escenaDesde, FINAL_DURACION)
end
encender.Triggered:Connect(premio)

local function escudo(quien, root, t)
	if fase ~= "Transportar" or not quien:GetAttribute("Pedernal") or t < escudoListo
		or not dentroXZ(zona, root.Position, 8.75) or root.Position.Y > llegada.Position.Y + 11 then
		return
	end
	escudoHasta = t + ESCUDO_DURACION
	escudoListo = t + datos.RecargaEscudo({ MejoraPedernal = quien:GetAttribute("MejoraPedernal") == true })
	quien:SetAttribute("EscudoMolinoHasta", escudoHasta)
	quien:SetAttribute("EscudoMolinoListoEn", escudoListo)
end

remoto.OnServerEvent:Connect(function(quien, accion)
	if quien ~= jugador or not quien:GetAttribute("EnMolino") then
		return
	end
	local root = avatar(quien)
	if not root then
		return
	end
	if accion == "Escudo" then
		escudo(quien, root, reloj())
	elseif accion == "TerminarLlegada" and fase == "Llegada" then
		prepararChispa()
	end
end)

local function actualizarEscudo(root, activo)
	if activo then
		if not burbuja then
			burbuja = Instance.new("Part")
			burbuja.Name = "EscudoPedernal"
			burbuja.Shape = Enum.PartType.Ball
			burbuja.Size = Vector3.new(6.8, 6.8, 6.8)
			burbuja.Anchored = true
			burbuja.CanCollide = false
			burbuja.CanTouch = false
			burbuja.CanQuery = false
			burbuja.CastShadow = false
			burbuja.Transparency = 0.87
			burbuja.Color = CIELO
			burbuja.Material = Enum.Material.ForceField
			burbuja.Position = root.Position
			burbuja.Parent = molino
		end
		burbuja.Position = root.Position
	elseif burbuja then
		burbuja:Destroy()
		burbuja = nil
	end
end

local function apagarChispa(t)
	soltar()
	limpiarEscudo()
	apagadaHasta = t + 1.45
	salir.Enabled = true
	jugador:SetAttribute("EstadoChispa", "Apagada")
	ponerFase("BuscarChispa", "La chispa volvió a su pedestal. Activa el escudo justo antes de cruzar.")
	local atras = marcoChispa.Position - Vector3.xAxis * 2
	mover(jugador, Vector3.new(atras.X, llegada.Position.Y + 0.95, atras.Z), zona.Position)
end

local function transportar(root, t, dt)
	local enViento = dentroXZ(zona, root.Position, 0)
	local protegido = t < escudoHasta
	local ciclo = (t - oleadasDesde) % 3.7
	local rafaga = ciclo >= 1.43 and ciclo < 2.48
	local aviso = ciclo >= 0.70 and ciclo < 1.43
	local oleada = if rafaga then "Rafaga" elseif aviso then "Aviso" else "Calma"
	molino:SetAttribute("EstadoViento", oleada)

	if protegido and enViento and root.Position.X >= MEDIO then
		cruzoProtegido = true
	end
	if enViento and not protegido then
		desgaste += dt * (if rafaga then 3.6 else 1.23)
		if desgaste >= 1 then
			apagarChispa(t)
			return
		end
	elseif protegido then
		desgaste = math.max(0, desgaste - dt * 2.7)
	end
	local estado = if protegido then "Protegida" elseif enViento then "En riesgo"
		elseif aviso and dentroXZ(zona, root.Position, 6) then "Alerta" else "Segura"
	jugador:SetAttribute("EstadoChispa", estado)
	jugador:SetAttribute("FuerzaChispa", math.ceil((1 - desgaste) * 25) / 25)
	encender.Enabled = cruzoProtegido
	chispa.CFrame = CFrame.new(root.Position + root.CFrame.LookVector * 1.8 + Vector3.yAxis * (0.58 + math.sin(t * 6) * 0.15))
		* CFrame.Angles(t % 6, t % 6, math.rad(26))
	chispa.Color = if protegido then MENTA else ORO:Lerp(Color3.fromRGB(191, 110, 109), desgaste)
	chispa.Transparency = desgaste * 0.55
	actualizarEscudo(root, protegido)
end

local function actualizarMundo(t)
	if not iluminado then
		return
	end
	local edad = t - origenLuz
	if edad < 0 then
		return
	end
	if edad >= 0.16 and lucesEncendidas == 0 then
		estadoPieza(farol, ORO, true)
	end
	local cantidad = math.clamp(math.floor((edad - 0.28) / 0.071) + 1, 0, #luces)
	for i = lucesEncendidas + 1, cantidad do
		estadoPieza(luces[i], ORO, true)
	end
	lucesEncendidas = cantidad
	local giro = if edad < 1.3 then edad * edad * 0.73 else (edad - 0.65) * 1.9
	aspas:PivotTo(marcoAspas * CFrame.Angles(0, 0, -giro))
	if edad >= 0.80 and not luceroVisible then
		luceroVisible = true
		for pieza, transparencia in pairs(partesLucero) do
			pieza.Transparency = transparencia
		end
		for _, objeto in ipairs(lucero:GetDescendants()) do
			if objeto:IsA("Light") then
				objeto.Enabled = true
			end
		end
	end
	if luceroVisible then
		local ascenso = 1 - (1 - math.clamp((edad - 0.8) / .85, 0, 1)) ^ 3
		lucero:PivotTo((marcoLucero + Vector3.yAxis * (ascenso * 1.85 + math.sin(edad * 3.2) * 0.21))
			* CFrame.Angles(0, (1 - ascenso) * 0.53, math.sin(edad * 2.4) * 0.072))
	end
end

local function registrar(nuevo)
	if jugador then
		return
	end
	jugador = nuevo
	for _, propiedad in ipairs({ "EnMolino", "LlevaChispa", "MolinoVista", "Lucero" }) do
		if nuevo:GetAttribute(propiedad) == nil then
			nuevo:SetAttribute(propiedad, false)
		end
	end
	nuevo:SetAttribute("EstadoChispa", "Segura")
	nuevo:SetAttribute("FuerzaChispa", 1)
	nuevo:SetAttribute("EscudoMolinoHasta", 0)
	nuevo:SetAttribute("EscudoMolinoListoEn", 0)
	local function recuperar()
		if nuevo:GetAttribute("Lucero") and not iluminado then
			despertar(reloj() - 4.5)
			soltar()
			if nuevo:GetAttribute("EnMolino") then
				prepararChispa()
			end
		end
	end
	nuevo:GetAttributeChangedSignal("Lucero"):Connect(recuperar)
	nuevo:GetAttributeChangedSignal("ProgresoRevision"):Connect(recuperar)
	recuperar()
end

if RunService:IsStudio() and game.GameId == 0 and isla:GetAttribute("AtajosDePrueba") == true then
	local prueba = Instance.new("Part")
	prueba.Name = "PruebaDelMolino"
	prueba.Anchored = true
	prueba.CanCollide = false
	prueba.CanTouch = false
	prueba.Material = Enum.Material.Neon
	prueba.Color = Color3.fromRGB(255, 160, 83)
	prueba.Size = Vector3.new(1.56, 1.75, 1.56)
	prueba.CFrame = CFrame.new(-50.9, 22.20, -4.9) * CFrame.Angles(0, 0, math.rad(42))
	prueba.Parent = isla
	local ir = interactuar(prueba, "Probar el molino", "Molino del Viento", 7.4)
	ir.Enabled = true
	ir.Triggered:Connect(function(quien)
		if not cerca(quien, ir) or quien:GetAttribute("EnCueva") or not quien:GetAttribute("ProgresoListo")
			or isla:GetAttribute("Fase") == "Defensa" then
			return
		end
		quien:SetAttribute("Cometa", true)
		quien:SetAttribute("Pedernal", true)
		local p = despegue.Position
		mover(quien, Vector3.new(p.X, 23.65, p.Z - 1.12), llegada.Position)
	end)
end

ponerFase("Fuera", "")
molino:SetAttribute("EstadoViento", "Calma")
molino:SetAttribute("MolinoEncendido", false)
Players.PlayerAdded:Connect(registrar)
for _, conectado in ipairs(Players:GetPlayers()) do
	registrar(conectado)
end

while true do
	local dt = math.min(task.wait(0.045), 0.1)
	local t = reloj()
	actualizarMundo(t)
	local root, h = avatar(jugador)
	if not root then
		if jugador and jugador:GetAttribute("EnMolino") then
			restaurarPlaza(jugador)
		end
		saludInicial = nil
		continue
	end
	if saludInicial ~= h then
		if jugador:GetAttribute("EnMolino") then
			restaurarPlaza(jugador)
		end
		saludInicial = h
	end

	if fase == "Fuera" then
		if jugador:GetAttribute("ProgresoListo") and not jugador:GetAttribute("EnCueva")
			and jugador:GetAttribute("Cometa") and jugador:GetAttribute("Pedernal")
			and (jugador:GetAttribute("PlaneoIslaHasta") or 0) > t
			and dentroXZ(llegada, root.Position, 0.5)
			and math.abs(root.Position.Y - llegada.Position.Y) < 13.1 then
			iniciarAterrizaje(root, t)
		end
	elseif fase == "Aterrizando" then
		if root.Position.Y <= llegada.Position.Y + 2.1 or t >= hasta then
			local p = llegada.Position
			mover(jugador, Vector3.new(p.X, p.Y + 0.96, p.Z), chispa.Position)
			empezarLlegada(t)
		end
	elseif root.Position.Y < 12.0 or root.Position.Z < llegada.Position.Z - 14 then
		restaurarPlaza(jugador)
	elseif fase == "Llegada" or fase == "Despertar" then
		if t >= hasta then
			prepararChispa()
		end
	elseif fase == "Transportar" then
		transportar(root, t, dt)
	elseif apagadaHasta > 0 and t >= apagadaHasta then
		recoger.Enabled = true
		apagadaHasta = 0
		jugador:SetAttribute("EstadoChispa", "Segura")
	end
	if fase ~= "Transportar" then
		molino:SetAttribute("EstadoViento", "Calma")
	end
end
