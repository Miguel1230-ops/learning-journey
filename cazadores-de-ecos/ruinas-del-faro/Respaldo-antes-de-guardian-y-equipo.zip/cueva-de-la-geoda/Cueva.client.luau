-- Controles y guía contextual de la expedición a la Geoda.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ContextActionService = game:GetService("ContextActionService")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")

local jugador = Players.LocalPlayer
local playerGui = jugador:WaitForChild("PlayerGui")
local cueva = workspace:WaitForChild("CuevaDeLaGeoda")
local guardian = cueva:WaitForChild("Guardian")
local cristal = guardian:WaitForChild("CristalEspalda")
local puerta = cueva:WaitForChild("Ruta"):WaitForChild("PuertaViento")
local accion = ReplicatedStorage:WaitForChild("AccionGeoda")

local CARBON = Color3.fromRGB(14, 24, 36)
local PIZARRA = Color3.fromRGB(33, 51, 69)
local PERLA = Color3.fromRGB(246, 249, 247)
local SUAVE = Color3.fromRGB(208, 223, 231)
local APAGADO = Color3.fromRGB(139, 162, 177)
local MENTA = Color3.fromRGB(124, 242, 206)
local ORO = Color3.fromRGB(255, 210, 126)
local AZUL = Color3.fromRGB(153, 220, 255)
local CORAL = Color3.fromRGB(255, 151, 138)

-- Mismas distancias, altura y orientación que valida Guardian.server.luau.
local DISTANCIA_COMETA_MINIMA = 0.2
local DISTANCIA_COMETA = 26
local DISTANCIA_CRISTAL = 12.6
local LIMITE_DEL_FRENTE = 0.35

local function redondear(objeto, radio)
	local curva = Instance.new("UICorner")
	curva.CornerRadius = UDim.new(0, radio)
	curva.Parent = objeto
end

local function borde(objeto, tono, grosor, transparencia)
	local linea = Instance.new("UIStroke")
	linea.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	linea.Color = tono
	linea.Thickness = grosor
	linea.Transparency = transparencia or 0
	linea.Parent = objeto
	return linea
end

local function etiqueta(padre, nombre, texto, tono, tamano, pos, medida, negrita)
	local e = Instance.new("TextLabel")
	e.Name = nombre
	e.Position = pos
	e.Size = medida
	e.BackgroundTransparency = 1
	e.Text = texto
	e.TextColor3 = tono
	e.TextSize = tamano
	e.Font = if negrita then Enum.Font.GothamBold else Enum.Font.GothamMedium
	e.TextXAlignment = Enum.TextXAlignment.Left
	e.TextWrapped = true
	e.Parent = padre
	return e
end

local function superficie(padre, clase, nombre, medida, ancho, pos, ancla)
	local f = Instance.new(clase)
	f.Name = nombre
	f.Size = medida
	f.AnchorPoint = ancla or Vector2.zero
	f.Position = pos
	f.BackgroundColor3 = CARBON
	f.BackgroundTransparency = 0.08
	f.BorderSizePixel = 0
	redondear(f, 11)
	local limite = Instance.new("UISizeConstraint")
	limite.MaxSize = Vector2.new(ancho, medida.Y.Offset)
	limite.Parent = f
	f.Parent = padre
	return f
end

local gui = Instance.new("ScreenGui")
gui.Name = "CuevaDeLaGeodaHUD"
gui.ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets
gui.ResetOnSpawn = false
gui.Enabled = false
gui.Parent = playerGui

local guardia = superficie(gui, "Frame", "VidaDelGuardian", UDim2.fromOffset(204, 33), 204,
	UDim2.new(0.5, 0, 0, 8), Vector2.new(0.5, 0))
borde(guardia, PIZARRA, 1)
etiqueta(guardia, "Nombre", "GUARDIÁN", SUAVE, 11, UDim2.fromOffset(13, 5), UDim2.fromOffset(101, 23), true)
local cristales = {}
for i = 1, 3 do
	local cristalVida = Instance.new("Frame")
	cristalVida.Name = "Cristal" .. i
	cristalVida.Size = UDim2.fromOffset(12, 12)
	cristalVida.Position = UDim2.fromOffset(123 + (i - 1) * 25, 11)
	cristalVida.BorderSizePixel = 0
	cristalVida.Rotation = 45
	cristalVida.BackgroundColor3 = ORO
	redondear(cristalVida, 2)
	local filo = borde(cristalVida, ORO, 1, 0.14)
	cristalVida.Parent = guardia
	cristales[i] = { pieza = cristalVida, filo = filo }
end

local objetivo = superficie(gui, "Frame", "Objetivo", UDim2.new(1, -26, 0, 67), 316,
	UDim2.fromOffset(13, 8))
borde(objetivo, PIZARRA, 1)
local titulo = etiqueta(objetivo, "Titulo", "", PERLA, 15, UDim2.fromOffset(13, 5), UDim2.new(1, -26, 0, 23), true)
local pista = etiqueta(objetivo, "Pista", "", SUAVE, 12, UDim2.fromOffset(13, 29), UDim2.new(1, -26, 0, 31), false)

local aviso = superficie(gui, "TextButton", "Instruccion", UDim2.new(1, -32, 0, 53), 326,
	UDim2.new(0.5, 0, 1, -50), Vector2.new(0.5, 1))
aviso.Text = ""
aviso.AutoButtonColor = false
aviso.Selectable = false
aviso.Visible = false
local filoAviso = borde(aviso, MENTA, 1, 0.28)
local tecla = Instance.new("TextLabel")
tecla.Name = "Tecla"
tecla.Position = UDim2.fromOffset(9, 9)
tecla.Size = UDim2.fromOffset(51, 35)
tecla.BackgroundColor3 = MENTA
tecla.BorderSizePixel = 0
tecla.Font = Enum.Font.GothamBold
tecla.TextColor3 = CARBON
tecla.TextSize = 13
redondear(tecla, 8)
tecla.Parent = aviso
local tituloAviso = etiqueta(aviso, "Accion", "", PERLA, 16, UDim2.fromOffset(70, 5), UDim2.new(1, -79, 0, 21), true)
local detalleAviso = etiqueta(aviso, "Detalle", "", SUAVE, 11, UDim2.fromOffset(70, 27), UDim2.new(1, -79, 0, 21), false)

local ayuda = superficie(gui, "Frame", "Controles", UDim2.new(1, -34, 0, 25), 318,
	UDim2.new(0.5, 0, 1, -12), Vector2.new(0.5, 1))
local teclas = etiqueta(ayuda, "Teclas", "", SUAVE, 11, UDim2.fromOffset(8, 0), UDim2.new(1, -16, 1, 0), true)
teclas.TextXAlignment = Enum.TextXAlignment.Center

local function botonMovil(nombre, margen)
	local b = superficie(gui, "TextButton", nombre, UDim2.fromOffset(101, 43), 101,
		UDim2.new(1, -17, 1, -margen), Vector2.new(1, 1))
	b.TextColor3 = PERLA
	b.TextSize = 13
	b.Font = Enum.Font.GothamBold
	b.Visible = false
	borde(b, PIZARRA, 1)
	return b
end
local botonPulso = botonMovil("Rafaga", 124)
local botonCompanero = botonMovil("Companero", 175)

local marcador = Instance.new("BillboardGui")
marcador.Name = "CristalExpuesto"
marcador.Adornee = cristal
marcador.Size = UDim2.fromOffset(88, 25)
marcador.StudsOffsetWorldSpace = Vector3.new(0, 1.9, 0)
marcador.MaxDistance = 42
marcador.Enabled = false
marcador.Parent = playerGui
local marca = etiqueta(marcador, "Marca", "PUNTO DÉBIL", MENTA, 10, UDim2.fromOffset(0, 0), UDim2.fromScale(1, 1), true)
marca.TextXAlignment = Enum.TextXAlignment.Center
marca.TextStrokeColor3 = CARBON
marca.TextStrokeTransparency = 0.25

local hudIsla
local estadoIsla
local function actualizarPantallas()
	local dentro = jugador:GetAttribute("EnCueva") == true
	gui.Enabled = dentro and jugador:GetAttribute("GeodaPresentando") ~= true
	if not gui.Enabled then
		marcador.Enabled = false
	end
	local uiIsla = playerGui:FindFirstChild("IslaDelVientoHUD")
	if uiIsla and uiIsla:IsA("ScreenGui") then
		if dentro then
			if hudIsla ~= uiIsla then
				hudIsla = uiIsla
				estadoIsla = uiIsla.Enabled
			end
			uiIsla.Enabled = false
		elseif hudIsla == uiIsla then
			uiIsla.Enabled = estadoIsla
			hudIsla, estadoIsla = nil, nil
		end
	end
end
playerGui.ChildAdded:Connect(function(nuevo)
	if nuevo.Name == "IslaDelVientoHUD" then
		actualizarPantallas()
	end
end)
jugador:GetAttributeChangedSignal("EnCueva"):Connect(actualizarPantallas)
jugador:GetAttributeChangedSignal("GeodaPresentando"):Connect(actualizarPantallas)
actualizarPantallas()

local function enCombate()
	return cueva:GetAttribute("Fase") == "Combate"
end

local ultimaOrden = -1
local function enviar(tipo)
	if not gui.Enabled then
		return
	end
	local tiempo = os.clock()
	if tiempo - ultimaOrden >= 0.12 then
		ultimaOrden = tiempo
		accion:FireServer(tipo)
	end
end

local function rafaga()
	if enCombate() and (jugador:GetAttribute("PulsoCuevaListoEn") or 0) <= workspace:GetServerTimeNow() then
		enviar("Rafaga")
	end
end

local function companero()
	local ahora = workspace:GetServerTimeNow()
	if enCombate() then
		if (jugador:GetAttribute("OrdenCometaListaEn") or 0) <= ahora then
			enviar("Cometa")
		end
	elseif jugador:GetAttribute("Pedernal") and (jugador:GetAttribute("EscudoHasta") or 0) <= ahora then
		enviar("Escudo")
	end
end

local function vincular(nombre, responder, disponible, teclaFisica, mando)
	ContextActionService:BindActionAtPriority(nombre, function(_, entrada)
		if jugador:GetAttribute("EnCueva") ~= true or UserInputService:GetFocusedTextBox() then
			return Enum.ContextActionResult.Pass
		end
		if jugador:GetAttribute("GeodaPresentando") then
			return Enum.ContextActionResult.Sink
		end
		if not disponible() then
			return Enum.ContextActionResult.Pass
		end
		if entrada == Enum.UserInputState.Begin then
			responder()
		end
		return Enum.ContextActionResult.Sink
	end, false, Enum.ContextActionPriority.High.Value, teclaFisica, mando)
end
vincular("GeodaRafaga", rafaga, enCombate, Enum.KeyCode.Q, Enum.KeyCode.ButtonX)
vincular("GeodaCompanero", companero, function()
	return enCombate() or jugador:GetAttribute("Pedernal") == true
end, Enum.KeyCode.C, Enum.KeyCode.ButtonY)
botonPulso.Activated:Connect(rafaga)
botonCompanero.Activated:Connect(companero)

local accionAviso
local hayAviso = false
aviso.Activated:Connect(function()
	if accionAviso then
		accionAviso()
	end
end)

local function mostrarAviso(texto, detalle, tono, teclaTexto, fn)
	accionAviso = fn
	hayAviso = true
	aviso.Interactable = fn ~= nil
	filoAviso.Color = tono
	tecla.Visible = teclaTexto ~= nil
	tecla.Text = teclaTexto or ""
	tecla.BackgroundColor3 = tono
	local margen = if teclaTexto then 70 else 13
	tituloAviso.Position = UDim2.fromOffset(margen, 6)
	tituloAviso.Size = UDim2.new(1, -margen - 10, 0, 21)
	tituloAviso.Text = texto
	tituloAviso.TextColor3 = tono
	detalleAviso.Position = UDim2.fromOffset(margen, 27)
	detalleAviso.Size = UDim2.new(1, -margen - 10, 0, 21)
	detalleAviso.Text = detalle
end

local function plano(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function raizViva()
	local personaje = jugador.Character
	local humanoide = personaje and personaje:FindFirstChildOfClass("Humanoid")
	if humanoide and humanoide.Health > 0 then
		return personaje:FindFirstChild("HumanoidRootPart")
	end
	return nil
end

local function posiciones(root)
	local base = guardian.PrimaryPart
	if not root or not base then
		return false, false, false
	end
	local lado = plano(root.Position - base.Position)
	local frente = plano(guardian:GetPivot().LookVector)
	if frente.Magnitude > 0.1 then
		frente = frente.Unit
	end
	local espalda = lado.Magnitude <= 0.1 or frente:Dot(lado.Unit) <= LIMITE_DEL_FRENTE
	return lado.Magnitude >= DISTANCIA_COMETA_MINIMA and lado.Magnitude <= DISTANCIA_COMETA,
		(root.Position - cristal.Position).Magnitude <= DISTANCIA_CRISTAL,
		espalda
end

local transcurrido = 0
RunService.Heartbeat:Connect(function(dt)
	if not gui.Enabled then
		return
	end
	transcurrido += dt
	if transcurrido < 0.065 then
		return
	end
	transcurrido = 0
	local fase = cueva:GetAttribute("Fase") or "Inicio"
	local ataque = cueva:GetAttribute("EstadoGuardian")
	local mensaje = cueva:GetAttribute("Titulo")
	local combate = fase == "Combate"
	local pedernal = jugador:GetAttribute("Pedernal") == true
	local reloj = workspace:GetServerTimeNow()
	local listo = (jugador:GetAttribute("PulsoCuevaListoEn") or 0) <= reloj
	local aliadoListo = (jugador:GetAttribute("OrdenCometaListaEn") or 0) <= reloj
	local escudo = math.max(0, (jugador:GetAttribute("EscudoHasta") or 0) - reloj)
	local mando = UserInputService:GetLastInputType().Name:match("^Gamepad") ~= nil
	local tactil = UserInputService.TouchEnabled and not mando
	local disparo = if tactil then "TOCA" elseif mando then "X" else "Q"
	local aliado = if tactil then "TOCA" elseif mando then "Y" else "C"
	local root = raizViva()
	local cometaCerca, cristalCerca, detras = posiciones(root)
	local puedeLlamar = combate and ataque == "Aviso" and cometaCerca and aliadoListo
	local puedeGolpear = combate and ataque == "Expuesto" and cristalCerca and detras and listo
	local distanciaPuerta = root and puerta.CFrame:PointToObjectSpace(root.Position)
	local juntoViento = distanciaPuerta and math.abs(distanciaPuerta.X) <= 10
		and math.abs(distanciaPuerta.Y) <= 6 and math.abs(distanciaPuerta.Z) <= 8
	local cruzado = distanciaPuerta and distanciaPuerta.X > 4
	local vida = math.clamp(cueva:GetAttribute("VidaGuardian") or 3, 0, 3)

	guardia.Visible = combate
	objetivo.Visible = not combate
	hayAviso = false
	accionAviso = nil
	aviso.Position = if tactil then UDim2.new(0.5, 0, 1, -67) else UDim2.new(0.5, 0, 1, -49)
	marcador.Enabled = combate and ataque == "Expuesto"
	marca.TextColor3 = if puedeGolpear then MENTA else SUAVE

	for i, pieza in ipairs(cristales) do
		pieza.pieza.BackgroundColor3 = if i <= vida then ORO else PIZARRA
		pieza.filo.Color = if i <= vida then ORO else APAGADO
		pieza.filo.Transparency = if i <= vida then 0.14 else 0.54
	end

	titulo.Text = mensaje or "Cueva de la Geoda"
	pista.Text = cueva:GetAttribute("Pista") or ""
	if puedeLlamar then
		mostrarAviso("¡Llama a Cometa!", "Distráelo antes de que embista.", ORO, aliado, companero)
	elseif puedeGolpear then
		mostrarAviso("¡Golpea el cristal!", "Ahora está al alcance de tu ráfaga.", MENTA, disparo, rafaga)
	elseif combate and ataque == "Onda" then
		mostrarAviso("¡Salta o sal del círculo!", "La onda golpea el suelo marcado.", CORAL)
	elseif combate and ataque == "Aviso" then
		mostrarAviso("Sal de la línea roja", if cometaCerca then "Cometa necesita recuperarse." else "Acércate para que Cometa pueda distraerlo.", CORAL)
	elseif combate and ataque == "Embestida" then
		mostrarAviso("Esquiva hacia un lado", "El guardián está embistiendo.", CORAL)
	elseif combate and ataque == "Expuesto" then
		if not cristalCerca then
			mostrarAviso("Acércate al cristal", "Sigue el brillo de su espalda.", SUAVE)
		elseif not detras then
			mostrarAviso("Ve a su espalda", "Ahí está el cristal expuesto.", SUAVE)
		else
			mostrarAviso("Prepara la ráfaga", "Se está recargando.", SUAVE)
		end
	elseif combate and ataque == "Recupera" and mensaje == "¡Rompiste una capa de armadura!" then
		mostrarAviso(mensaje, ("Cristales restantes: %d"):format(vida), ORO)
	elseif combate and mensaje == "La ráfaga rebotó en la armadura" then
		mostrarAviso("La armadura bloqueó la ráfaga", "Llama a Cometa cuando aparezca la línea roja.", SUAVE)
	elseif combate and vida == 3 and ataque == "Acecha" then
		mostrarAviso("Espera el aviso de embestida", "Cometa te ayudará a abrir la armadura.", SUAVE)
	elseif fase == "Salida" then
		if cruzado then
			titulo.Text = if cueva:GetAttribute("SelloEncendido") then "Sello de Rebote encendido" else "Mirador de la Geoda"
			pista.Text = "Sigue el camino y enciende la baliza."
		else
			titulo.Text = "Pasadizo de viento"
			pista.Text = "Sigue la luz azul. Activa el escudo al acercarte."
		end
		if escudo > 0 then
			mostrarAviso("Escudo activo", ("Cruza el pasadizo  ·  %.1f s"):format(escudo), AZUL)
		elseif juntoViento and not cruzado and pedernal then
			mostrarAviso("Activa el escudo", "Pedernal te protege del viento.", AZUL, aliado, companero)
		end
	end

	aviso.Visible = hayAviso
	ayuda.Visible = not tactil
	if combate then
		teclas.Text = if mando then "X  Ráfaga   ·   Y  Cometa   ·   A  Saltar" else "Q  Ráfaga   ·   C  Cometa   ·   Espacio  Saltar"
	elseif pedernal then
		teclas.Text = if mando then "Y  Escudo   ·   X  Interactuar" else "C  Escudo   ·   E  Interactuar"
	else
		teclas.Text = if mando then "X  Interactuar" else "E  Interactuar"
	end
	botonPulso.Visible = tactil and combate
	botonPulso.Text = if listo then "Ráfaga" else "Recargando"
	botonPulso.TextColor3 = if puedeGolpear then MENTA elseif listo then PERLA else APAGADO
	botonPulso.BackgroundColor3 = if puedeGolpear then PIZARRA else CARBON
	botonCompanero.Visible = tactil and (combate or pedernal)
	botonCompanero.Position = UDim2.new(1, -17, 1, if combate then -175 else -124)
	botonCompanero.Text = if combate then (if aliadoListo then "Cometa" else "Recargando") else (if escudo > 0 then "Escudo activo" else "Escudo")
	botonCompanero.TextColor3 = if puedeLlamar then ORO elseif combate then PERLA else AZUL
	botonCompanero.BackgroundColor3 = if puedeLlamar or (not combate and juntoViento and not cruzado) then PIZARRA else CARBON
end)
