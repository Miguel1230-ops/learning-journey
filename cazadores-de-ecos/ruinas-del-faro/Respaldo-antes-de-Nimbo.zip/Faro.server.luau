local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local isla = workspace:WaitForChild("IslaDelViento")
local faro = isla:WaitForChild("RuinasDelFaro")
local remoto = ReplicatedStorage:WaitForChild("AccionFaro")
local llegada = faro.Llegada
local espejo = faro.Espejo
local puerta = faro.Puerta
local linterna = faro.Linterna
local veta = faro.Veta
local prisma = faro.Prisma
local oro = Color3.fromRGB(255, 203, 126)
local agua = Color3.fromRGB(141, 232, 218)
local lila = Color3.fromRGB(207, 175, 255)
local fareroPosicion = Vector3.new(85.8, 23.65, -2)
local llegadaRefugio = Vector3.new(82.4, 23.65, 3.1)
local lucero
local jugador
local aterrizajeHasta
local rastro = false
local lente = false
local abierta = false
local encendido = false
local angulo = 0
local girando = false
local GIRO_ESPEJO = TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)

local function reloj()
	return workspace:GetServerTimeNow()
end

local function anunciar(titulo, pista)
	faro:SetAttribute("TituloFaro", titulo)
	faro:SetAttribute("PistaFaro", pista)
end

local function interactuar(parte, titulo, accion, alcance)
	local p = Instance.new("ProximityPrompt")
	p.Name = "Accion"
	p.ObjectText = titulo
	p.ActionText = accion
	p.Enabled = false
	p.MaxActivationDistance = alcance
	p.RequiresLineOfSight = false
	p.ClickablePrompt = true
	p.Parent = parte
	return p
end

local girar = interactuar(faro.Girar, "Espejo de Lucero", "Girar espejo", 6)
local montar = interactuar(faro.Montura, "Anclaje del faro", "Montar lente", 5.5)
local recoger = interactuar(prisma, "Prisma", "Tocar cristal", 5.5)
local regreso = interactuar(faro.Regreso, "Refugio del Viento", "Regresar", 6)
local salida = interactuar(faro.SalidaTerraza, "Refugio del Viento", "Regresar", 6)

local function punto(ubicacion)
	local parte = Instance.new("Part")
	parte.Name = "FinDelHaz"
	parte.Size = Vector3.new(0.17, 0.17, 0.17)
	parte.Position = ubicacion
	parte.Anchored = true
	parte.CanCollide = false
	parte.CanQuery = false
	parte.Transparency = 1
	parte.Parent = faro
	return parte
end

local function crearHaz(desde, hasta, color, ancho, final)
	local a = Instance.new("Attachment")
	a.Parent = desde
	local b = Instance.new("Attachment")
	b.Parent = hasta
	local luz = Instance.new("Beam")
	luz.Attachment0, luz.Attachment1 = a, b
	luz.FaceCamera = true
	luz.Color = ColorSequence.new(color)
	luz.LightEmission = 0.88
	luz.Transparency = NumberSequence.new(0.27, 0.79)
	luz.Width0, luz.Width1 = ancho, final
	luz.Enabled = false
	luz.Parent = desde
	return luz
end

local centro = espejo.PrimaryPart
local haciaLinterna = crearHaz(centro, linterna, oro, 0.6, 0.28)
local haciaVeta = crearHaz(centro, veta, lila, 0.53, 0.34)
local nubes = punto(Vector3.new(96, 32, 101))
local haciaNubes = crearHaz(centro, nubes, agua, 0.46, 0.32)
local entreIslas = crearHaz(linterna, punto(Vector3.new(43, 23.8, 68)), oro, 1.72, 5.6)
local extremoGiro = punto(nubes.Position)
local hazGiro = crearHaz(centro, extremoGiro, agua, 0.48, 0.28)
local destello = Instance.new("PointLight")
destello.Name = "DestelloDeAlineacion"
destello.Range = 12
destello.Brightness = 0
destello.Parent = centro
local clic = Instance.new("Sound")
clic.Name = "ClicDelEspejo"
clic.SoundId = "rbxasset://sounds/volume_slider.ogg"
clic.PlaybackSpeed = 1.18
clic.Volume = 0.55
clic.RollOffMaxDistance = 36
clic.Parent = centro

local function avatar()
	local c = jugador and jugador.Character
	local h = c and c:FindFirstChildOfClass("Humanoid")
	local root = c and c:FindFirstChild("HumanoidRootPart")
	return if h and h.Health > 0 then root else nil
end

local function mover(root, pos, mira)
	root.Parent:PivotTo(CFrame.lookAt(pos, Vector3.new(mira.X, pos.Y, mira.Z)))
	root.AssemblyLinearVelocity = Vector3.zero
end

local function cerca(quien, prompt)
	local root = avatar()
	return quien == jugador and root and prompt.Enabled and quien:GetAttribute("EnFaro")
		and (root.Position - prompt.Parent.Position).Magnitude <= prompt.MaxActivationDistance + 0.65
end

local function mostrarRastro()
	if rastro then
		return
	end
	rastro = true
	faro:SetAttribute("RastroRevelado", true)
	for _, escalon in faro.Escalones:GetChildren() do
		escalon.CanCollide = true
		TweenService:Create(escalon, TweenInfo.new(0.35), { Transparency = 0.13 }):Play()
	end
	anunciar("El camino de Lucero", "Cruza los escalones de luz y gira el espejo hacia la linterna.")
end

local function encenderLinterna()
	if encendido then
		return
	end
	encendido = true
	linterna.Color = oro
	linterna.Material = Enum.Material.Neon
	linterna.Transparency = 0.08
	linterna.Luz.Enabled = true
	entreIslas.Enabled = true
	TweenService:Create(entreIslas, TweenInfo.new(0.78), { Width1 = 7.3 }):Play()
end

local function abrirCamara()
	if abierta then
		return
	end
	abierta = true
	puerta.CanCollide = false
	veta.Luz.Enabled = true
	TweenService:Create(puerta, TweenInfo.new(0.65, Enum.EasingStyle.Quint), {
		Position = puerta.Position + Vector3.yAxis * 8.15,
		Transparency = 0.8,
	}):Play()
end

local function salir(quien, prompt)
	if cerca(quien, prompt) then
		local root = avatar()
		quien:SetAttribute("EnFaro", false)
		mover(root, llegadaRefugio, fareroPosicion)
	end
end
regreso.Triggered:Connect(function(quien) salir(quien, regreso) end)
salida.Triggered:Connect(function(quien) salir(quien, salida) end)

remoto.OnServerEvent:Connect(function(quien, accion)
	if accion ~= "Lucero" or quien ~= jugador or not quien:GetAttribute("EnFaro")
		or not quien:GetAttribute("Lucero") or aterrizajeHasta then
		return
	end
	local root = avatar()
	if root and (root.Position - faro.Rastro.Position).Magnitude <= 13 then
		mostrarRastro()
	end
end)

montar.Triggered:Connect(function(quien)
	if not cerca(quien, montar) or not quien:GetAttribute("LenteGeoda") or not rastro then
		return
	end
	lente = true
	local aro = faro["Aro de la lente"]
	aro.Color = lila
	aro.Transparency = 0.05
	anunciar("Lente montada", "Dirige la luz del espejo hacia la veta violeta junto a la cámara.")
end)

girar.Triggered:Connect(function(quien)
	if girando or not cerca(quien, girar) or not rastro then
		return
	end
	girando = true
	girar.Enabled = false
	faro:SetAttribute("EspejoGirando", true)
	local siguiente = angulo % 3 + 1
	local objetivo = if siguiente == 1 then linterna.Position elseif siguiente == 2 then veta.Position else nubes.Position
	local origen = espejo:GetPivot()
	local destino = CFrame.lookAt(centro.Position, objetivo)
	local objetivoPrevio = if angulo == 1 then linterna.Position elseif angulo == 2 then veta.Position else nubes.Position
	local alcanceInicial = (objetivoPrevio - centro.Position).Magnitude
	local alcanceFinal = (objetivo - centro.Position).Magnitude
	local tono = if siguiente == 1 then oro elseif siguiente == 2 then lila else agua
	local recorrido = Instance.new("NumberValue")
	local function dibujarGiro(avance)
		local pose = origen:Lerp(destino, avance)
		espejo:PivotTo(pose)
		extremoGiro.Position = pose.Position + pose.LookVector * (alcanceInicial + (alcanceFinal - alcanceInicial) * avance)
	end
	haciaLinterna.Enabled, haciaVeta.Enabled, haciaNubes.Enabled = false, false, false
	dibujarGiro(0)
	hazGiro.Enabled = true
	local cambio = recorrido.Changed:Connect(dibujarGiro)
	local animacion = TweenService:Create(recorrido, GIRO_ESPEJO, { Value = 1 })
	animacion:Play()
	animacion.Completed:Wait()
	cambio:Disconnect()
	recorrido:Destroy()
	espejo:PivotTo(destino)
	angulo = siguiente
	hazGiro.Enabled = false
	haciaLinterna.Enabled = angulo == 1
	haciaVeta.Enabled = angulo == 2 or (angulo == 1 and quien:GetAttribute("Prisma") == true)
	haciaNubes.Enabled = angulo == 3
	clic:Play()
	if angulo ~= 3 then
		destello.Color = tono
		destello.Brightness = 2.6
		TweenService:Create(destello, TweenInfo.new(0.24), { Brightness = 0 }):Play()
	end
	girando = false
	faro:SetAttribute("EspejoGirando", false)
	if quien.Parent ~= Players then
		return
	end
	if angulo == 1 then
		encenderLinterna()
		quien:SetAttribute("FaroEncendido", true)
		anunciar("¡Faro encendido!", if lente then "La luz del faro también puede abrir la cámara."
			else "El haz llega hasta el molino. La veta violeta esconde otro camino.")
	elseif angulo == 2 then
		if lente and encendido then
			abrirCamara()
			anunciar("La cámara se abrió", "Sigue la luz violeta hasta el cristal de Prisma.")
		else
			anunciar("La veta refleja la luz", if lente then "Enciende la linterna para dar fuerza al haz."
				else "El anclaje pide la lente que guarda el guardián de la Geoda en su revancha.")
		end
	else
		anunciar("Luz hacia las nubes", "Vuelve a girar el espejo para apuntar a otra superficie.")
	end
end)

recoger.Triggered:Connect(function(quien)
	if not abierta or not lente or not encendido or not cerca(quien, recoger)
		or not quien:GetAttribute("LenteGeoda") or not quien:GetAttribute("FaroEncendido") then
		return
	end
	quien:SetAttribute("Prisma", true)
	haciaLinterna.Enabled, haciaVeta.Enabled, haciaNubes.Enabled = true, true, false
	prisma.Color = agua
	anunciar("¡Lucero aprendió Prisma!", "Ahora el espejo puede iluminar la linterna y la veta con un solo giro.")
end)

local function vivoEnRuinas(nuevo)
	if jugador then
		return
	end
	jugador = nuevo
	nuevo:SetAttribute("EnFaro", false)
	local function restaurar()
		if nuevo:GetAttribute("FaroEncendido") then
			encenderLinterna()
		end
		if nuevo:GetAttribute("Prisma") and not abierta then
			lente = true
			abrirCamara()
			prisma.Color = agua
		end
	end
	nuevo:GetAttributeChangedSignal("ProgresoRevision"):Connect(restaurar)
	restaurar()
end

local function alumbrarRegreso(root, t)
	if not lucero then
		local molino = isla:FindFirstChild("MolinoDelViento")
		local original = molino and molino:FindFirstChild("Lucero")
		if not original then
			return
		end
		lucero = original:Clone()
		lucero.Name = "LuceroExplorador"
		for _, parte in lucero:GetDescendants() do
			if parte:IsA("BasePart") then
				parte.CanCollide = false
				parte.CanTouch = false
				parte.CastShadow = false
			end
		end
		lucero:PivotTo(root.CFrame)
		lucero.Parent = faro
	end
	local posicion = root.Position + root.CFrame.RightVector * 3.35 - root.CFrame.LookVector * 1.45
		+ Vector3.yAxis * (2.1 + math.sin(t * 3.6) * 0.21)
	lucero:PivotTo(lucero:GetPivot():Lerp(CFrame.lookAt(posicion, posicion + root.CFrame.LookVector), 0.26))
end

anunciar("Ruinas del Faro", "Lucero puede iluminar las marcas antiguas.")
Players.PlayerAdded:Connect(vivoEnRuinas)
for _, nuevo in Players:GetPlayers() do
	vivoEnRuinas(nuevo)
end

while task.wait(0.05) do
	local root = avatar()
	local t = reloj()
	if jugador and root and not jugador:GetAttribute("EnFaro") and jugador:GetAttribute("Lucero")
		and not jugador:GetAttribute("EnCueva") and not jugador:GetAttribute("EnMolino")
		and not jugador:GetAttribute("EnEncargoPedernal") and (jugador:GetAttribute("PlaneoIslaHasta") or 0) > t then
		local d = llegada.CFrame:PointToObjectSpace(root.Position)
		if math.abs(d.X) <= llegada.Size.X / 2 and math.abs(d.Z) <= llegada.Size.Z / 2 and math.abs(d.Y) < 13 then
			aterrizajeHasta = t + 0.65
			jugador:SetAttribute("EnFaro", true)
			root.AssemblyLinearVelocity = Vector3.new(0, math.min(root.AssemblyLinearVelocity.Y, -6), 0)
			anunciar("Ruinas del Faro", "Lucero puede iluminar las marcas del suelo.")
		end
	end
	if jugador and jugador:GetAttribute("EnFaro") then
		if not root or root.Position.Y < 11 then
			jugador:SetAttribute("EnFaro", false)
			aterrizajeHasta = nil
		elseif aterrizajeHasta and (t >= aterrizajeHasta or root.Position.Y < llegada.Position.Y + 2.05) then
			aterrizajeHasta = nil
			mover(root, llegada.Position + Vector3.yAxis * 1.05, faro.Rastro.Position)
			if rastro then
				anunciar("Ruinas del Faro", "Sigue el camino de luz de vuelta al espejo.")
			end
		elseif not aterrizajeHasta then
			alumbrarRegreso(root, t)
		end
	elseif lucero then
		lucero:Destroy()
		lucero = nil
	end
	local activo = jugador ~= nil and jugador:GetAttribute("EnFaro") == true and aterrizajeHasta == nil
	regreso.Enabled = activo
	salida.Enabled = activo and rastro
	girar.Enabled = activo and rastro and not girando
	montar.Enabled = activo and rastro and not lente and jugador:GetAttribute("LenteGeoda") == true
	recoger.Enabled = activo and abierta and not jugador:GetAttribute("Prisma")
end
