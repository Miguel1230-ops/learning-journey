-- Modelos del rescate y de las dos apariencias del compañero.
local Escena = {}
local azul = Color3.fromRGB(43, 63, 92)
local perla = Color3.fromRGB(250, 233, 199)
local oro = Color3.fromRGB(254, 173, 83)
local menta = Color3.fromRGB(101, 255, 196)
local violeta = Color3.fromRGB(186, 129, 255)
local v = Vector3.new

local function pieza(padre, nombre, pos, tam, color, forma, material)
	local p = Instance.new("Part")
	p.Name, p.Size, p.Position, p.Color = nombre, tam, pos, color
	p.Shape = forma or Enum.PartType.Block
	p.Material = material or Enum.Material.SmoothPlastic
	p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch = true, false, false, false
	p.Parent = padre
	return p
end

local function ovalo(padre, nombre, pos, tam, color, luminoso)
	return pieza(padre, nombre, pos, tam, color, Enum.PartType.Ball, if luminoso then Enum.Material.Neon else nil)
end

local function segmento(padre, nombre, a, b, grosor, color)
	local p = pieza(padre, nombre, (a+b)/2, v(grosor,grosor,(b-a).Magnitude+0.04), color, nil, Enum.Material.Neon)
	p.CFrame = CFrame.lookAt((a+b)/2,b)
	return p
end

function Escena.eco(aurora)
	local m = Instance.new("Model")
	m.Name = if aurora then "NimboAurora" else "Nimbo"
	m.PrimaryPart = ovalo(m,"Pecho",v(0,0,0),v(1.55,1.45,1.95),azul)
	ovalo(m,"Gorguera",v(0,.03,-.64),v(1.32,1.12,.94),perla)
	ovalo(m,"Cabeza",v(0,.61,-.74),v(1.35,1.14,1.16),azul)
	ovalo(m,"Pico",v(0,.46,-1.39),v(.34,.26,.52),oro)
	ovalo(m,"Penacho",v(0,1.15,-.6),v(.28,.69,.34),if aurora then violeta else oro,true).Orientation = v(-24,0,0)
	for _,lado in {-1,1} do
		ovalo(m,"Ojo",v(lado*.42,.69,-1.18),v(.26,.28,.22),perla)
		ovalo(m,"Pupila",v(lado*.43,.70,-1.28),v(.13,.16,.10),azul)
		local ala = Instance.new("Model")
		ala.Name = if lado<0 then "AlaIzquierda" else "AlaDerecha"
		ala.Parent = m
		local tono = if aurora then (if lado<0 then menta else violeta) else oro
		for i=1,3 do
			local pluma = ovalo(ala,"Pluma",v(lado*(1.38-i*.13),.14+i*.04,-.45+i*.42),v(2.0-i*.16,.2,.64),tono,aurora)
			pluma.Orientation = v(0,-lado*(12+i*7),lado*(17-i*3))
		end
		ala.WorldPivot = CFrame.new(lado*.58,.12,0)
	end
	ovalo(m,"Cola",v(0,.14,1.15),v(.87,.32,1.14),if aurora then violeta else oro)
	if aurora then
		local a,b = Instance.new("Attachment"),Instance.new("Attachment")
		a.Position,b.Position = v(-.48,.1,.8),v(.48,.1,.8)
		a.Parent,b.Parent = m.PrimaryPart,m.PrimaryPart
		local estela = Instance.new("Trail")
		estela.Attachment0,estela.Attachment1 = a,b
		estela.Color = ColorSequence.new(menta,violeta)
		estela.Transparency = NumberSequence.new(.16,1)
		estela.Lifetime,estela.LightEmission,estela.FaceCamera = .78,1,true
		estela.Parent = m.PrimaryPart
	end
	return m
end

function Escena.ruta(faro)
	local ruta = Instance.new("Model")
	ruta.Name = "RescateNimbo"
	local function suelo(nombre,pos,tam)
		local p = pieza(ruta,nombre,pos,tam,azul,nil,Enum.Material.Slate)
		p.CanCollide,p.CanQuery = true,true
		return p
	end
	suelo("Balcon",v(106,29.2,88),v(8,.8,7))
	local base = ovalo(ruta,"Ascensor",v(104,18.45,91),v(4.3,.65,4.3),menta,true)
	local salto = ovalo(ruta,"Despegue",v(108,29.68,87),v(3.5,.16,3.5),oro,true)
	local plataforma = suelo("Nido",v(153,20,87),v(14,2,14))
	for i=1,10 do
		local a = i*math.pi/5
		ovalo(ruta,"Nube",plataforma.Position+v(7*math.cos(a),-1+math.sin(i*3),7*math.sin(a)),v(6+i%3,4+i%2,6),if i%2==0 then azul else Color3.fromRGB(96,108,146))
	end
	for i=1,3 do
		segmento(ruta,"Relámpago",v(149+i*2,20,81),v(147+i*2,17,81),.16,violeta)
	end
	local huevo = ovalo(ruta,"Huevo",v(153,25,87),v(2.85,3.9,2.85),perla)
	local veta = segmento(ruta,"VetaHuevo",v(152.25,25.8,85.85),v(153.45,24.8,85.65),.16,oro)
	segmento(veta,"Rama",v(153.45,24.8,85.65),v(153.2,24.2,85.69),.12,oro)
	local aros = Instance.new("Folder")
	aros.Name,aros.Parent="Aros",ruta
	for i, centro in {v(119,32,88.5),v(133,29.5,81.3),v(145,27.5,87.8)} do
		local aro = Instance.new("Model")
		aro.Name,aro.Parent = tostring(i),aros
		local origen = pieza(aro,"Centro",centro,Vector3.one*.1,perla)
		origen.Transparency,aro.PrimaryPart = 1,origen
		for j=1,24 do
			local a,b = (j-1)*math.pi/12,j*math.pi/12
			local function punto(t) return centro+v(0,math.cos(t)*4.8,math.sin(t)*4.8) end
			segmento(aro,"Arco",punto(a),punto(b),if j%6==0 then .48 else .2,({menta,oro,violeta})[i])
		end
	end
	ruta.Parent = faro
	return ruta,base,salto,huevo
end

return Escena
