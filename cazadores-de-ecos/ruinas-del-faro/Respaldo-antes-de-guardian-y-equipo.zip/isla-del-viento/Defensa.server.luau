-- Cazadores de Ecos · Isla del Viento
-- El servidor lleva la pelea y entrega el rescate y la mutación.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local isla = workspace:WaitForChild("IslaDelViento")
local accion = ReplicatedStorage:WaitForChild("AccionViento")
local Planeadores = require(ReplicatedStorage:WaitForChild("Planeadores"))
local nido = isla.Nido
local cometa = nido.Cometa
local nucleo = nido.Nucleo
local ruta = isla.Rutas
local efectos = Instance.new("Folder")
efectos.Name = "EfectosDeViento"
efectos.Parent = isla

local VERDE = Color3.fromRGB(120, 255, 219)
local ORO = Color3.fromRGB(255, 211, 125)
local ROJO = Color3.fromRGB(255, 119, 115)
local CIAN = Color3.fromRGB(119, 207, 255)
local CENTRO_NIDO = nido.Base.Position
local VIDA_NIDO = 100
local RADIO_RAFAGA = 11.5
local RECARGA = 0.97
local PISO = 20.1

local jugador
local fase = "Inicio"
local vidaNido = VIDA_NIDO
local pendientes = 0
local ultimoPulso = -100
local vuelos = {}
Players.PlayerRemoving:Connect(function(p)
	local vuelo = vuelos[p]
	if vuelo then vuelo.suelo:Disconnect() end
	vuelos[p] = nil
end)
local tieneCometa = false
local vendaval = false
local balconVisitado = false
local regresoSeguro = false
local avatarReciente

local function ahora()
	return workspace:GetServerTimeNow()
end

local function punto(posicion, nombre, texto, distancia)
	local p = Instance.new("ProximityPrompt")
	p.Name = "Accion"
	p.ObjectText = nombre
	p.ActionText = texto
	p.MaxActivationDistance = distancia
	p.RequiresLineOfSight = false
	p.ClickablePrompt = true
	p.Parent = posicion
	return p
end

local comenzar = punto(isla.Totem, "Nido del Eco Cometa", "Defender nido", 9)
local rescatar = punto(nido.PuntoRescate, "Eco Cometa", "Rescatar", 8.2)
local refugio = punto(ruta.Refugio, "Refugio del viento", "Completar rescate", 9)
local balcon = punto(ruta.Baliza, "Cornisa de los vientos", "Activar baliza", 8)
rescatar.Enabled = false
refugio.Enabled = false
balcon.Enabled = false

local function cartel(parte, texto, tono, altura, distancia)
	local gui = Instance.new("BillboardGui")
	gui.Name = "Cartel"
	gui.Size = UDim2.fromOffset(146, 28)
	gui.StudsOffsetWorldSpace = Vector3.new(0, altura, 0)
	gui.MaxDistance = distancia
	gui.Parent = parte
	local e = Instance.new("TextLabel")
	e.Size = UDim2.fromScale(1, 1)
	e.BackgroundColor3 = Color3.fromRGB(26, 34, 55)
	e.BackgroundTransparency = 0.16
	e.TextColor3 = tono
	e.TextSize = 12
	e.Font = Enum.Font.GothamBold
	e.Text = texto
	e.Parent = gui
	local curva = Instance.new("UICorner")
	curva.CornerRadius = UDim.new(0, 6)
	curva.Parent = e
end

cartel(ruta.PuertaPuente, "PUENTE AL REFUGIO", ORO, 3.7, 47)
cartel(ruta.PuertaPlaneo, "ARO DEL VIENTO", VERDE, 3.7, 47)
cartel(ruta.CorazonCorriente, "CORRIENTE ASCENDENTE", CIAN, 3.5, 34)

local function objetivo(siguiente, titulo, pista)
	fase = siguiente
	isla:SetAttribute("Fase", fase)
	isla:SetAttribute("Titulo", titulo)
	isla:SetAttribute("Pista", pista)
	if jugador then jugador:SetAttribute("FaseNido", fase) end
end

local function actualizarNido()
	isla:SetAttribute("VidaNido", vidaNido)
	isla:SetAttribute("VigiasActivos", pendientes)
	nucleo.Color = ROJO:Lerp(ORO, vidaNido / VIDA_NIDO)
end

local function personajeActivo()
	local personaje = jugador and jugador.Character
	local h = personaje and personaje:FindFirstChildOfClass("Humanoid")
	local root = personaje and personaje:FindFirstChild("HumanoidRootPart")
	if h and h.Health > 0 and root then
		return root, h
	end
	return nil
end

local function dentro(posicion, zona)
	local diferencia = zona.CFrame:PointToObjectSpace(posicion)
	local tamano = zona.Size / 2
	return math.abs(diferencia.X) <= tamano.X
		and math.abs(diferencia.Y) <= tamano.Y
		and math.abs(diferencia.Z) <= tamano.Z
end

local function vectorPlano(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function enArena(v)
	return Vector3.new(math.clamp(v.X, -34, 21), v.Y, math.clamp(v.Z, -24, 24))
end

local function cercaDeAccion(quien, p)
	local root = personajeActivo()
	return quien == jugador and p.Enabled and root
		and (root.Position - p.Parent.Position).Magnitude <= p.MaxActivationDistance + 0.75
end

local function piezaEfecto(nombre, tamano, posicion, tono)
	local parte = Instance.new("Part")
	parte.Name = nombre
	parte.Size = tamano
	parte.CFrame = posicion
	parte.Material = Enum.Material.Neon
	parte.Color = tono
	parte.Anchored = true
	parte.CanCollide = false
	parte.CanTouch = false
	parte.CanQuery = false
	parte.CastShadow = false
	parte.Parent = efectos
	return parte
end

local function disco(nombre, centro, radio, tono)
	local p = piezaEfecto(nombre, Vector3.new(0.09, radio * 2, radio * 2),
		CFrame.new(centro) * CFrame.Angles(0, 0, math.pi / 2), tono)
	p.Shape = Enum.PartType.Cylinder
	return p
end

local function pulsoVisual(root)
	local destello = disco("Rafaga", root.Position - Vector3.new(0, 2.2, 0), 2, VERDE)
	destello.Transparency = 0.27
	local a = TweenService:Create(destello, TweenInfo.new(0.24, Enum.EasingStyle.Quad), {
		Size = Vector3.new(0.09, RADIO_RAFAGA * 2, RADIO_RAFAGA * 2),
		Transparency = 1,
	})
	a.Completed:Once(function()
		destello:Destroy()
	end)
	a:Play()
end

local function ficha(modelo, cazador, rapidez, golpes, demora)
	local visibilidad = {}
	for _, parte in ipairs(modelo:GetDescendants()) do
		if parte:IsA("BasePart") then
			visibilidad[parte] = parte.Transparency
		end
	end
	local base = modelo.PrimaryPart
	local gui = Instance.new("BillboardGui")
	gui.Name = "Vida"
	gui.Size = UDim2.fromOffset(104, 35)
	gui.StudsOffsetWorldSpace = Vector3.new(0, 3.3, 0)
	gui.MaxDistance = 42
	gui.Parent = base
	local texto = Instance.new("TextLabel")
	texto.BackgroundTransparency = 1
	texto.Size = UDim2.fromScale(1, 1)
	texto.Font = Enum.Font.GothamBold
	texto.TextSize = 12
	texto.TextColor3 = Color3.fromRGB(255, 248, 231)
	texto.TextStrokeTransparency = 0.45
	texto.Parent = gui
	return {
		modelo = modelo, original = modelo:GetPivot(), visibilidad = visibilidad, gui = gui, texto = texto,
		cazador = cazador, rapidez = rapidez, maxGolpes = golpes, demora = demora, estado = "Fuera",
		pos = base.Position, frente = -Vector3.xAxis, salud = golpes, hasta = 0, listoEn = 0,
	}
end

local vigias = {
	ficha(isla.Vigias.Embestidor, true, 8.4, 2, 0.25),
	ficha(isla.Vigias.Rompenidos, false, 5.3, 3, 1.3),
}

local function mostrarVigia(v, aparece)
	for parte, transparencia in pairs(v.visibilidad) do
		parte.Transparency = if aparece then transparencia else 1
	end
	v.gui.Enabled = aparece
end

local function quitarAviso(v)
	if v.aviso then
		v.aviso:Destroy()
		v.aviso = nil
	end
end

local function ponerVigia(v)
	v.modelo:PivotTo(CFrame.lookAt(v.pos, v.pos + v.frente))
end

local function rotulo(v, aviso)
	v.texto.Text = aviso or ("%s  %d/%d"):format(v.modelo.Name, v.salud, v.maxGolpes)
end

local function desactivarVigias()
	for _, v in ipairs(vigias) do
		v.estado = "Fuera"
		quitarAviso(v)
		mostrarVigia(v, false)
	end
end

local function prepararDefensa(quien)
	if (fase ~= "Inicio" and fase ~= "Perdido") or not cercaDeAccion(quien, comenzar) then
		return
	end
	local _, humanoide = personajeActivo()
	humanoide.Health = humanoide.MaxHealth
	comenzar.Enabled = false
	vidaNido = VIDA_NIDO
	pendientes = #vigias
	local tiempo = ahora()
	for _, v in ipairs(vigias) do
		v.pos = v.original.Position
		v.frente = -Vector3.xAxis
		v.salud = v.maxGolpes
		v.estado = "Llegando"
		v.hasta = tiempo + v.demora
		v.listoEn = 0
		v.golpeoNido = false
		v.golpeoJugador = false
		quitarAviso(v)
		ponerVigia(v)
		mostrarVigia(v, false)
	end
	actualizarNido()
	objetivo("Defensa", "Defiende al Eco Cometa", "Esquiva las zonas rojas y usa la ráfaga cerca de los vigías.")
end
comenzar.Triggered:Connect(prepararDefensa)

local function perder(texto)
	desactivarVigias()
	pendientes = 0
	actualizarNido()
	comenzar.ActionText = "Reintentar defensa"
	comenzar.Enabled = true
	objetivo("Perdido", "El nido necesita otro intento", texto)
end

local function victoria()
	rescatar.Enabled = true
	nucleo.Color = VERDE
	for _, barra in ipairs(nido.Barrera:GetChildren()) do
		TweenService:Create(barra, TweenInfo.new(0.32), { Transparency = 1 }):Play()
	end
	objetivo("Rescate", "¡Nido a salvo!", "Acércate al nido y rescata al Cometa.")
end

local function danoAlNido(cantidad)
	vidaNido = math.max(0, vidaNido - cantidad)
	actualizarNido()
	if vidaNido == 0 then
		perder("Vuelve al tótem para defenderlo de nuevo.")
	end
end

local function ataquePreparado(v, destino, tiempo)
	v.estado = "Aviso"
	quitarAviso(v)
	local diferencia = vectorPlano(destino - v.pos)
	if diferencia.Magnitude > 0.05 then
		v.frente = diferencia.Unit
	end
	ponerVigia(v)
	if v.cazador then
		v.hasta = tiempo + 0.8
		v.avance = 14
		local inicio = Vector3.new(v.pos.X, PISO, v.pos.Z)
		local centro = inicio + v.frente * (v.avance / 2)
		v.aviso = piezaEfecto("AvisoEmbestida", Vector3.new(6.4, 0.13, v.avance),
			CFrame.lookAt(centro, centro + v.frente), ROJO)
		rotulo(v, "¡EMBESTIDA!")
	else
		v.hasta = tiempo + 0.95
		v.aviso = disco("AvisoAlNido", Vector3.new(CENTRO_NIDO.X, PISO, CENTRO_NIDO.Z), 5.6, ROJO)
		rotulo(v, "¡AL NIDO!")
	end
	v.aviso.Transparency = 0.27
end

local function actualizarVigia(v, root, humanoide, dt, tiempo)
	if v.estado == "Fuera" or v.estado == "Derrotado" then
		return
	end

	if v.estado == "Llegando" then
		if tiempo >= v.hasta then
			v.estado = "Avanza"
			mostrarVigia(v, true)
			rotulo(v)
		end
		return
	end

	if v.estado == "Aturdido" or v.estado == "Recupera" then
		if tiempo >= v.hasta then
			v.estado = "Avanza"
			rotulo(v)
		end
		return
	end

	if v.estado == "Aviso" then
		if tiempo < v.hasta then
			return
		end
		quitarAviso(v)
		if v.cazador then
			v.estado = "Embestida"
			v.golpeoJugador = false
			v.golpeoNido = false
		else
			v.estado = "Recupera"
			v.hasta = tiempo + 2.4
			danoAlNido(27)
			if vectorPlano(root.Position - CENTRO_NIDO).Magnitude < 5.5 and root.Position.Y < 26 then
				humanoide:TakeDamage(14)
			end
		end
		rotulo(v)
		return
	end

	if v.estado == "Embestida" then
		local paso = math.min(v.avance, 28 * dt)
		v.avance -= paso
		v.pos = enArena(v.pos + v.frente * paso)
		ponerVigia(v)
		if not v.golpeoJugador and vectorPlano(root.Position - v.pos).Magnitude < 3.7 and root.Position.Y < 26 then
			v.golpeoJugador = true
			humanoide:TakeDamage(32)
		end
		if not v.golpeoNido and vectorPlano(CENTRO_NIDO - v.pos).Magnitude < 3.5 then
			v.golpeoNido = true
			danoAlNido(22)
			if fase ~= "Defensa" then
				return
			end
		end
		if v.avance <= 0 then
			v.estado = "Recupera"
			v.hasta = tiempo + 1.38
		end
		return
	end

	local persigue = v.cazador and vectorPlano(root.Position - v.pos).Magnitude < 20 and root.Position.Y < 27
	local destino = if persigue then root.Position else CENTRO_NIDO
	local delta = vectorPlano(destino - v.pos)
	local radio = if v.cazador then 12.5 else 5.3
	if delta.Magnitude <= radio and tiempo >= v.listoEn then
		ataquePreparado(v, destino, tiempo)
	elseif delta.Magnitude > 0.1 then
		v.frente = delta.Unit
		v.pos = enArena(v.pos + v.frente * math.min(v.rapidez * dt, delta.Magnitude))
		ponerVigia(v)
	end
end

local function registrarPlaneo(quien, tipo)
	local vuelo = vuelos[quien]
	if tipo == "PlegarPlaneo" then
		if vuelo then quien:SetAttribute("PlaneoIslaHasta", 0) end
		return
	end
	local personaje = quien.Character
	local h = personaje and personaje:FindFirstChildOfClass("Humanoid")
	local root = personaje and personaje:FindFirstChild("HumanoidRootPart")
	if not root or not h or h.Health <= 0 or not quien:GetAttribute("Cometa")
		or quien:GetAttribute("EnCueva") or quien:GetAttribute("EnMolino") or quien:GetAttribute("EnFaro") then return end
	if not vuelo or vuelo.humanoide ~= h then
		if vuelo then vuelo.suelo:Disconnect() end
		vuelo = { humanoide = h, hasta = 0 }
		vuelos[quien] = vuelo
		vuelo.suelo = h:GetPropertyChangedSignal("FloorMaterial"):Connect(function()
			if h.FloorMaterial ~= Enum.Material.Air then vuelo.hasta = 0 end
		end)
	end
	local tiempo = ahora()
	if tiempo < vuelo.hasta then return end
	local ajustes = Planeadores.ajustes(quien:GetAttribute("PlaneadorAvanzado") == true)
	vuelo.hasta = tiempo + ajustes.ventanaServidor
	quien:SetAttribute("PlaneoIslaHasta", vuelo.hasta)
end

accion.OnServerEvent:Connect(function(quien, tipo)
	if tipo == "Planeo" or tipo == "PlegarPlaneo" then
		registrarPlaneo(quien, tipo)
		return
	end
	if quien ~= jugador then return end
	local root = personajeActivo()
	if not root then return end
	local tiempo = ahora()
	if tipo ~= "Rafaga" or (fase ~= "Defensa" and fase ~= "Inicio" and fase ~= "Perdido") or tiempo - ultimoPulso < RECARGA then
		return
	end

	ultimoPulso = tiempo
	jugador:SetAttribute("RafagaListaEn", tiempo + RECARGA)
	pulsoVisual(root)
	if fase ~= "Defensa" then
		return
	end
	for _, v in ipairs(vigias) do
		local cerca = (v.pos - root.Position).Magnitude <= RADIO_RAFAGA
		if cerca and v.estado ~= "Fuera" and v.estado ~= "Llegando" and v.estado ~= "Derrotado" then
			v.salud -= 1
			quitarAviso(v)
			if v.salud == 0 then
				v.estado = "Derrotado"
				mostrarVigia(v, false)
				pendientes -= 1
			else
				local empuje = vectorPlano(v.pos - root.Position)
				if empuje.Magnitude > 0.1 then
					v.pos = enArena(v.pos + empuje.Unit * 5.2)
				end
				ponerVigia(v)
				v.estado = "Aturdido"
				v.hasta = tiempo + 0.67
				v.listoEn = tiempo + 0.95
				rotulo(v)
			end
		end
	end

	actualizarNido()
	if pendientes == 0 then
		victoria()
	end
end)

local function abrirPuerta(objeto)
	objeto.CanCollide = false
	TweenService:Create(objeto, TweenInfo.new(0.33), { Transparency = 1 }):Play()
end

local function activarCometa()
	comenzar.Enabled = false
	rescatar.Enabled = false
	tieneCometa = true
	isla.PuntoRetorno.Enabled = true
	jugador.RespawnLocation = isla.PuntoRetorno
	abrirPuerta(ruta.PuertaPuente)
	abrirPuerta(ruta.PuertaPlaneo)
	refugio.Enabled = true
	objetivo("Regreso", "Cometa rescatado · planeo desbloqueado", "Vuelve por el puente o salta hacia el aro y usa el planeo.")
end

rescatar.Triggered:Connect(function(quien)
	if fase ~= "Rescate" or not cercaDeAccion(quien, rescatar) then
		return
	end
	activarCometa()
	jugador:SetAttribute("Cometa", true)
end)

local function mutar()
	vendaval = true
	jugador:SetAttribute("Vendaval", true)
	cometa.Nucleo.Color = CIAN
	cometa.Nucleo["Luz propia"].Color = CIAN
	for _, parte in ipairs(cometa:GetChildren()) do
		if parte:IsA("BasePart") and parte.Material == Enum.Material.Neon then
			parte.Color = CIAN
		end
	end
	cometa:ScaleTo(1.25)
	ruta.CorazonCorriente.Color = CIAN
	balcon.Enabled = true
	objetivo("Regreso", "¡Cometa mutó a Vendaval!", "Entra en la columna azul y activa el planeo para subir a la cornisa.")
end

refugio.Triggered:Connect(function(quien)
	if not tieneCometa or regresoSeguro or not cercaDeAccion(quien, refugio) then
		return
	end
	regresoSeguro = true
	jugador:SetAttribute("Refugio", true)
	refugio.Enabled = false
	objetivo("Refugio", "Cometa llegó al refugio", if balconVisitado then "Rescate y cornisa completados."
		else "El aro sigue abierto si quieres probar el regreso por el aire.")
end)

balcon.Triggered:Connect(function(quien)
	if not vendaval or balconVisitado or not cercaDeAccion(quien, balcon) then
		return
	end
	balconVisitado = true
	jugador:SetAttribute("Cornisa", true)
	balcon.Enabled = false
	ruta.Baliza.Color = ORO
	objetivo("Cornisa", "¡Alcanzaste la Cornisa de los Vientos!", "Tu Cometa Vendaval te trajo a un lugar secreto.")
end)

local function recibeJugador(nuevo)
	if jugador then
		return
	end
	jugador = nuevo
	for _, nombre in ipairs({ "Cometa", "Vendaval", "Refugio", "Cornisa" }) do
		if nuevo:GetAttribute(nombre) == nil then
			nuevo:SetAttribute(nombre, false)
		end
	end
	jugador:SetAttribute("RafagaListaEn", 0)
	jugador:SetAttribute("PlaneoIslaHasta", 0)
	local function recuperarProgreso()
		if nuevo:GetAttribute("Cometa") and not tieneCometa then
			desactivarVigias()
			pendientes = 0
			actualizarNido()
			activarCometa()
		end
		if tieneCometa and nuevo:GetAttribute("Vendaval") and not vendaval then
			mutar()
		end
		if tieneCometa and nuevo:GetAttribute("Refugio") and not regresoSeguro then
			regresoSeguro = true
			refugio.Enabled = false
			objetivo("Refugio", "Cometa llegó al refugio", "La isla conserva tu rescate. Puedes seguir explorando.")
		end
		if vendaval and nuevo:GetAttribute("Cornisa") and not balconVisitado then
			balconVisitado = true
			balcon.Enabled = false
			ruta.Baliza.Color = ORO
			objetivo("Cornisa", "Cornisa de los Vientos", "Tu Cometa Vendaval conoce la corriente.")
		end
	end
	for _, nombre in ipairs({ "ProgresoRevision", "Cometa", "Vendaval", "Refugio", "Cornisa" }) do
		nuevo:GetAttributeChangedSignal(nombre):Connect(recuperarProgreso)
	end
	recuperarProgreso()
end

desactivarVigias()
actualizarNido()
objetivo("Inicio", "Rescate en la Isla del Viento", "Acércate al tótem para defender el nido. Puedes probar tu ráfaga.")
Players.PlayerAdded:Connect(recibeJugador)
for _, conectado in ipairs(Players:GetPlayers()) do
	recibeJugador(conectado)
end

while true do
	local dt = math.min(task.wait(0.055), 0.12)
	local tiempo = ahora()
	local root, humanoide = personajeActivo()
	if fase == "Defensa" then
		if not root or (avatarReciente and root.Parent ~= avatarReciente) then
			perder("El tótem te permite volver a intentarlo.")
		else
			for _, v in ipairs(vigias) do
				actualizarVigia(v, root, humanoide, dt, tiempo)
				if fase ~= "Defensa" then
					break
				end
			end
		end
	end
	avatarReciente = root and root.Parent
	if root and tieneCometa and not jugador:GetAttribute("EnCueva") then
		if not vendaval and tiempo < (jugador:GetAttribute("PlaneoIslaHasta") or 0) and dentro(root.Position, ruta.ZonaAro) then
			mutar()
		end
		local lado = root.CFrame.RightVector * 4.1
		local posicion = root.Position + lado - root.CFrame.LookVector * 2.5
			+ Vector3.new(0, 2.1 + math.sin(tiempo * 3.5) * 0.31, 0)
		local destino = CFrame.lookAt(posicion, posicion + root.CFrame.LookVector)
		cometa:PivotTo(cometa:GetPivot():Lerp(destino, 0.26))
	end
end
