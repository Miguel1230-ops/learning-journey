-- Controles y movimiento del jugador en la prueba Isla del Viento.
local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local ContextActionService = game:GetService("ContextActionService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local jugador = Players.LocalPlayer
local isla = workspace:WaitForChild("IslaDelViento")
local ruta = isla:WaitForChild("Rutas")
local molino = isla:FindFirstChild("MolinoDelViento")
local despegueMolino = molino and molino:FindFirstChild("PlayaDespegue")
local accion = ReplicatedStorage:WaitForChild("AccionViento")
local Planeadores = require(ReplicatedStorage:WaitForChild("Planeadores"))
local gui = Instance.new("ScreenGui")
gui.Name = "IslaDelVientoHUD"
gui.ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets
gui.ResetOnSpawn = false
gui.Parent = jugador:WaitForChild("PlayerGui")

local function fueraDelRecorrido()
	return jugador:GetAttribute("EnCueva") or jugador:GetAttribute("EnMolino") or jugador:GetAttribute("EnFaro")
		or jugador:GetAttribute("MolinoPresentando") or jugador:GetAttribute("FaroPresentando")
end

local function verInterfazIsla()
	gui.Enabled = not fueraDelRecorrido() and not jugador:GetAttribute("EnEncargoPedernal")
		and not jugador:GetAttribute("FareroConversando")
end
for _, nombre in ipairs({ "EnMolino", "EnEncargoPedernal", "EnFaro", "FaroPresentando", "MolinoPresentando", "FareroConversando" }) do
	jugador:GetAttributeChangedSignal(nombre):Connect(verInterfazIsla)
end
verInterfazIsla()

local CLARO = Color3.fromRGB(249, 251, 247)
local SUAVE = Color3.fromRGB(220, 233, 242)
local VERDE = Color3.fromRGB(143, 244, 217)
local ORO = Color3.fromRGB(255, 211, 125)
local ROJO = Color3.fromRGB(255, 119, 115)
local NOCHE = Color3.fromRGB(20, 29, 46)

local function esquinas(objeto, radio)
	local curva = Instance.new("UICorner")
	curva.CornerRadius = UDim.new(0, radio)
	curva.Parent = objeto
end

local function etiqueta(padre, nombre, tamano, y, alto, color, fuente)
	local e = Instance.new("TextLabel")
	e.Name = nombre
	e.BackgroundTransparency = 1
	e.Position = UDim2.fromOffset(13, y)
	e.Size = UDim2.new(1, -26, 0, alto)
	e.Text = ""
	e.TextSize = tamano
	e.TextColor3 = color
	e.TextWrapped = true
	e.TextXAlignment = Enum.TextXAlignment.Left
	e.TextYAlignment = Enum.TextYAlignment.Top
	e.Font = fuente
	e.Parent = padre
	return e
end

local tarjeta = Instance.new("Frame")
tarjeta.Name = "Objetivo"
tarjeta.BackgroundColor3 = NOCHE
tarjeta.BackgroundTransparency = 0.09
tarjeta.BorderSizePixel = 0
tarjeta.Position = UDim2.fromOffset(13, 10)
tarjeta.Size = UDim2.new(1, -26, 0, 107)
esquinas(tarjeta, 12)
local limite = Instance.new("UISizeConstraint")
limite.MaxSize = Vector2.new(370, 107)
limite.Parent = tarjeta
tarjeta.Parent = gui

local titulo = etiqueta(tarjeta, "Titulo", 17, 10, 34, CLARO, Enum.Font.GothamBold)
local pista = etiqueta(tarjeta, "Pista", 13, 42, 32, SUAVE, Enum.Font.GothamMedium)
local estado = etiqueta(tarjeta, "Estado", 11, 79, 15, VERDE, Enum.Font.GothamBold)
local barra = Instance.new("Frame")
barra.Name = "VidaDelNido"
barra.BackgroundColor3 = Color3.fromRGB(55, 74, 100)
barra.BorderSizePixel = 0
barra.Position = UDim2.fromOffset(13, 95)
barra.Size = UDim2.new(1, -26, 0, 4)
barra.Parent = tarjeta
local relleno = Instance.new("Frame")
relleno.BorderSizePixel = 0
relleno.BackgroundColor3 = VERDE
relleno.Size = UDim2.fromScale(1, 1)
relleno.Parent = barra

local teclado = Instance.new("TextLabel")
teclado.Name = "Controles"
teclado.AnchorPoint = Vector2.new(0.5, 1)
teclado.Position = UDim2.new(0.5, 0, 1, -15)
teclado.Size = UDim2.new(0.8, 0, 0, 30)
teclado.BackgroundTransparency = 0.12
teclado.BackgroundColor3 = NOCHE
teclado.Font = Enum.Font.GothamMedium
teclado.TextColor3 = CLARO
teclado.TextSize = 13
teclado.Text = ""
teclado.Visible = not UIS.TouchEnabled
teclado.BorderSizePixel = 0
esquinas(teclado, 8)
local limiteTeclado = Instance.new("UISizeConstraint")
limiteTeclado.MaxSize = Vector2.new(390, 30)
limiteTeclado.Parent = teclado
teclado.Parent = gui

local boton = Instance.new("TextButton")
boton.Name = "AccionMovil"
boton.AnchorPoint = Vector2.new(1, 1)
boton.Position = UDim2.new(1, -18, 1, -110)
boton.Size = UDim2.fromOffset(113, 50)
boton.BackgroundColor3 = NOCHE
boton.TextColor3 = VERDE
boton.TextSize = 15
boton.Text = "Ráfaga"
boton.Font = Enum.Font.GothamBold
boton.Visible = UIS.TouchEnabled
boton.BorderSizePixel = 0
esquinas(boton, 12)
boton.Parent = gui

local root
local humanoide
local vuelo
local planeador
local accionUsadaEnAire = false
local ultimoPulsoLocal = -10
local mostrarHasta = 0
local ABRIR_ALAS = 0.20
local PLEGAR_ALAS = 0.23

local function quitarPlaneador()
	if planeador then
		planeador.modelo:Destroy()
		planeador = nil
	end
end

local function acabarPlaneo(plegar)
	if vuelo then
		vuelo = nil
		jugador:SetAttribute("PlaneandoLocal", false)
	end
	if planeador and plegar then
		planeador.plegando = os.clock()
		planeador.desde = math.clamp((planeador.plegando - planeador.inicio) / ABRIR_ALAS, 0, 1)
	else
		quitarPlaneador()
	end
end

local function leerPersonaje(personaje)
	local parte = personaje:WaitForChild("HumanoidRootPart", 10)
	local controlador = personaje:WaitForChild("Humanoid", 10)
	if personaje ~= jugador.Character then
		return
	end
	acabarPlaneo(false)
	root, humanoide = parte, controlador
	accionUsadaEnAire = false
	jugador:SetAttribute("PlaneandoLocal", false)
end

jugador.CharacterAdded:Connect(leerPersonaje)
jugador.CharacterRemoving:Connect(function(personaje)
	if root and root.Parent == personaje then
		acabarPlaneo(false)
		root, humanoide = nil, nil
	end
end)
if jugador.Character then
	task.spawn(leerPersonaje, jugador.Character)
end

local function horizontal(v)
	return Vector3.new(v.X, 0, v.Z)
end

local function enCorriente()
	if not root or not jugador:GetAttribute("Vendaval") then
		return false
	end
	local zona = ruta.ZonaAscenso
	local d = zona.CFrame:PointToObjectSpace(root.Position)
	local t = zona.Size / 2
	return math.abs(d.X) <= t.X and math.abs(d.Y) <= t.Y and math.abs(d.Z) <= t.Z
end

local function rafaga()
	local fase = isla:GetAttribute("Fase")
	if fase ~= "Inicio" and fase ~= "Perdido" and fase ~= "Defensa" then
		return
	end
	if os.clock() - ultimoPulsoLocal >= 0.17 and (jugador:GetAttribute("RafagaListaEn") or 0) <= workspace:GetServerTimeNow() then
		ultimoPulsoLocal = os.clock()
		accion:FireServer("Rafaga")
	end
end

local function fueraDePlaneo()
	return fueraDelRecorrido() and not (jugador:GetAttribute("EnFaro") and jugador:GetAttribute("RescateNimbo") == "Vuelo")
end

local function iniciarPlaneo(desdeTorre)
	if not jugador:GetAttribute("Cometa") or (not desdeTorre and fueraDelRecorrido())
		or not root or not humanoide or humanoide.Health <= 0 or vuelo then
		return
	end
	local impulso = enCorriente()
	if not desdeTorre and not impulso and (humanoide.FloorMaterial ~= Enum.Material.Air or accionUsadaEnAire) then
		mostrarHasta = os.clock() + 1
		return
	end

	local direccion = if desdeTorre then Vector3.xAxis else horizontal(humanoide.MoveDirection)
	if direccion.Magnitude < 0.1 then
		direccion = horizontal(root.CFrame.LookVector)
	end
	if direccion.Magnitude < 0.1 then
		direccion = Vector3.xAxis
	end
	local mejorado = jugador:GetAttribute("PlaneadorAvanzado") == true
	vuelo = { inicio = os.clock(), direccion = direccion.Unit, impulso = impulso, ajustes = Planeadores.ajustes(mejorado) }
	quitarPlaneador()
	planeador = Planeadores.crear(mejorado)
	planeador.inicio = vuelo.inicio
	planeador.direccion = vuelo.direccion
	planeador.banco = 0
	Planeadores.colocar(planeador, root.Position, vuelo.direccion, 0, 0)
	planeador.modelo.Parent = workspace
	accionUsadaEnAire = true
	jugador:SetAttribute("PlaneandoLocal", true)
	if not desdeTorre then accion:FireServer("Planeo") end
	if impulso then
		humanoide:ChangeState(Enum.HumanoidStateType.Freefall)
	end
end

ReplicatedStorage:WaitForChild("AccionFaro").OnClientEvent:Connect(function(evento, origen)
	if evento ~= "VueloNimbo" or not root then return end
	if jugador:GetAttribute("RescateNimbo") ~= "Vuelo" then
		local limite = os.clock() + 1
		repeat task.wait() until jugador:GetAttribute("RescateNimbo") == "Vuelo" or os.clock() >= limite
	end
	if jugador:GetAttribute("RescateNimbo") ~= "Vuelo" or not root then return end
	root.Parent:PivotTo(CFrame.lookAt(origen, origen + Vector3.xAxis))
	root.AssemblyLinearVelocity = Vector3.zero
	humanoide:ChangeState(Enum.HumanoidStateType.Freefall)
	iniciarPlaneo(true)
end)

local function enlace(funcion)
	return function(_, entrada)
		if fueraDelRecorrido() then
			return Enum.ContextActionResult.Pass
		end
		if entrada == Enum.UserInputState.Begin then
			funcion()
		end
		return Enum.ContextActionResult.Sink
	end
end

ContextActionService:BindAction("VientoRafaga", enlace(rafaga), false, Enum.KeyCode.Q, Enum.KeyCode.ButtonX)
ContextActionService:BindAction("VientoPlano", enlace(iniciarPlaneo), false, Enum.KeyCode.F, Enum.KeyCode.ButtonY)
boton.Activated:Connect(function()
	if jugador:GetAttribute("Cometa") then
		iniciarPlaneo()
	else
		rafaga()
	end
end)

RunService.PreSimulation:Connect(function(dt)
	if not root or not humanoide or humanoide.Health <= 0 or fueraDePlaneo() then
		acabarPlaneo(false)
		return
	end
	local enSuelo = humanoide.FloorMaterial ~= Enum.Material.Air
	if not vuelo then
		if enSuelo then
			accionUsadaEnAire = false
		end
		return
	end

	local tiempo = os.clock() - vuelo.inicio
	local elevando = vuelo.impulso and root.Position.Y < ruta.AlturaSalida.Position.Y and enCorriente()
	if tiempo > vuelo.ajustes.duracion or (enSuelo and not elevando and tiempo > 0.22) then
		acabarPlaneo(true)
		return
	end

	local velocidad = root.AssemblyLinearVelocity
	local mando = horizontal(humanoide.MoveDirection)
	local banco = 0
	if mando.Magnitude > 0.14 and not elevando then
		banco = math.clamp(vuelo.direccion:Cross(mando.Unit).Y * 0.26, -0.24, 0.24)
		local giro = vuelo.direccion:Lerp(mando.Unit, math.min(dt * vuelo.ajustes.giro, 1))
		vuelo.direccion = if giro.Magnitude > 0.05 then giro.Unit else mando.Unit
	end

	local movimiento
	local y
	if elevando then
		movimiento = horizontal(ruta.ZonaAscenso.Position - root.Position) * 3.6
		y = math.max(velocidad.Y, 25)
		vuelo.direccion = Vector3.xAxis
	else
		movimiento = vuelo.direccion * vuelo.ajustes.velocidad
		y = math.max(velocidad.Y, -4.4)
	end
	planeador.banco += (banco - planeador.banco) * math.min(dt * 9, 1)
	planeador.direccion = vuelo.direccion
	root.AssemblyLinearVelocity = Vector3.new(movimiento.X, y, movimiento.Z)
end)

RunService.PreRender:Connect(function()
	if not planeador or not root or fueraDePlaneo() then
		return
	end
	local t = os.clock()
	local apertura = math.clamp((t - planeador.inicio) / ABRIR_ALAS, 0, 1)
	if planeador.plegando then
		apertura = planeador.desde * math.max(0, 1 - (t - planeador.plegando) / PLEGAR_ALAS)
		if apertura <= 0 then
			quitarPlaneador()
			return
		end
	end
	local camara = workspace.CurrentCamera
	local cerca = camara and (camara.CFrame.Position - root.Position).Magnitude < 2.7
	if cerca then
		if planeador.modelo.Parent then
			planeador.modelo.Parent = nil
		end
		return
	end
	Planeadores.colocar(planeador, root.Position, planeador.direccion, apertura * apertura * (3 - 2 * apertura), planeador.banco)
	if not planeador.modelo.Parent then
		planeador.modelo.Parent = workspace
	end
end)

local tiempoPantalla = 0
RunService.Heartbeat:Connect(function(dt)
	if not gui.Enabled then
		return
	end
	tiempoPantalla += dt
	if tiempoPantalla < 0.095 then
		return
	end
	tiempoPantalla = 0
	local fase = isla:GetAttribute("Fase") or "Inicio"
	local vida = isla:GetAttribute("VidaNido") or 100
	local quedan = isla:GetAttribute("VigiasActivos") or 0
	local rescatado = jugador:GetAttribute("Cometa")
	local mejorado = jugador:GetAttribute("Vendaval")
	local listo = (jugador:GetAttribute("RafagaListaEn") or 0) <= workspace:GetServerTimeNow()
	local guiandoAlMolino = fase ~= "Defensa" and root and despegueMolino and rescatado
		and jugador:GetAttribute("Pedernal") and not jugador:GetAttribute("Lucero")
		and (root.Position - despegueMolino.Position).Magnitude < 13
	tarjeta.Visible = not guiandoAlMolino
	titulo.Text = isla:GetAttribute("Titulo") or "Isla del Viento"
	pista.Text = isla:GetAttribute("Pista") or ""
	barra.Visible = fase == "Defensa"
	relleno.Size = UDim2.fromScale(vida / 100, 1)
	relleno.BackgroundColor3 = ROJO:Lerp(VERDE, vida / 100)
	if fase == "Defensa" then
		estado.Text = ("%d%% nido   ·   %d vigías"):format(vida, quedan)
	elseif rescatado then
		estado.Text = if mejorado then "COMETA VENDAVAL   ·   LAS CORRIENTES TE ELEVAN" else "ECO COMETA   ·   PLANEO"
	else
		estado.Text = ""
	end
	if rescatado then
		teclado.Text = if vuelo then "Planeando   ·   dirige con WASD"
			elseif enCorriente() then "F  Ascender en la corriente   ·   E  Interactuar"
			elseif os.clock() < mostrarHasta then "Salta y pulsa F para planear"
			else "Espacio  Saltar   ·   F  Planear   ·   E  Interactuar"
		boton.Text = if enCorriente() then "Ascender" elseif vuelo then "Planeando" else "Planeo"
	else
		teclado.Text = if listo then "Q  Ráfaga   ·   E  Interactuar" else "Ráfaga recargando…"
		boton.Text = if listo then "Ráfaga" else "Recargando"
	end
	boton.TextColor3 = if rescatado or listo then VERDE else ORO
end)
